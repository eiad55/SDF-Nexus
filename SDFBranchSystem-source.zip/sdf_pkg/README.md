# نظام إدارة ومراجعة ملفات البرامج التدريبية

صندوق تنمية المهارات — مكتب النائب لشؤون الفروع

تطبيق مكتبي (Windows) باللغة العربية (RTL) لإدارة ملفات البرامج التدريبية ومراجعتها
فنيًا وماليًا، مع استمارة مراجعة رسمية قابلة للطباعة.

## التشغيل للمستخدم

1. ثبّت البرنامج عبر `SDFBranchSystem-Setup-1.0.0.exe` (اختصار على سطح المكتب).
2. سجّل الدخول: المستخدم الافتراضي `admin` / `admin123` — **غيّر كلمة المرور فورًا**
   من صفحة الإعدادات ← المستخدمون.
3. استورد بياناتك من صفحة «استيراد من Excel» (xlsx / xlsm / xls).
4. راجع الملفات من صفحة «المراجعة الفنية»، واطبع الاستمارة من «التقارير والطباعة».

**البيانات** تُحفظ في `%LOCALAPPDATA%\SDFBranchSystem` (قاعدة البيانات والمرفقات
والنسخ الاحتياطية) — لا تُحذف عند إلغاء تثبيت البرنامج أو تحديثه.

## البناء من المصدر (Windows)

```bat
pip install -r requirements-dev.txt
python -m pytest tests/ -q
pyinstaller build\SDFBranchSystem.spec
iscc build\setup.iss
```

الناتج:
- `dist\SDFBranchSystem\` — نسخة محمولة (بدون تثبيت)
- `dist\SDFBranchSystem-Setup-1.0.0.exe` — المثبت

أو تلقائيًا عبر GitHub Actions: استخدم وسم إصدار بصيغة `vMAJOR.MINOR.PATCH` مثل `v1.0.0`؛ الأوسمة الأخرى التي تبدأ بـ`v` تُرفض عمدًا.

## البنية

```
src/sdf_app/
  main.py            نقطة الدخول
  config.py          المسارات والإعدادات (البيانات منفصلة عن البرنامج)
  database/          schema.sql + الترحيلات + البذور
  core/              finance.py (Decimal) / review_logic.py / workflow.py / validation.py
  services/          file_service / import_service (xlsx+xlsm+xls) / export_service
                     auth_service (PBKDF2) / backup_service
  reports/           review_form.py (استمارة PDF) + excel_reports.py
  ui/                واجهات PySide6 عربية RTL
build/               SDFBranchSystem.spec + setup.iss + icon
tests/               اختبارات pytest؛ اعرض العدد الحالي عبر `python -m pytest tests/ --collect-only -q`
docs/                excel_inspection.md (فحص الملف الأصلي) + خطة التنفيذ + changes_fixes.md (إصلاحات المراجعة)
```

## قواعد العمل المطبقة

- القرار المالي النهائي للموظف المخول — النظام يدير المراجعة والتوثيق فقط.
- «غير المنطبق» ليست حالة نقص، والعدد المفقود لا يُعامل صفرًا.
- مبلغ التمويل حقل يدوي (لا توجد قاعدة موثقة في الملف الأصلي لاحتسابه).
- يُعرض فارقا المبلغ بتسمية واضحة: (التمويل − المطالب به) و(المطالب به − المعتمد).
- تشابه الأسماء وحده لا يثبت الهوية — المطابقة اليدوية متاحة دائمًا.

## النسخ الاحتياطي

من صفحة الإعدادات ← النسخ الاحتياطي: إنشاء نسخة (قاعدة البيانات + المرفقات)
واستعادتها. تُنشأ نسخة أمان تلقائيًا قبل أي استعادة.
