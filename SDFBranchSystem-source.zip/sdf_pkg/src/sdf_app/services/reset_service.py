# -*- coding: utf-8 -*-
"""إعادة تهيئة النظام (متطلب 12) — عملية عالية الخطورة، لمدير النظام فقط.

النطاق الدقيق:
- يُمسح: قاعدة البيانات الحالية بكل بياناتها التشغيلية، وملفات المرفقات.
- يبقى خارج المسح: ملفات البرنامج، ومجلد النسخ الاحتياطية backups (وفيه نسخة
  ما قبل التهيئة الموثقة)، وأي ملفات خارج مجلد بيانات التطبيق.
- بعد المسح تُنشأ قاعدة جديدة بالمخطط والبذور الافتراضية (حساب مدير مؤقت
  admin مع إلزام تغيير كلمة المرور عند أول دخول) فيعود الوصول الإداري
  بصورة مقصودة ومُتحكم فيها.

الضمانات: فرض دور المدير من قاعدة البيانات هنا (لا من الواجهة)؛ إنشاء نسخة
احتياطية كاملة والتحقق من سلامة أرشيفها نفسه قبل أي مسح — أي فشل في النسخ
أو التحقق يُجهض العملية كاملة دون لمس أي بيان.
"""
import shutil
import sqlite3
import tempfile
import zipfile
from pathlib import Path
from typing import Optional

from . import backup_service


def _require_admin(conn: sqlite3.Connection, user_id: Optional[int]):
    row = None
    if user_id:
        row = conn.execute("SELECT role, active FROM users WHERE id=?",
                           (user_id,)).fetchone()
    if not row or not row["active"] or row["role"] != "admin":
        raise PermissionError("إعادة تهيئة النظام متاحة لمدير النظام فقط.")


def prepare_reset(conn: sqlite3.Connection, user_id: Optional[int]) -> Path:
    """الخطوة الآمنة: نسخة احتياطية كاملة + تحقق مستقل من أرشيفها.
    لا يمسح شيئًا؛ أي فشل يرفع استثناءً وتبقى البيانات كما هي."""
    _require_admin(conn, user_id)
    zip_path = backup_service.create_backup(
        conn, include_attachments=True, notes="نسخة إلزامية قبل إعادة تهيئة النظام")
    # تحقق مستقل من الأرشيف النهائي نفسه (ما سيُستعاد منه فعليًا عند الحاجة)
    ok = False
    try:
        with tempfile.TemporaryDirectory() as td:
            with zipfile.ZipFile(zip_path) as zf:
                if "sdf.db" in zf.namelist():
                    zf.extract("sdf.db", td)
                    ok = backup_service.verify_backup(Path(td) / "sdf.db")
    except Exception:
        ok = False
    if not ok:
        zip_path.unlink(missing_ok=True)
        raise RuntimeError(
            "فشل التحقق من سلامة النسخة الاحتياطية — أُجهضت إعادة التهيئة "
            "ولم تُمسح أي بيانات.")
    return zip_path


def execute_wipe(db_path: Path, attachments_dir: Path) -> None:
    """المسح الفعلي — يُستدعى فقط بعد إغلاق اتصال قاعدة البيانات وبعد نجاح
    prepare_reset وتأكيد المستخدم الصريح. لا يقترب من مجلد النسخ."""
    db_path = Path(db_path)
    for suffix in ("", "-wal", "-shm"):
        Path(str(db_path) + suffix).unlink(missing_ok=True)
    att = Path(attachments_dir)
    if att.exists():
        for child in att.iterdir():
            if child.is_dir():
                shutil.rmtree(child, ignore_errors=True)
            else:
                child.unlink(missing_ok=True)


def reinitialize(db_path: Path) -> None:
    """إنشاء قاعدة جديدة نظيفة بالمخطط والبذور الافتراضية بعد المسح."""
    from ..database.connection import Database
    from ..database.seeds import seed_all
    db = Database(Path(db_path))
    conn = db.connect()
    seed_all(conn)
    db.close()
