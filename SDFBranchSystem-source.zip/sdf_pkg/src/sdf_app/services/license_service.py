# -*- coding: utf-8 -*-
"""تراخيص الجهات المنفذة (متطلب 10.5 — 2026-10-19).

الترخيص يُدار مع بيانات الجهة المنفذة نفسها (إعدادات/جهات)، وتحتفظ الجهة
بسجل تراخيص متعدد. «الأحدث» = تاريخ النهاية الأعلى، ثم تاريخ البداية الأعلى،
ثم الأحدث إنشاءً. نموذج الملف يعرض أحدث ترخيص ويحفظ نسخة منه في أعمدة
الملف التاريخية (license_issuer/start/end) عند حفظ الملف.
"""
from ..core.validation import parse_date

_ORDER = ("ORDER BY COALESCE(license_end, '') DESC, "
          "COALESCE(license_start, '') DESC, id DESC")


def list_licenses(conn, entity_id: int) -> list:
    return conn.execute(
        f"SELECT * FROM entity_licenses WHERE entity_id=? {_ORDER}",
        (entity_id,)).fetchall()


def latest_license(conn, entity_id: int):
    if not entity_id:
        return None
    return conn.execute(
        f"SELECT * FROM entity_licenses WHERE entity_id=? {_ORDER} LIMIT 1",
        (entity_id,)).fetchone()


def _clean_date(value, label):
    if value in (None, ""):
        return None
    iso, status, _note = parse_date(value)
    if status != "ok":
        raise ValueError(f"{label} غير صالح: «{value}» — الصيغة المتوقعة YYYY-MM-DD.")
    return iso


def add_license(conn, entity_id: int, issuer, start, end) -> int:
    if not entity_id:
        raise ValueError("اختر الجهة المنفذة أولًا.")
    start = _clean_date(start, "تاريخ بداية الترخيص")
    end = _clean_date(end, "تاريخ نهاية الترخيص")
    if start and end and end < start:
        raise ValueError("تاريخ نهاية الترخيص يسبق تاريخ بدايته.")
    cur = conn.execute(
        "INSERT INTO entity_licenses (entity_id, license_issuer, license_start, license_end)"
        " VALUES (?,?,?,?)",
        (entity_id, (issuer or "").strip() or None, start, end))
    conn.commit()
    return cur.lastrowid


def delete_license(conn, license_id: int):
    conn.execute("DELETE FROM entity_licenses WHERE id=?", (license_id,))
    conn.commit()
