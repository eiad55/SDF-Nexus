# -*- coding: utf-8 -*-
"""النسخ الاحتياطي والاستعادة: نسخ آمن عبر SQLite backup API + أرشفة المرفقات."""
import os
import shutil
import sqlite3
import zipfile
from datetime import datetime
from pathlib import Path, PurePosixPath
from typing import Optional

from .. import config


def create_backup(conn: sqlite3.Connection, include_attachments: bool = True,
                  dest_dir: Optional[Path] = None,
                  notes: str = "") -> Path:
    """إنشاء نسخة احتياطية. يعيد مسار ملف الـ zip."""
    dest_dir = Path(dest_dir) if dest_dir else config.backups_dir()
    dest_dir.mkdir(parents=True, exist_ok=True)
    base = datetime.now().strftime("%Y%m%d_%H%M%S")
    stamp, n = base, 1
    while (dest_dir / f"sdf_backup_{stamp}.zip").exists() or (dest_dir / f"sdf_{stamp}.db").exists():
        stamp = f"{base}_{n}"  # نسختان في الثانية نفسها: لا تكتب إحداهما فوق الأخرى
        n += 1
    tmp_db = dest_dir / f"sdf_{stamp}.db"
    try:
        # نسخ آمن أثناء العمل عبر backup API
        target = sqlite3.connect(str(tmp_db))
        with target:
            conn.backup(target)
        target.close()
        if not verify_backup(tmp_db):
            raise RuntimeError("فشل التحقق من سلامة النسخة الاحتياطية.")
        zip_path = dest_dir / f"sdf_backup_{stamp}.zip"
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(tmp_db, arcname="sdf.db")
            if include_attachments:
                att = config.attachments_dir()
                if att.exists():
                    for f in att.rglob("*"):
                        if f.is_file():
                            zf.write(f, arcname=str(Path("attachments") / f.relative_to(att)))
        # تحقق ما بعد الكتابة: سلامة CRC للأرشيف كله + فحص القاعدة المستخرجة
        # منه فعليًا — نسخة لا تُقرأ لا قيمة لها مهما سلمت قبل الأرشفة.
        if not verify_archive(zip_path):
            zip_path.unlink(missing_ok=True)
            raise RuntimeError("فشل التحقق من سلامة أرشيف النسخة الاحتياطية بعد كتابته.")
        conn.execute(
            "INSERT INTO backup_history (path, size_bytes, includes_attachments, verified, notes)"
            " VALUES (?,?,?,?,?)",
            (str(zip_path), zip_path.stat().st_size, int(include_attachments), 1, notes))
        conn.commit()
        return zip_path
    finally:
        if tmp_db.exists():
            tmp_db.unlink()


def _integrity_ok(conn: sqlite3.Connection) -> bool:
    """نتيجة PRAGMA quick_check يجب أن تكون «ok» وحدها (كانت تُهمل فلا يُكشف التلف)."""
    rows = conn.execute("PRAGMA quick_check").fetchall()
    return len(rows) == 1 and str(rows[0][0]).strip().lower() == "ok"


def verify_backup(db_path: Path) -> bool:
    """التحقق من سلامة نسخة: فتح + فحص سلامة فعلي + وجود الجداول الأساسية."""
    try:
        conn = sqlite3.connect(str(db_path))
        try:
            if not _integrity_ok(conn):
                return False
            tables = {r[0] for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'")}
        finally:
            conn.close()
        return {"training_files", "users", "file_statuses"} <= tables
    except Exception:
        return False


def verify_archive(zip_path: Path) -> bool:
    """تحقق كامل من أرشيف نسخة مكتوب: CRC كل عنصر + سلامة القاعدة داخله."""
    try:
        with zipfile.ZipFile(zip_path) as zf:
            if zf.testzip() is not None:
                return False
            if "sdf.db" not in zf.namelist():
                return False
            data = zf.read("sdf.db")
        tmp = Path(zip_path).with_suffix(".verify.db")
        try:
            tmp.write_bytes(data)
            return verify_backup(tmp)
        finally:
            tmp.unlink(missing_ok=True)
    except Exception:
        return False


def _attachment_target(att_dir: Path, member: str) -> Optional[Path]:
    """يحوّل اسم عنصر في الأرشيف إلى مسار داخل مجلد المرفقات.

    يعيد None لما ليس مرفقًا (قاعدة البيانات، المجلدات)، ويرفع ValueError لأي مسار غير آمن
    (مطلق، أو فيه «..»، أو حرف قرص) حتى لا تكتب الاستعادة خارج مجلد المرفقات (Zip Slip)."""
    name = member.replace("\\", "/")
    if name == "sdf.db" or name.endswith("/"):
        return None
    parts = PurePosixPath(name).parts
    unsafe = (name.startswith("/") or ".." in parts
              or any(":" in p for p in parts[:1]))
    if unsafe:
        raise ValueError(f"الأرشيف يحتوي مسارًا غير آمن ورُفضت الاستعادة: {member}")
    if len(parts) < 2 or parts[0] != "attachments":
        return None
    base = att_dir.resolve()
    target = base.joinpath(*parts[1:]).resolve()
    if base not in target.parents:
        raise ValueError(f"الأرشيف يحتوي مسارًا غير آمن ورُفضت الاستعادة: {member}")
    return target


def restore_backup(zip_path: Path, confirm: bool = False, database=None,
                   actor: Optional[dict] = None) -> Path:
    """
    استعادة نسخة احتياطية. تتطلب confirm=True صراحةً (حماية من الاستبدال غير المقصود).

    - يُتحقق من الأرشيف كله (سلامة القاعدة + أمان كل مسارات المرفقات) قبل أي تغيير.
    - database: كائن Database المفتوح؛ يُغلق (فيُفرغ WAL) قبل الاستبدال، وتُحذف ملفات
      -wal/-shm القديمة حتى لا تُعاد عملياتها فوق القاعدة المستعادة. بعد الاستعادة يجب
      إعادة تشغيل البرنامج (أي اتصال قديم لا يصلح للاستخدام).
    - الاستبدال ذرّي (نسخ بجوار الهدف ثم os.replace).
    - actor (قاموس فيه id وusername) يُسجَّل قيد «backup.restore» داخل القاعدة المستعادة.
    - النسخة الاحتياطية للوضع الحالي قبل الاستعادة مسؤولية المتصل (تفعلها شاشة الإعدادات).
    """
    if not confirm:
        raise PermissionError("الاستعادة تتطلب تأكيدًا صريحًا (confirm=True).")
    zip_path = Path(zip_path)
    if not zipfile.is_zipfile(zip_path):
        raise ValueError("ملف النسخة الاحتياطية غير صالح.")
    att_dir = config.attachments_dir()
    backups = config.backups_dir()
    backups.mkdir(parents=True, exist_ok=True)
    tmp = backups / "_restore_check.db"
    with zipfile.ZipFile(zip_path) as zf:
        names = zf.namelist()
        if "sdf.db" not in names:
            raise ValueError("الأرشيف لا يحتوي على قاعدة البيانات (sdf.db).")
        # فحص كل المسارات أولًا: أي مسار غير آمن يُجهض الاستعادة قبل لمس أي ملف
        plan = []
        for m in names:
            target = _attachment_target(att_dir, m)
            if target is not None:
                plan.append((m, target))
        with zf.open("sdf.db") as src, open(tmp, "wb") as dst:
            shutil.copyfileobj(src, dst)
    if not verify_backup(tmp):
        tmp.unlink(missing_ok=True)
        raise ValueError("فشل التحقق من سلامة النسخة — أُجهضت الاستعادة.")
    db_target = config.db_path()
    db_target.parent.mkdir(parents=True, exist_ok=True)
    if database is not None:
        database.close()
    for suffix in ("-wal", "-shm"):
        Path(str(db_target) + suffix).unlink(missing_ok=True)
    staged = db_target.with_name(db_target.name + ".restoring")
    shutil.copy2(tmp, staged)
    os.replace(staged, db_target)
    tmp.unlink(missing_ok=True)
    if plan:
        att_dir.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(zip_path) as zf:
            for member, target in plan:
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(member) as src, open(target, "wb") as dst:
                    shutil.copyfileobj(src, dst)
    _audit_restore(db_target, actor, zip_path)
    return db_target


def _audit_restore(db_path: Path, actor: Optional[dict], zip_path: Path):
    """قيد تدقيق داخل القاعدة المستعادة (القيد السابق للاستعادة يضيع مع القاعدة القديمة)."""
    try:
        conn = sqlite3.connect(str(db_path))
        try:
            conn.execute(
                "INSERT INTO audit_log (user_id, username, action, entity, details)"
                " VALUES (?,?,?,?,?)",
                ((actor or {}).get("id"), (actor or {}).get("username"), "backup.restore",
                 "backup", f"استعادة نسخة احتياطية: {Path(zip_path).name}"))
            conn.commit()
        finally:
            conn.close()
    except Exception:
        pass  # قيد التدقيق لا يجوز أن يُفشل استعادة نجحت


def cleanup_old_backups(conn: sqlite3.Connection, keep: int = 10):
    """الاحتفاظ بآخر N نسخ وحذف الأقدم."""
    rows = conn.execute("SELECT id, path FROM backup_history ORDER BY created_at DESC").fetchall()
    for r in rows[keep:]:
        p = Path(r["path"])
        if p.exists():
            p.unlink()
        conn.execute("DELETE FROM backup_history WHERE id=?", (r["id"],))
    conn.commit()
