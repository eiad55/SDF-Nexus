# -*- coding: utf-8 -*-
"""سير عمل الملف: الحالات، الانتقالات المسموحة، وشروط الاعتماد."""

# (الرمز، الاسم، نهائية؟)
STATUSES = [
    ("new", "ملف جديد", 0),
    ("received", "مستلم من الفرع", 0),
    ("tech_review", "قيد المراجعة الفنية", 0),
    ("missing_docs", "توجد نواقص", 0),
    ("returned", "معاد للاستكمال", 0),
    ("tech_done", "مكتمل فنيًا", 0),
    ("finance_review", "قيد المراجعة المالية", 0),
    ("ready_approve", "جاهز للاعتماد", 0),
    ("approved", "معتمد", 1),
    ("ready_disburse", "جاهزة للصرف", 0),
    ("disbursing", "قيد الصرف", 0),
    ("disbursed", "منصرفة", 1),
    ("rejected", "مرفوض", 1),
    ("archived", "مغلق ومؤرشف", 1),
]

STATUS_NAMES = {code: name for code, name, _ in STATUSES}
TERMINAL = {code for code, _, t in STATUSES if t}

# الانتقالات المنطقية المسموحة
TRANSITIONS = [
    ("new", "received"),
    ("new", "rejected"),
    ("received", "tech_review"),
    ("received", "returned"),
    ("received", "rejected"),
    ("tech_review", "missing_docs"),
    ("tech_review", "tech_done"),
    ("tech_review", "returned"),
    ("tech_review", "rejected"),
    ("missing_docs", "tech_review"),
    ("missing_docs", "returned"),
    ("returned", "received"),
    ("returned", "tech_review"),
    ("tech_done", "finance_review"),
    ("tech_done", "returned"),
    ("finance_review", "ready_approve"),
    ("finance_review", "returned"),
    ("finance_review", "tech_review"),
    ("ready_approve", "approved"),
    ("ready_approve", "rejected"),
    ("ready_approve", "finance_review"),
    ("approved", "ready_disburse"),
    ("approved", "archived"),
    ("ready_disburse", "disbursing"),
    ("ready_disburse", "approved"),
    ("disbursing", "disbursed"),
    ("disbursing", "ready_disburse"),
    ("disbursed", "archived"),
    ("rejected", "archived"),
    ("rejected", "received"),
]

_ALLOWED = set(TRANSITIONS)


def can_transition(from_code: str, to_code: str) -> bool:
    """هل الانتقال بين الحالتين منطقي ومسموح؟"""
    if from_code == to_code:
        return False
    return (from_code, to_code) in _ALLOWED


def next_statuses(from_code: str):
    """الحالات المسموح الانتقال إليها من حالة معينة."""
    return [to_code for fc, to_code in TRANSITIONS if fc == from_code]


# ----------------------------------------------------------------------
# شروط الاعتماد — لا يُسمح بالانتقال إلى «معتمد» إلا باستيفائها أو استثناء موثق
# ----------------------------------------------------------------------

REQUIRED_FINANCIAL_FIELDS = [
    ("approved_trainees", "العدد المعتمد للمتدربين"),
    ("approved_cost_per_trainee", "تكلفة المتدرب المعتمدة"),
    ("approved_hours", "عدد الساعات المعتمدة"),
    ("funding_amount", "مبلغ التمويل"),
]


def approval_blockers(file_rec: dict, review_items: list) -> list:
    """
    قائمة موانع الاعتماد. فارغة = جاهز للاعتماد.
    file_rec: قاموس حقول الملف. review_items: قائمة قواميس بنتيجة كل وثيقة.
    """
    blockers = []
    for field, label in REQUIRED_FINANCIAL_FIELDS:
        if file_rec.get(field) in (None, ""):
            blockers.append(f"الحقل المالي الإلزامي غير مكتمل: {label}")
    for item in review_items:
        result = item.get("result")
        name = item.get("document_name", "")
        if result in ("غير مطابق", "غير مكتمل"):
            blockers.append(f"وثيقة تحتاج معالجة: {name} ({result})")
        elif result in ("لم يراجع", None):
            # الوثائق غير المطلوبة أصلًا (غير منطبق) ليست مانعًا
            if item.get("required_default", 1):
                blockers.append(f"وثيقة لم تُراجع بعد: {name}")
    return blockers


# ----------------------------------------------------------------------
# الصلاحيات اللازمة لكل انتقال: يكفي المستخدم أي صلاحية من المجموعة.
# (مدير النظام يملك "*" فينفّذ كل شيء.) أي انتقال غير مذكور هنا يتطلب file.update.
# ----------------------------------------------------------------------
_TECH = ("review.technical",)
_FIN = ("review.financial", "finance.approve")
_TECH_OR_FIN = ("review.technical", "review.financial", "finance.approve")
_DECISION = ("finance.approve", "review.technical")          # الرفض/إعادة الفتح: قرار مراجع
_DISBURSE = ("disburse.manage", "finance.approve")
_DISBURSE_ONLY = ("disburse.manage",)

TRANSITION_PERMISSIONS = {
    ("new", "received"): ("file.update",),
    ("new", "rejected"): _DECISION,
    ("received", "tech_review"): _TECH,
    ("received", "returned"): _TECH,
    ("received", "rejected"): _DECISION,
    ("tech_review", "missing_docs"): _TECH,
    ("tech_review", "tech_done"): _TECH,
    ("tech_review", "returned"): _TECH,
    ("tech_review", "rejected"): _DECISION,
    ("missing_docs", "tech_review"): _TECH,
    ("missing_docs", "returned"): _TECH,
    ("returned", "received"): ("file.update",),
    ("returned", "tech_review"): _TECH,
    ("tech_done", "finance_review"): _TECH_OR_FIN,
    ("tech_done", "returned"): _TECH_OR_FIN,
    ("finance_review", "ready_approve"): _FIN,
    ("finance_review", "returned"): _FIN,
    ("finance_review", "tech_review"): _TECH_OR_FIN,
    ("ready_approve", "approved"): ("finance.approve",),
    ("ready_approve", "rejected"): ("finance.approve",),
    ("ready_approve", "finance_review"): _FIN,
    ("approved", "ready_disburse"): _DISBURSE,
    ("approved", "archived"): _DISBURSE,
    ("ready_disburse", "disbursing"): _DISBURSE_ONLY,
    ("ready_disburse", "approved"): _DISBURSE,
    ("disbursing", "disbursed"): _DISBURSE_ONLY,
    ("disbursing", "ready_disburse"): _DISBURSE_ONLY,
    ("disbursed", "archived"): _DISBURSE,
    ("rejected", "archived"): _DECISION,
    ("rejected", "received"): _DECISION,
}


def required_permissions(from_code: str, to_code: str) -> tuple:
    """الصلاحيات التي يكفي واحدة منها لتنفيذ الانتقال."""
    return TRANSITION_PERMISSIONS.get((from_code, to_code), ("file.update",))


def next_statuses_for(from_code: str, can) -> list:
    """الحالات التالية التي يستطيع المستخدم الانتقال إليها. can(permission) -> bool."""
    return [to for to in next_statuses(from_code)
            if any(can(p) for p in required_permissions(from_code, to))]


# حالات ما بعد الاعتماد: الحقول المالية فيها مقفلة إلا بتعديل موثق (انظر FileService.update)
LOCKED_STATUSES = {"approved", "ready_disburse", "disbursing", "disbursed", "archived"}
