# -*- coding: utf-8 -*-
"""تقارير Excel الإضافية: مجمعة حسب الفرع/الجهة/المجال/الفترة/المتأخرة/الحركة."""
from datetime import date, timedelta
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill

from ..core.finance import format_money, summarize

HEADER_FILL = PatternFill("solid", fgColor="1F3A5F")
HEADER_FONT = Font(name="Segoe UI", bold=True, color="FFFFFF", size=11)


def _base_wb(title: str, headers: list, meta: dict = None):
    wb = Workbook()
    ws = wb.active
    ws.title = "التقرير"
    ws.sheet_view.rightToLeft = True
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(headers))
    c = ws.cell(row=1, column=1, value=title)
    c.font = Font(name="Segoe UI", bold=True, size=14, color="1F3A5F")
    c.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 28
    for j, h in enumerate(headers, 1):
        cell = ws.cell(row=2, column=j, value=h)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[2].height = 30
    ws.freeze_panes = "A3"
    if meta:
        ws2 = wb.create_sheet("معلومات")
        ws2.sheet_view.rightToLeft = True
        for i, (k, v) in enumerate(meta.items(), 1):
            ws2.cell(row=i, column=1, value=k).font = Font(bold=True)
            ws2.cell(row=i, column=2, value=v)
    return wb, ws


def _finish(wb, ws, path: Path, widths=None):
    if widths:
        from openpyxl.utils import get_column_letter
        for j, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(j)].width = w
    path = Path(path)
    wb.save(path)
    return path


def _rows_with_finance(conn, where="1=1", params=()):
    from ..services.file_service import JOIN_SQL
    rows = conn.execute(JOIN_SQL + f" WHERE {where} ORDER BY f.file_number", params).fetchall()
    out = []
    for r in rows:
        rec = dict(r)
        rec.update(summarize(rec))
        out.append(rec)
    return out


# تعبيرات رقمية قابلة للترشيح — تكلفة الفرد والإجمالي بالريال دائمًا كما في
# finance.summarize (عقود الدولار تُحوَّل بسعر الصرف المخزن؛ بلا سعر صرف تصبح
# القيمة NULL فلا تطابق أي مقارنة، وهو الصواب)
_YER_RATE = "CASE WHEN f.cost_currency='USD' THEN f.exchange_rate ELSE 1 END"
NUMERIC_EXPR = {
    "trainees": "f.contract_trainees",
    "cost_per": f"(f.contract_cost_per_trainee * {_YER_RATE})",
    "total": f"(f.contract_trainees * f.contract_cost_per_trainee * {_YER_RATE})",
    "hours": "f.contract_hours",
}
NUMERIC_OPS = (">", "<", "=")


def _extra_where(filters):
    """شروط إضافية من فلاتر التقارير: الجهات/المجال + معايير متطلب 9 الثمانية
    (تاريخ التنفيذ، تاريخ العقد، أعداد/تكاليف/ساعات بمقارنات، المشرف، المنصرفة)."""
    if not filters:
        return "1=1", ()
    w, p = [], []
    if filters.get("beneficiary_id"):
        w.append("f.beneficiary_id=?")
        p.append(filters["beneficiary_id"])
    if filters.get("implementing_id"):
        w.append("f.implementing_id=?")
        p.append(filters["implementing_id"])
    if filters.get("field_id"):
        w.append("f.field_id=?")
        p.append(filters["field_id"])
    # تاريخ التنفيذ: تطابق بتداخل فترة التنفيذ مع النطاق المطلوب
    if filters.get("exec_from"):
        w.append("f.exec_start IS NOT NULL AND COALESCE(f.exec_end, f.exec_start)>=?")
        p.append(filters["exec_from"])
    if filters.get("exec_to"):
        w.append("f.exec_start IS NOT NULL AND f.exec_start<=?")
        p.append(filters["exec_to"])
    # تاريخ العقد ضمن النطاق
    if filters.get("contract_from"):
        w.append("f.contract_date>=?")
        p.append(filters["contract_from"])
    if filters.get("contract_to"):
        w.append("f.contract_date<=?")
        p.append(filters["contract_to"])
    # قواعد رقمية: (حقل، مقارنة، قيمة) — الحقول والمقارنات من قوائم بيضاء فقط
    for field, op, value in filters.get("numeric") or []:
        if field in NUMERIC_EXPR and op in NUMERIC_OPS:
            w.append(f"{NUMERIC_EXPR[field]}{op}?")
            p.append(value)
    # اسم المشرف: من القيم الفعلية المخزنة في الملفات
    if filters.get("supervisor"):
        w.append("f.supervisor_name=?")
        p.append(filters["supervisor"])
    # «المنصرفة»: حالة الملف النهائية disbursed
    if filters.get("disbursed_only"):
        w.append("f.status_id IN (SELECT id FROM file_statuses WHERE code='disbursed')")
    return (" AND ".join(w) if w else "1=1"), tuple(p)


def _with_filters(base_where, base_params, filters):
    extra, eparams = _extra_where(filters)
    return f"({base_where}) AND ({extra})", tuple(base_params) + eparams


def report_by_period(conn, path, date_from, date_to, filters=None):
    where, params = _with_filters("f.received_date>=? AND f.received_date<=?",
                                  (date_from, date_to), filters)
    rows = _rows_with_finance(conn, where, params)
    wb, ws = _base_wb("تقرير الملفات المستلمة خلال فترة",
                      ["رقم الملف", "تاريخ الاستلام", "الفرع", "البرنامج", "الجهة المستفيدة", "الحالة"],
                      {"الفترة": f"{date_from} إلى {date_to}", "العدد": len(rows)})
    for i, r in enumerate(rows, 3):
        for j, v in enumerate([r["file_number"], r["received_date"], r["branch_name"],
                               r["program_name"], r["beneficiary_name"], r["status_name"]], 1):
            ws.cell(row=i, column=j, value=v)
    return _finish(wb, ws, path, [12, 14, 16, 30, 30, 16])


def report_by_branch(conn, path, filters=None):
    extra, eparams = _extra_where(filters)
    rows = conn.execute(f"""SELECT b.name AS branch, COUNT(f.id) AS c,
                           COALESCE(SUM(f.claimed_amount),0) AS claimed,
                           COALESCE(SUM(f.funding_amount),0) AS funding
                           FROM branches b LEFT JOIN training_files f
                             ON f.branch_id=b.id AND ({extra})
                           GROUP BY b.name ORDER BY c DESC""", eparams).fetchall()
    wb, ws = _base_wb("تقرير الملفات حسب الفرع",
                      ["الفرع", "عدد الملفات", "إجمالي المطالب به", "إجمالي التمويل"])
    for i, r in enumerate(rows, 3):
        ws.cell(row=i, column=1, value=r["branch"] or "غير محدد")
        ws.cell(row=i, column=2, value=r["c"])
        ws.cell(row=i, column=3, value=float(r["claimed"]))
        ws.cell(row=i, column=4, value=float(r["funding"]))
    return _finish(wb, ws, path, [24, 14, 20, 20])


def report_by_beneficiary(conn, path, filters=None):
    extra, eparams = _extra_where({k: v for k, v in (filters or {}).items()
                                   if k in ("implementing_id", "field_id")})
    rows = conn.execute(f"""SELECT e.name AS ben, COUNT(f.id) AS c,
                           COALESCE(SUM(f.funding_amount),0) AS funding
                           FROM entities e LEFT JOIN training_files f
                             ON f.beneficiary_id=e.id AND e.kind='beneficiary' AND ({extra})
                           WHERE e.kind='beneficiary'
                           GROUP BY e.name ORDER BY c DESC""", eparams).fetchall()
    wb, ws = _base_wb("تقرير البرامج حسب الجهة المستفيدة",
                      ["الجهة المستفيدة", "عدد البرامج", "إجمالي التمويل"])
    for i, r in enumerate(rows, 3):
        ws.cell(row=i, column=1, value=r["ben"])
        ws.cell(row=i, column=2, value=r["c"])
        ws.cell(row=i, column=3, value=float(r["funding"]))
    return _finish(wb, ws, path, [40, 14, 20])


def report_by_field(conn, path, filters=None):
    extra, eparams = _extra_where({k: v for k, v in (filters or {}).items()
                                   if k in ("beneficiary_id", "implementing_id")})
    rows = conn.execute(f"""SELECT pf.name AS fld, COUNT(f.id) AS c
                           FROM program_fields pf LEFT JOIN training_files f
                             ON f.field_id=pf.id AND ({extra})
                           GROUP BY pf.name ORDER BY c DESC""", eparams).fetchall()
    wb, ws = _base_wb("تقرير البرامج حسب مجال التدريب", ["المجال", "عدد البرامج"])
    for i, r in enumerate(rows, 3):
        ws.cell(row=i, column=1, value=r["fld"] or "غير محدد")
        ws.cell(row=i, column=2, value=r["c"])
    return _finish(wb, ws, path, [24, 14])


def report_financial(conn, path, filters=None):
    where, params = _with_filters("1=1", (), filters)
    rows = _rows_with_finance(conn, where, params)
    wb, ws = _base_wb("تقرير المطالبات والمبالغ المعتمدة والفروقات",
                      ["رقم الملف", "البرنامج", "المطالب به", "المعتمد الإجمالي",
                       "مبلغ التمويل", "الفارق: التمويل−المطالب", "الفارق: المطالب−المعتمد"])
    for i, r in enumerate(rows, 3):
        vals = [r["file_number"], r["program_name"],
                _f(r["claimed_amount"]), _f(r["approved_total"]), _f(r["funding_amount"]),
                _f(r["diff_funding_claimed"]), _f(r["diff_claimed_approved"])]
        for j, v in enumerate(vals, 1):
            ws.cell(row=i, column=j, value=v)
    return _finish(wb, ws, path, [12, 34, 18, 18, 18, 20, 20])


def _f(v):
    return float(v) if v is not None else None


def report_overdue(conn, path, deadline_days=30, filters=None):
    cutoff = (date.today() - timedelta(days=deadline_days)).isoformat()
    where, params = _with_filters(
        "f.received_date<? AND s.is_terminal=0 AND s.code NOT IN ('approved','disbursed')",
        (cutoff,), filters)
    rows = _rows_with_finance(conn, where, params)
    # ربط الحالة
    rows = [r for r in rows]
    wb, ws = _base_wb("تقرير الملفات المتأخرة",
                      ["رقم الملف", "تاريخ الاستلام", "الفرع", "البرنامج", "الحالة", "أيام التأخير"],
                      {"مدة المراجعة (يوم)": deadline_days, "العدد": len(rows)})
    for i, r in enumerate(rows, 3):
        days = ""
        try:
            days = (date.today() - date.fromisoformat(r["received_date"][:10])).days - deadline_days
        except Exception:
            pass
        for j, v in enumerate([r["file_number"], r["received_date"], r["branch_name"],
                               r["program_name"], r["status_name"], days], 1):
            ws.cell(row=i, column=j, value=v)
    return _finish(wb, ws, path, [12, 14, 16, 34, 18, 14])


def report_complete_vs_missing(conn, path, filters=None):
    where, params = _with_filters("1=1", (), filters)
    rows = _rows_with_finance(conn, where, params)
    complete, missing = [], []
    for r in rows:
        items = conn.execute(
            "SELECT result FROM review_items WHERE file_id=?", (r["id"],)).fetchall()
        results = [x["result"] for x in items]
        if results and all(x in ("مطابق", "غير منطبق") for x in results):
            complete.append(r)
        else:
            missing.append(r)
    wb, ws = _base_wb("تقرير الملفات المكتملة والناقصة",
                      ["رقم الملف", "البرنامج", "الفرع", "التصنيف"],
                      {"مكتملة": len(complete), "ناقصة/غير مراجعة": len(missing)})
    i = 3
    for r in complete:
        for j, v in enumerate([r["file_number"], r["program_name"], r["branch_name"], "مكتملة"], 1):
            ws.cell(row=i, column=j, value=v)
        i += 1
    for r in missing:
        for j, v in enumerate([r["file_number"], r["program_name"], r["branch_name"], "ناقصة"], 1):
            ws.cell(row=i, column=j, value=v)
        i += 1
    return _finish(wb, ws, path, [12, 34, 16, 14])


def report_file_history(conn, path, file_id):
    rows = conn.execute(
        """SELECT h.changed_at, u.full_name, s1.name AS from_name, s2.name AS to_name, h.notes
           FROM file_history h LEFT JOIN users u ON u.id=h.changed_by
           LEFT JOIN file_statuses s1 ON s1.id=h.from_status_id
           LEFT JOIN file_statuses s2 ON s2.id=h.to_status_id
           WHERE h.file_id=? ORDER BY h.changed_at""", (file_id,)).fetchall()
    wb, ws = _base_wb("تقرير حركة الملف وسجل إجراءاته",
                      ["التاريخ", "المستخدم", "من", "إلى", "ملاحظات"])
    for i, r in enumerate(rows, 3):
        for j, v in enumerate([r["changed_at"], r["full_name"], r["from_name"], r["to_name"], r["notes"]], 1):
            ws.cell(row=i, column=j, value=v)
    return _finish(wb, ws, path, [18, 20, 20, 20, 40])
