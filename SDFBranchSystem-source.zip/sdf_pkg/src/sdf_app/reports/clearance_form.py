# -*- coding: utf-8 -*-
"""استمارة التسميح: يصدرها الفرع لكل جهة مستفيدة تابعة له.

تُظهر: مبلغ مساهمات الجهة، رصيدها التدريبي، المتبقي من الرصيد حتى الملف السابق
للجهة، والمتبقي من الرصيد بعد هذا البرنامج — مع رقم متسلسل لبرامج الجهة في العام نفسه.
"""
from datetime import datetime
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, Spacer, Table, TableStyle

from ..core.finance import format_money
from .pdf_base import FormDocTemplate, ar, make_styles

NAVY = colors.HexColor("#1F3A5F")
LIGHT = colors.HexColor("#F2F4F7")
BORDER = colors.HexColor("#9AA3B2")
W = 182 * mm


def build_clearance_form(rec: dict, balance: dict, output_path,
                         settings: dict = None) -> Path:
    """rec: سجل الملف. balance: ناتج contribution_service.balance_before_file."""
    settings = settings or {}
    styles = make_styles()
    output_path = Path(output_path)
    doc = FormDocTemplate(str(output_path), file_number=rec.get("file_number"),
                          print_date=datetime.now().strftime("%Y-%m-%d"))
    story = []
    story.append(Paragraph(ar("الجمهورية اليمنية"), styles["subtitle"]))
    story.append(Paragraph(ar(settings.get("org_name", "صندوق تنمية المهارات")), styles["title"]))
    story.append(Paragraph(ar(settings.get("office_name", "مكتب النائب لشؤون الفروع")),
                           styles["subtitle"]))
    story.append(Spacer(1, 3 * mm))
    story.append(Paragraph(ar("استمارة تسميح برنامج تدريبي"), styles["title"]))
    story.append(Spacer(1, 2 * mm))

    year = balance.get("year")
    meta = [
        ("الفرع", rec.get("branch_name")),
        ("الجهة المستفيدة", rec.get("beneficiary_name")),
        ("الرقم التسلسلي لبرامج الجهة للعام", f"{balance.get('entity_year_serial')} / {year}"),
        ("رقم الملف", rec.get("file_number")),
        ("رقم الملف لدى الفرع", rec.get("branch_file_number")),
        ("رقم التسميح", rec.get("clearance_number")),
        ("اسم البرنامج", rec.get("program_name")),
        ("تاريخ التنفيذ", f"من {rec.get('exec_start') or '—'} إلى {rec.get('exec_end') or '—'}"),
    ]
    data = []
    for label, val in meta:
        data.append([Paragraph(ar(str(val) if val not in (None, "") else "—"), styles["cell"]),
                     Paragraph(ar(label), styles["cell_bold"])])
    t = Table(data, colWidths=[W - 55 * mm, 55 * mm])
    t.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (0, 0), (-1, -1), "RIGHT"),
        ("GRID", (0, 0), (-1, -1), 0.6, BORDER),
        ("BACKGROUND", (1, 0), (1, -1), LIGHT),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    story.append(t)
    story.append(Spacer(1, 4 * mm))

    story.append(Paragraph(ar("الوضع المالي للجهة"), styles["cell_bold"]))
    story.append(Spacer(1, 2 * mm))
    funding = float(rec.get("funding_amount") or 0)
    remaining_after = balance["remaining_before_file"] - funding
    fin_rows = [
        ("مبلغ مساهمات الجهة للعام", format_money(balance["contributions"])),
        ("نسبة رصيد التدريب", f"{balance['rate'] * 100:.0f}%"),
        ("رصيد التدريب", format_money(balance["training_balance"])),
        ("مرحّل من العام السابق (استثناء)", format_money(balance["carried_from_previous"])),
        ("المستخدم من الرصيد حتى الملف السابق", format_money(balance["used_before_file"])),
        ("المتبقي من الرصيد حتى الملف السابق", format_money(balance["remaining_before_file"])),
        ("مبلغ تمويل هذا البرنامج", format_money(funding)),
        ("المتبقي من الرصيد بعد هذا البرنامج", format_money(remaining_after)),
    ]
    fdata = []
    for label, val in fin_rows:
        fdata.append([Paragraph(ar(val), styles["cell"]),
                      Paragraph(ar(label), styles["cell_bold"])])
    ft = Table(fdata, colWidths=[W - 70 * mm, 70 * mm])
    ft.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (0, 0), (-1, -1), "RIGHT"),
        ("GRID", (0, 0), (-1, -1), 0.6, BORDER),
        ("BACKGROUND", (1, 0), (1, -1), LIGHT),
        ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#FFF8E1")),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    story.append(ft)
    story.append(Spacer(1, 6 * mm))
    story.append(Paragraph(ar("يُصدر هذا التسميح من الفرع للجهة المستفيدة التابعة له، "
                              "ولا يُعد التزامًا نهائيًا بمبلغ التمويل."), styles["small"]))
    story.append(Spacer(1, 8 * mm))
    sig = [[Paragraph(ar("مختص الفرع\nالاسم: ....................\nالتوقيع: ...................."),
                      styles["cell"]),
            Paragraph(ar("مدير الفرع\nالاسم: ....................\nالتوقيع: ...................."),
                      styles["cell"])]]
    st = Table(sig, colWidths=[W / 2, W / 2])
    st.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                            ("ALIGN", (0, 0), (-1, -1), "RIGHT")]))
    story.append(st)
    doc.build(story)
    return output_path
