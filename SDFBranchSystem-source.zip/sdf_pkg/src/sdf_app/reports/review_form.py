# -*- coding: utf-8 -*-
"""
استمارة مراجعة ملف برنامج تدريبي والمصادقة على التمويل — نموذج رقم 3.

صفحة A4 واحدة مطابقة لنموذج دليل الإجراءات: ترويسة، أولًا (البيانات العامة)،
ثانيًا (مطابقة أصول الوثائق — جدولان جنبًا إلى جنب)، ثالثًا (خلاصة المراجعة
الفنية + ملاحظات)، شريط مبلغ التمويل، ثم المذكرتين والتوقيعات.
"""
from datetime import datetime
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.platypus import (BaseDocTemplate, Frame, PageTemplate, Paragraph,
                                Spacer, Table, TableStyle)

from .pdf_base import Checkbox, ar, make_styles, money_ar

NAVY = colors.HexColor("#1F3A5F")
GREEN = colors.HexColor("#D9EAD3")
GREEN_D = colors.HexColor("#38761D")
BORDER = colors.HexColor("#555555")
WHITE = colors.white

PAGE_W, PAGE_H = A4
MARGIN = 8 * mm
W = PAGE_W - 2 * MARGIN  # عرض المحتوى

FS = 7      # حجم الخط الأساسي
FS_H = 8.5  # عناوين الأقسام
FS_T = 11   # عنوان الاستمارة
CELL_PAD = 2
SP1 = 1.2 * mm
SP2 = 2 * mm


def _p(text, style_name, styles, size=None):
    s = styles[style_name]
    t = "—" if text in (None, "") else str(text)
    if size:
        s = s.__class__(s.name, parent=s, fontSize=size, leading=size + 2)
    return Paragraph(ar(t), s)


def _row(label, value, styles, label_w, val_w, size=FS, bg=None):
    """صف (القيمة | التسمية) — التسمية يمينًا بخلفية خضراء فاتحة."""
    row = [_p(value, "cell", styles, size),
           _p(label, "cell_bold", styles, size)]
    t = Table([row], colWidths=[val_w, label_w])
    cmds = [
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (0, 0), (-1, -1), "RIGHT"),
        ("GRID", (0, 0), (-1, -1), 0.5, BORDER),
        ("LEFTPADDING", (0, 0), (-1, -1), CELL_PAD),
        ("RIGHTPADDING", (0, 0), (-1, -1), CELL_PAD),
        ("TOPPADDING", (0, 0), (-1, -1), CELL_PAD),
        ("BOTTOMPADDING", (0, 0), (-1, -1), CELL_PAD),
    ]
    if bg:
        cmds.append(("BACKGROUND", (1, 0), (1, 0), bg))
    t.setStyle(TableStyle(cmds))
    return t


def contract_cost_cell(rec, currency):
    """كلفة المتدرب حسب العقد: العقد بالدولار يُعرض بعملته مع المقابل بالريال،
    ولا يُعرض رقم الدولار على أنه ريال."""
    c = rec.get("contract_cost_per_trainee")
    if c is None:
        return "—"
    if str(rec.get("cost_currency") or "YER").upper() == "USD":
        yer = rec.get("contract_cost_per_trainee_yer")
        if yer is None:
            return f"{money_ar(c, '$')} (سعر الصرف غير مُدخل)"
        return f"{money_ar(c, '$')} ({money_ar(yer, currency)})"
    return money_ar(c, currency)


def _kv_block(pairs, styles, label_w=30 * mm, size=FS):
    """كتلة صفوف متتالية بعرض كامل."""
    val_w = W - label_w
    parts = [_row(l, v, styles, label_w, val_w, size, bg=GREEN) for l, v in pairs]
    return parts


def _match_pair(selected, styles, size=FS):
    """مطابق ☐ / غير مطابق ☐ — المحدد معلَّم."""
    cells = []
    for opt in ("مطابق", "غير مطابق"):
        inner = Table(
            [[Checkbox(checked=(selected == opt), size=2.8 * mm),
              _p(opt, "cell", styles, size)]],
            colWidths=[5 * mm, None])
        inner.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                                   ("LEFTPADDING", (0, 0), (-1, -1), 1),
                                   ("RIGHTPADDING", (0, 0), (-1, -1), 1)]))
        cells.append(inner)
    t = Table([[cells[1], cells[0]]])  # غير مطابق يمينًا كما في النموذج
    t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
    return t


def _section(text, styles):
    return Paragraph(ar(text), styles["section"])


def _group_header(text, styles, width):
    p = _p(text, "cell_bold", styles, FS)
    t = Table([[p]], colWidths=[width])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), GREEN),
        ("BOX", (0, 0), (-1, -1), 0.5, BORDER),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("LEFTPADDING", (0, 0), (-1, -1), CELL_PAD),
        ("TOPPADDING", (0, 0), (-1, -1), CELL_PAD),
        ("BOTTOMPADDING", (0, 0), (-1, -1), CELL_PAD),
    ]))
    return t


def build_review_form(rec: dict, review_items: list, output_path: Path,
                      settings: dict = None, print_date: str = None,
                      draft: bool = False) -> Path:
    settings = settings or {}
    styles = make_styles()
    # تصغير الخطوط لتناسب الصفحة الواحدة
    for st_name in ("cell", "cell_bold", "cell_center", "small", "normal", "memo"):
        if st_name in styles:
            styles[st_name].fontSize = FS
            styles[st_name].leading = FS + 2.5
    styles["section"].fontSize = FS_H
    styles["section"].leading = FS_H + 3
    styles["title"].fontSize = FS_T
    styles["title"].leading = FS_T + 4
    styles["subtitle"].fontSize = 9

    currency = settings.get("currency", "ر.ي")
    print_date = print_date or datetime.now().strftime("%Y-%m-%d")
    output_path = Path(output_path)

    doc = BaseDocTemplate(str(output_path), pagesize=A4,
                          leftMargin=MARGIN, rightMargin=MARGIN,
                          topMargin=MARGIN, bottomMargin=MARGIN,
                          showBoundary=0)
    frame = Frame(MARGIN, MARGIN, W, PAGE_H - 2 * MARGIN, id="f")
    doc.addPageTemplates([PageTemplate(id="p", frames=[frame])])

    story = []
    add = story.append

    # -- الترويسة ------------------------------------------------------------
    hdr_data = [
        [_p(f"( {print_date} )", "cell", styles), _p("التاريخ", "cell_bold", styles),
         _p("الجمهورية اليمنية", "cell_bold", styles, 9)],
        [_p(f"( {rec.get('file_number') or ''} )", "cell", styles), _p("رقم الملف", "cell_bold", styles),
         _p(settings.get("org_name", "صندوق تنمية المهارات"), "cell_bold", styles, 9)],
        [_p(f"( {rec.get('branch_file_number') or ''} )", "cell", styles),
         _p("رقم الملف بالفرع", "cell_bold", styles),
         _p(settings.get("office_name", "مكتب النائب لشؤون الفروع"), "cell_bold", styles, 9)],
    ]
    hdr = Table(hdr_data, colWidths=[55 * mm, 30 * mm, W - 85 * mm])
    hdr.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (0, 0), (-1, -1), "RIGHT"),
        ("LEFTPADDING", (0, 0), (-1, -1), 2),
        ("RIGHTPADDING", (0, 0), (-1, -1), 2),
        ("TOPPADDING", (0, 0), (-1, -1), 1),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 1),
    ]))
    add(hdr)
    add(Spacer(1, SP1))

    # -- شريط العنوان ----------------------------------------------------------
    title_bar = Table([[Paragraph(ar("استمارة المراجعة الفنية والمصادقة على التمويل"),
                                  styles["title"])]],
                      colWidths=[W])
    title_bar.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), GREEN),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    add(title_bar)
    if draft:
        add(_p("— مسودة مراجعة (بيانات غير مكتملة) —", "small", styles))
    add(Spacer(1, SP1))

    # -- أولًا: البيانات العامة ---------------------------------------------------
    add(_section("أولًا: البيانات العامة للملف", styles))
    lw = 32 * mm
    for label, value in [
        ("الجهة المستفيدة:", rec.get("beneficiary_name")),
        ("الفرع:", rec.get("branch_name")),
        ("اسم البرنامج:", rec.get("program_name")),
        ("الجهة المنفذة:", rec.get("implementing_name")),
        ("مجال البرنامج:", rec.get("program_field")),
        ("تاريخ التنفيذ:", f"من {rec.get('exec_start') or '—'} إلى {rec.get('exec_end') or '—'}"),
    ]:
        add(_row(label, value, styles, lw, W - lw, bg=GREEN))
    add(Spacer(1, SP1))

    # -- ثانيًا: مطابقة أصول الوثائق (جدولان جنبًا إلى جنب) ---------------------------
    add(_section("ثانيًا: مطابقة أصول الوثائق", styles))
    half = W / 2 - 1 * mm

    def _side_table(groups, width):
        parts = []
        for gtitle, pairs in groups:
            parts.append(_group_header(gtitle, styles, width))
            for label, value in pairs:
                if isinstance(value, tuple) and value[0] == "MATCH":
                    row = Table([[value[1], _p(label, "cell_bold", styles, FS)]],
                                colWidths=[width - 30 * mm, 30 * mm])
                    row.setStyle(TableStyle([
                        ("GRID", (0, 0), (-1, -1), 0.5, BORDER),
                        ("BACKGROUND", (1, 0), (1, 0), GREEN),
                        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                        ("ALIGN", (0, 0), (-1, -1), "RIGHT"),
                        ("LEFTPADDING", (0, 0), (-1, -1), CELL_PAD),
                        ("RIGHTPADDING", (0, 0), (-1, -1), CELL_PAD),
                        ("TOPPADDING", (0, 0), (-1, -1), CELL_PAD),
                        ("BOTTOMPADDING", (0, 0), (-1, -1), CELL_PAD),
                    ]))
                    parts.append(row)
                else:
                    parts.append(_row(label, value, styles, 30 * mm, width - 30 * mm, bg=GREEN))
        return parts

    def _m(val):
        return ("MATCH", _match_pair(val, styles))

    right_groups = [
        ("بيانات العقد", [
            ("تاريخ التوقيع:", rec.get("contract_date")),
            ("تاريخ التنفيذ:", f"من {rec.get('exec_start') or '—'} إلى {rec.get('exec_end') or '—'}"),
            ("مدة التنفيذ / ساعة:", rec.get("approved_hours") or rec.get("contract_hours")),
            ("كلفة المتدرب:", money_ar(rec.get("approved_cost_per_trainee"), currency)
             if rec.get("approved_cost_per_trainee") else contract_cost_cell(rec, currency)),
            ("عدد المتدربين:", rec.get("approved_trainees") or rec.get("contract_trainees")),
        ]),
        ("بيانات الترشيح", [
            ("عدد المرشحين:", rec.get("nominees_count")),
            ("تاريخ الترشيح:", rec.get("nomination_date")),
        ]),
        ("كشوفات الحضور", [
            ("تاريخ التنفيذ:", _m(rec.get("attendance_exec_match"))),
            ("عدد المتدربين:", rec.get("attendance_trainees")),
            ("مدة البرنامج:", rec.get("program_duration")),
        ]),
        ("تقرير الاشراف", [
            ("اسم المشرف:", rec.get("supervisor_name")),
            ("مستوى التنفيذ:", rec.get("supervision_level")),
        ]),
    ]
    left_groups = [
        ("سيرة الخبير المنفذ", [
            ("أسم المدرب:", rec.get("trainer_name")),
            ("المؤهل / المجال:", rec.get("trainer_qualification")),
            ("الخبرة:", rec.get("trainer_experience")),
        ]),
        ("الترخيص", [
            ("جهة الإصدار:", rec.get("license_issuer")),
            ("فترة الترخيص:", f"من {rec.get('license_start') or '—'} إلى {rec.get('license_end') or '—'}"),
            ("المجال:", rec.get("implementing_field") or rec.get("program_field")),
        ]),
        ("بيانات الشهادة", [
            ("أسم البرنامج:", _m(rec.get("cert_program_match"))),
            ("تاريخ التنفيذ:", _m(rec.get("cert_exec_match"))),
            ("عدد الشهادات المرفقة:", rec.get("certificates_count")),
        ]),
        ("المادة العلمية", [
            ("مطابقة محتواها:", _m(rec.get("material_match"))),
        ]),
        ("المطالبة", [
            ("تاريخ المطالبة:", rec.get("claim_date")),
            ("المبلغ المطالب به:", money_ar(rec.get("claimed_amount"), currency)),
        ]),
    ]
    right_parts = _side_table(right_groups, half)
    left_parts = _side_table(left_groups, half)
    n = max(len(right_parts), len(left_parts))
    right_parts += [Spacer(1, 0)] * (n - len(right_parts))
    left_parts += [Spacer(1, 0)] * (n - len(left_parts))
    # يمين: بيانات العقد | يسار: سيرة الخبير
    side_rows = [[rp, lp] for rp, lp in zip(right_parts, left_parts)]
    side = Table(side_rows, colWidths=[half, half], spaceBefore=0, spaceAfter=0)
    side.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 1),
        ("RIGHTPADDING", (0, 0), (-1, -1), 1),
        ("TOPPADDING", (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 0.5),
    ]))
    add(side)
    add(Spacer(1, SP1))

    # -- ثالثًا: خلاصة المراجعة الفنية ----------------------------------------------
    add(_section("ثالثًا: خلاصة المراجعة الفنية", styles))
    overall = _overall_match(review_items)
    sum_pairs = [
        ("مطابقة بيانات الوثائق:", overall),
        ("العدد المعتمد للمتدربين:", rec.get("approved_trainees")),
        ("عدد الساعات الفعلية:", rec.get("approved_hours")),
        ("كلفة المتدرب الفعلي:", money_ar(rec.get("approved_cost_per_trainee"), currency)),
        ("التكلفة الاجمالية:", money_ar(rec.get("approved_total"), currency)),
    ]
    sum_w = half
    sum_parts = [_row(l, v, styles, 38 * mm, sum_w - 38 * mm, bg=GREEN) for l, v in sum_pairs]
    notes_box = Table([
        [_p("ملاحظات", "cell_bold", styles)],
        [_p(rec.get("notes") or "", "cell", styles)],
    ], colWidths=[half], rowHeights=[6 * mm, 20 * mm])
    notes_box.setStyle(TableStyle([
        ("GRID", (0, 0), (-1, -1), 0.5, BORDER),
        ("BACKGROUND", (0, 0), (-1, 0), GREEN),
        ("ALIGN", (0, 0), (-1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), CELL_PAD),
        ("RIGHTPADDING", (0, 0), (-1, -1), CELL_PAD),
    ]))
    # دمج أجزاء الملخص في خلية واحدة
    sum_cell = Table([[p] for p in sum_parts], colWidths=[sum_w])
    sum_cell.setStyle(TableStyle([("LEFTPADDING", (0, 0), (-1, -1), 0),
                                  ("RIGHTPADDING", (0, 0), (-1, -1), 2),
                                  ("TOPPADDING", (0, 0), (-1, -1), 0),
                                  ("BOTTOMPADDING", (0, 0), (-1, -1), 0.5)]))
    third = Table([[sum_cell, notes_box]], colWidths=[sum_w, half])
    third.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                               ("LEFTPADDING", (0, 0), (-1, -1), 0),
                               ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
    add(third)
    add(Spacer(1, SP1))

    # -- شريط مبلغ التمويل ------------------------------------------------------------
    fund_bar = Table([
        [_p(money_ar(rec.get("funding_amount"), currency), "cell_bold", styles, 10),
         _p("مبلغ التمويل", "cell_bold", styles, 10)]
    ], colWidths=[50 * mm, W - 50 * mm])
    fund_bar.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), GREEN),
        ("BOX", (0, 0), (-1, -1), 0.7, BORDER),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (0, 0), (-1, -1), "RIGHT"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    add(fund_bar)
    add(Spacer(1, SP2))

    # -- المذكرة الأولى -------------------------------------------------------------------
    add(_p("الأخ / المدير التنفيذي المحترم", "cell_bold", styles))
    add(_p("ترون بعاليه نتائج المراجعة الفنية لملف البرنامج التدريبي الموضح أعلاه. وعليه / يرجى التوجيه "
           "للنائب للشؤون المالية والادارية بأستكمال الإجراءات حسب النظام. وشكرًا،،،",
           "cell", styles))
    add(Spacer(1, SP1))
    sig1 = [(t, settings.get(k, "")) for k, t in SIGNATORIES_MEMO1]
    add(_sig_row(sig1, styles))
    add(Spacer(1, SP2))

    # -- المذكرة الثانية --------------------------------------------------------------------
    add(_p("الأخ / النائب للشؤون المالية والإدارية المحترم", "cell_bold", styles))
    add(_p("يتم استكمال الإجراءات بحسب النظام وبحسب ما تم اعتماده من مكتب النائب لشؤون الفروع.",
           "cell", styles))
    add(Spacer(1, SP1))
    add(_sig_row([("المدير التنفيذي", settings.get("signatory_executive", ""))], styles, cols=4))

    doc.build(story)
    return output_path


def _overall_match(review_items: list) -> str:
    if not review_items:
        return "—"
    results = [it.get("result") for it in review_items]
    if any(r in ("غير مطابق", "غير مكتمل") for r in results):
        return "غير مطابق"
    if any(r in ("لم يراجع", None, "") for r in results):
        return "—"
    return "مطابق"


# الموقّعون على الاستمارة: (مفتاح الإعداد، اللقب الرسمي) — الأسماء تُدار من إعدادات
# النظام (تبويب «إعدادات النظام») وتُحفظ في جدول settings؛ اللقب والترتيب ثابتان.
SIGNATORIES_MEMO1 = [
    ("signatory_tech", "مختص الشؤون الفنية"),
    ("signatory_finance", "مختص الشؤون المالية"),
    ("signatory_office_manager", "مدير مكتب النائب لشؤون الفروع"),
    ("signatory_deputy", "نائب المدير التنفيذي لشؤون الفروع"),
]
SIGNATORY_EXECUTIVE = ("signatory_executive", "المدير التنفيذي")


def _sig_row(pairs, styles, cols=None):
    """pairs: قائمة (اللقب، الاسم من الإعدادات) — اسم فارغ يُبقي سطر الاسم نقطيًا."""
    cols = cols or len(pairs)
    cells = []
    for t, name in pairs:
        name = (name or "").strip()
        name_line = f"الاسم: {name}" if name else "الاسم: ...................."
        cell = Table([
            [_p(t, "cell_bold", styles)],
            [_p(name_line, "cell", styles)],
            [_p("التوقيع: ....................", "cell", styles)],
        ], colWidths=[W / cols - 4 * mm])
        cell.setStyle(TableStyle([
            ("ALIGN", (0, 0), (-1, -1), "RIGHT"),
            ("LEFTPADDING", (0, 0), (-1, -1), 2),
            ("TOPPADDING", (0, 0), (-1, -1), 1),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 1),
        ]))
        cells.append(cell)
    while len(cells) < cols:
        cells.append(Paragraph("", styles["cell"]))
    # ترتيب يمين→يسار
    cells = list(reversed(cells))
    t = Table([cells], colWidths=[W / cols] * cols)
    t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP")]))
    return t
