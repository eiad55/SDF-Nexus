# -*- coding: utf-8 -*-
"""إجراءات جماعية على استمارات المراجعة: دمج نماذج عدة ملفات في PDF واحد.

كل نموذج يُبنى بالمسار نفسه المستعمل للنموذج المفرد (build_review_form
مع علم المسودة من review_summary)، ثم تُدمج الملفات المؤقتة بـ pypdf.
"""
import tempfile
from pathlib import Path

from ..core.review_logic import review_summary
from .review_form import build_review_form


def build_forms_bundle(files_service, settings: dict, file_ids, dest_path) -> Path:
    """يبني نموذج مراجعة لكل ملف محدد ويدمجها في PDF واحد عند dest_path."""
    from pypdf import PdfWriter

    ids = [int(i) for i in file_ids]
    if not ids:
        raise ValueError("لا ملفات محددة.")
    dest_path = Path(dest_path)
    dest_path.parent.mkdir(parents=True, exist_ok=True)
    writer = PdfWriter()
    with tempfile.TemporaryDirectory(prefix="sdf_forms_") as tmp:
        tmp = Path(tmp)
        for n, fid in enumerate(ids, 1):
            rec = files_service.get(fid)
            if not rec:
                continue
            items = [{"document_name": it["document_name"],
                      "result": it["result"], "notes": it["notes"]}
                     for it in files_service.review_items(fid, visible_only=True)]
            summary = (review_summary([{"result": it["result"]} for it in items])
                       if items else {"is_technically_complete": False})
            draft = not summary.get("is_technically_complete", False)
            one = tmp / f"form_{n}_{rec['file_number']}.pdf"
            build_review_form(rec, items, one, settings=settings, draft=draft)
            writer.append(str(one))
        if len(writer.pages) == 0:
            raise ValueError("تعذر بناء أي نموذج للملفات المحددة.")
        with open(dest_path, "wb") as fh:
            writer.write(fh)
    return dest_path
