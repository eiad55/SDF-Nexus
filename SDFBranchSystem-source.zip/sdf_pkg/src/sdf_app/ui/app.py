# -*- coding: utf-8 -*-
"""تهيئة تطبيق Qt: اتجاه RTL، الخط العربي، والتنسيق العام."""
import sys

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import QApplication

from .. import config

STYLESHEET = """
QApplication, QWidget { font-family: "IBM Plex Sans Arabic", "Segoe UI", "Tahoma", "Arial"; }
QMainWindow { background: #F4F6FA; }
#sidebar { background: #1F3A5F; }
#sidebarHeader { background: #18304F; border-bottom: 3px solid #F2B705; }
#sidebarTitle { color: #FFFFFF; font-size: 15px; font-weight: bold; }
#sidebarOrg { color: #C7D3E8; font-size: 12px; }
#sidebar QPushButton {
    color: #DCE4F0; background: transparent; border: none;
    text-align: right; padding: 11px 14px; font-size: 14px;
    border-right: 4px solid transparent; border-radius: 8px; margin: 2px 10px;
}
#sidebar QPushButton:hover { background: #2A4A73; }
#sidebar QPushButton:checked { background: #2A4A73; border-right: 4px solid #F2B705; color: #FFFFFF; font-weight: bold; }
#pageTitle { font-size: 20px; font-weight: bold; color: #1F3A5F; border-bottom: 2px solid #F2B705; padding-bottom: 6px; }
QPushButton[primary="true"] {
    background: #1F3A5F; color: white; border-radius: 6px; padding: 8px 18px; font-size: 13px;
}
QPushButton[primary="true"]:hover { background: #2A4A73; }
QPushButton[primary="true"]:disabled { background: #9AA3B2; }
QPushButton[warn="true"] { background: #C0392B; color: white; border-radius: 6px; padding: 8px 18px; }
QPushButton[ok="true"] { background: #1E7E34; color: white; border-radius: 6px; padding: 8px 18px; }
QLineEdit, QComboBox, QDateEdit, QSpinBox, QDoubleSpinBox, QTextEdit, QPlainTextEdit {
    border: 1px solid #C9D2E0; border-radius: 6px; padding: 7px; font-size: 13px; background: white;
}
/* v2: النص من يمين الحقل في كل الشاشات (البقية عبر rtl_align برمجيًا) */
QLineEdit { qproperty-alignment: AlignRight; }
QLineEdit:focus, QComboBox:focus, QTextEdit:focus { border: 1.5px solid #1F3A5F; }
QTableWidget { background: white; border: 1px solid #D5DCE8; border-radius: 8px;
    gridline-color: #E8EDF4; font-size: 13px; }
QTableWidget::item:selected { background: #D6E4F7; color: #1F3A5F; }
QHeaderView::section { background: #1F3A5F; color: white; padding: 8px; font-size: 13px; border: none; }
QTabWidget::pane { border: 1px solid #D5DCE8; border-radius: 8px; background: white; }
QTabBar::tab { background: #E8EDF4; padding: 10px 22px; margin: 2px; border-radius: 6px; font-size: 13px; }
QTabBar::tab:selected { background: #1F3A5F; color: white; font-weight: bold; }
QGroupBox { border: 1px solid #D5DCE8; border-radius: 8px; margin-top: 12px; font-size: 14px; font-weight: bold; color: #1F3A5F; background: white; }
QGroupBox::title { subcontrol-origin: margin; right: 12px; padding: 2px 8px; }
#statCard { background: white; border: 1px solid #D5DCE8; border-radius: 10px; }
#statSuffix { font-size: 15px; font-weight: bold; color: #5A6B85; }
#chartPanel { background: white; border: 1px solid #D5DCE8; border-radius: 10px; }
#chartTitle { font-size: 14px; font-weight: bold; color: #1F3A5F; }
#statValue { font-size: 26px; font-weight: bold; color: #1F3A5F; }
#statTitle { font-size: 13px; color: #5A6B85; }
#statSub { font-size: 11px; color: #8A97AD; }
QStatusBar { background: #1F3A5F; color: white; }
QMessageBox { font-size: 13px; }
"""


UI_FONT_FAMILY = "IBM Plex Sans Arabic"


def _register_bundled_fonts():
    """تسجيل الخط العربي المضمّن مع البرنامج نفسه (IBM Plex Sans Arabic).

    الاعتماد على خطوط جهاز المستخدم (Segoe UI/Tahoma) جعل عرض النصوص يختلف
    من جهاز لآخر حتى قُصّت حروف في الشريط الجانبي على أجهزة حقيقية؛ الخط
    المضمّن يضمن شكلًا واحدًا ثابتًا على كل الأجهزة.
    """
    from PySide6.QtGui import QFontDatabase
    fonts_dir = config.resource_path("resources", "fonts")
    for name in ("IBMPlexSansArabic-Regular.ttf", "IBMPlexSansArabic-Medium.ttf",
                 "IBMPlexSansArabic-SemiBold.ttf", "IBMPlexSansArabic-Bold.ttf"):
        try:
            QFontDatabase.addApplicationFont(str(fonts_dir / name))
        except Exception:
            pass


def create_app(argv=None) -> QApplication:
    app = QApplication.instance()
    if app is None:
        app = QApplication(argv if argv is not None else sys.argv)
    app.setApplicationName(config.APP_NAME_AR)
    app.setOrganizationName("SkillsDevelopmentFund")
    app.setLayoutDirection(Qt.RightToLeft)
    _register_bundled_fonts()
    font = QFont(UI_FONT_FAMILY, 10)
    font.setStyleHint(QFont.SansSerif)
    app.setFont(font)
    app.setStyleSheet(STYLESHEET)
    return app
