# -*- coding: utf-8 -*-
"""ودجات مشتركة: بطاقة إحصائية، رسم أعمدة، ومساعدات."""
from PySide6.QtCore import Qt, QObject, Signal, QRect
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import (QComboBox, QDoubleSpinBox, QFrame, QHBoxLayout,
                               QLabel, QLineEdit, QPlainTextEdit, QSizePolicy,
                               QSpinBox, QTextEdit, QToolButton, QVBoxLayout,
                               QWidget)


def rtl_align(container):
    """محاذاة كل حقول الإدخال داخل حاوية إلى اليمين (متطلب v2: النص من يمين الحقل)."""
    for cls in (QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QDoubleSpinBox):
        for w in container.findChildren(cls):
            try:
                w.setAlignment(Qt.AlignRight)
            except Exception:
                pass
    for cb in container.findChildren(QComboBox):
        try:
            if cb.isEditable() and cb.lineEdit():
                cb.lineEdit().setAlignment(Qt.AlignRight)
        except Exception:
            pass


class StatCard(QFrame):
    """بطاقة مؤشر قابلة للنقر — تنقل لملفات المؤشر عند النقر."""
    clicked = Signal(str)

    def __init__(self, key: str, title: str, parent=None):
        super().__init__(parent)
        self._key = key
        self.setObjectName("statCard")
        self.setCursor(Qt.PointingHandCursor)
        # ارتفاع محكوم بالمحتوى: لا تتمدد البطاقة عموديًا فتتناثر عناصرها
        self.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)
        self.setMinimumHeight(96)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(2)
        self.title_lbl = QLabel(title)
        self.title_lbl.setObjectName("statTitle")
        self.title_lbl.setAlignment(Qt.AlignRight)
        self.title_lbl.setWordWrap(True)  # عناوين طويلة تلتف بدل أن تُقصّ بصمت
        # صف القيمة: قيمة + لاحقة اختيارية (عملة) في مجموعة واحدة مثبتة يمينًا
        # مهما كان اتجاه النص المختلط (أرقام لاتينية + عربي)
        value_row = QHBoxLayout()
        value_row.setSpacing(6)
        self.value_lbl = QLabel("—")
        self.value_lbl.setObjectName("statValue")
        self.value_lbl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.suffix_lbl = QLabel("")
        self.suffix_lbl.setObjectName("statSuffix")
        self.suffix_lbl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        value_row.addWidget(self.value_lbl)
        value_row.addWidget(self.suffix_lbl)
        value_row.addStretch(1)
        self.sub_lbl = QLabel("")
        self.sub_lbl.setObjectName("statSub")
        self.sub_lbl.setAlignment(Qt.AlignRight)
        self.sub_lbl.setWordWrap(True)
        layout.addWidget(self.title_lbl)
        layout.addLayout(value_row)
        layout.addWidget(self.sub_lbl)
        # شريط تمييز جانبي
        self._accent = QColor("#1F3A5F")

    def set_value(self, value: str, sub: str = "", accent: str = None,
                  suffix: str = ""):
        self.value_lbl.setText(value)
        self.suffix_lbl.setText(suffix)
        self.sub_lbl.setText(sub)
        if accent:
            self._accent = QColor(accent)
            self.update()

    def mousePressEvent(self, event):
        self.clicked.emit(self._key)
        super().mousePressEvent(event)

    def paintEvent(self, event):
        super().paintEvent(event)
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(Qt.NoPen)
        p.setBrush(self._accent)
        # شريط على اليمين (RTL)
        p.drawRoundedRect(self.width() - 6, 8, 6, self.height() - 16, 3, 3)


class BarChart(QWidget):
    """رسم أعمدة أفقي بسيط بـ QPainter — بدون مكتبات خارجية."""

    barClicked = Signal(str)  # يُطلق عند النقر على شريط: التسمية

    def __init__(self, parent=None, bar_color="#1F3A5F", height_per_bar=34):
        super().__init__(parent)
        self._data = []  # [(label, value)]
        self._bar_color = QColor(bar_color)
        self._hpb = height_per_bar
        self._rects = []  # [(QRect, label)]
        self.setMinimumHeight(60)
        self.setCursor(Qt.PointingHandCursor)

    def set_data(self, data):
        self._data = [(str(l), float(v or 0)) for l, v in data]
        self.setMinimumHeight(max(60, len(self._data) * self._hpb + 10))
        self.update()

    def mousePressEvent(self, event):
        for rect, label in self._rects:
            if rect.contains(event.position().toPoint()):
                self.barClicked.emit(label)
                break
        super().mousePressEvent(event)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        self._rects = []
        if not self._data:
            p.drawText(self.rect(), Qt.AlignCenter, "لا توجد بيانات")
            return
        max_v = max((v for _, v in self._data), default=1) or 1
        # عرض التسمية يتكيف مع أطول اسم فعلي (حتى 45% من العرض) بدل ثابت يقصّ الأسماء
        fm0 = p.fontMetrics()
        widest = max((fm0.horizontalAdvance(l) for l, _ in self._data), default=0)
        label_w = max(130, min(widest + 8, int(self.width() * 0.45)))
        val_w = 70
        bar_area = self.width() - label_w - val_w - 20
        y = 8
        fm = p.fontMetrics()
        for label, value in self._data:
            # التسمية يمينًا — تقصير مُتحكم فيه (…) عند الحاجة بدل قصّ صامت
            p.setPen(QColor("#1F3A5F"))
            shown = fm.elidedText(label, Qt.ElideRight, label_w)
            p.drawText(QRect(self.width() - label_w - 8, y, label_w, self._hpb - 8),
                       Qt.AlignRight | Qt.AlignVCenter, shown)
            # مسار خافت بعرض منطقة الرسم كاملة (سياق بصري لكل صف)
            track_x = self.width() - label_w - 12 - max(bar_area, 0)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor("#E8EDF4"))
            if bar_area > 0:
                p.drawRoundedRect(track_x, y + 4, bar_area, self._hpb - 16, 4, 4)
            # الشريط (من اليمين) — القيمة صفر لا ترسم أي عمود (كانت تُرسم بعرض
            # 2px فتظهر كعلامة «|» شاردة بجانب كل تسمية)
            bw = int(bar_area * (value / max_v)) if value > 0 else 0
            if bw > 0:
                x = self.width() - label_w - 12 - bw
                p.setBrush(self._bar_color)
                p.drawRoundedRect(x, y + 4, bw, self._hpb - 16, 4, 4)
            # القيمة يسارًا
            p.setPen(QColor("#5A6B85"))
            p.drawText(QRect(4, y, val_w, self._hpb - 8),
                       Qt.AlignLeft | Qt.AlignVCenter, f"{value:,.0f}")
            self._rects.append((QRect(0, y, self.width(), self._hpb), label))
            y += self._hpb
            if y > self.height():
                break
        _ = fm


class DateField(QWidget):
    """حقل تاريخ قابل للكتابة اليدوية (متطلب 10.1) + زر تقويم.

    الصيغة المعيارية للعرض والتخزين: YYYY-MM-DD. الإدخال اليدوي يقبل صيغًا
    متعددة عبر core.validation.parse_date (ISO، DD/MM/YYYY، أسماء الشهور
    العربية، الأرقام العربية) ويُطبَّع إلى ISO؛ القيمة غير الصالحة ترفع
    ValueError برسالة واضحة بدل ابتلاعها بصمت كما كان يفعل QDateEdit.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(4)
        self.edit = QLineEdit()
        self.edit.setPlaceholderText("YYYY-MM-DD")
        self.edit.setAlignment(Qt.AlignRight)
        btn = QToolButton()
        btn.setText("📅")
        btn.setToolTip("اختيار من التقويم")
        btn.clicked.connect(self._open_calendar)
        lay.addWidget(self.edit, 1)
        lay.addWidget(btn)

    def _open_calendar(self):
        from PySide6.QtWidgets import QCalendarWidget, QDialog, QVBoxLayout
        dlg = QDialog(self)
        dlg.setWindowTitle("اختيار التاريخ")
        lay = QVBoxLayout(dlg)
        cal = QCalendarWidget()
        current = self.iso_or_none()
        if current:
            from PySide6.QtCore import QDate
            d = QDate.fromString(current, "yyyy-MM-dd")
            if d.isValid():
                cal.setSelectedDate(d)
        lay.addWidget(cal)
        cal.clicked.connect(lambda d: (self.edit.setText(d.toString("yyyy-MM-dd")),
                                       dlg.accept()))
        dlg.exec()

    def set_iso(self, value):
        self.edit.setText(str(value)[:10] if value else "")

    def raw_text(self) -> str:
        return self.edit.text().strip()

    def iso_or_none(self):
        """القيمة بصيغة ISO أو None — دون رفع (للاستخدامات العرضية)."""
        from ..core.validation import parse_date
        iso, status, _ = parse_date(self.raw_text() or None)
        return iso if status == "ok" else None

    def iso_value(self, label: str = "التاريخ"):
        """القيمة بصيغة ISO أو None إن كان الحقل فارغًا؛ يرفع ValueError
        برسالة واضحة عند إدخال غير صالح (لا حفظ صامتًا لقيمة خاطئة أبدًا)."""
        from ..core.validation import parse_date
        text = self.raw_text()
        if not text:
            return None
        iso, status, _ = parse_date(text)
        if status != "ok":
            raise ValueError(
                f"تاريخ غير صالح في حقل «{label}»: «{text}».\n"
                "الصيغة المتوقعة: YYYY-MM-DD (مثال: 2026-03-25)، "
                "وتُقبل أيضًا كتابة التاريخ بصيغة DD/MM/YYYY.")
        if text != iso:
            self.edit.setText(iso)  # تطبيع العرض إلى الصيغة المعيارية
        return iso


class _EnterNavFilter(QObject):
    """مرشح Enter للحوارات: ينقل التركيز بدل تفعيل زر الحفظ الافتراضي."""

    def __init__(self, dialog):
        super().__init__(dialog)
        self._dlg = dialog

    def eventFilter(self, obj, event):
        from PySide6.QtCore import QEvent
        from PySide6.QtWidgets import QAbstractButton, QTableWidget
        if event.type() == QEvent.KeyPress and event.key() in (Qt.Key_Return, Qt.Key_Enter):
            fw = self._dlg.focusWidget()
            if fw is not None and fw is not self._dlg:
                if isinstance(fw, (QTextEdit, QAbstractButton)):
                    return False
                if isinstance(fw, QComboBox) and fw.view() is not None \
                        and fw.view().isVisible():
                    return False
                parent = fw.parentWidget()
                while parent is not None:
                    if isinstance(parent, QTableWidget):
                        return False
                    parent = parent.parentWidget()
                self._dlg.focusNextChild()
                return True
        return False


def install_enter_navigation(dialog):
    """يمنع حفظ الحوار بـ Enter ويجعل Enter تنقلًا بين الحقول (كما في نموذج
    الملف، متطلب 10.2) — يُستخدم في حوارات الإدخال المشابهة."""
    from PySide6.QtWidgets import QPushButton
    for b in dialog.findChildren(QPushButton):
        b.setAutoDefault(False)
        b.setDefault(False)
    filt = _EnterNavFilter(dialog)
    dialog.installEventFilter(filt)
    return filt


class QHLine(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.HLine)
        self.setStyleSheet("color: #D5DCE8;")


def labeled_row(label: str, widget: QWidget) -> QHBoxLayout:
    box = QHBoxLayout()
    lbl = QLabel(label)
    lbl.setMinimumWidth(150)
    lbl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    # RTL: أول مُضاف يظهر أقصى اليمين — التسمية أولًا فتقع يمين الحقل
    box.addWidget(lbl, 0)
    box.addWidget(widget, 1)
    return box
