# -*- coding: utf-8 -*-
"""صفحة التقارير والطباعة."""
from datetime import date
from pathlib import Path

from PySide6.QtWidgets import (QCheckBox, QComboBox, QFileDialog, QGridLayout,
                               QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                               QPushButton, QVBoxLayout, QWidget)

from .. import config
from ..reports import excel_reports as er
from ..reports.clearance_form import build_clearance_form
from ..reports.review_form import build_review_form
from ..services import contribution_service as contrib
from .print_preview import PrintPreviewDialog
from .widgets import DateField, rtl_align, TitledPanel, show_error


class ReportsPage(QWidget):
    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        layout = QVBoxLayout(self)

        # -- استمارة المراجعة ------------------------------------------------------
        g0 = TitledPanel("استمارة مراجعة ملف برنامج تدريبي والمصادقة على التمويل")
        l0 = QHBoxLayout(g0.content)
        self.form_number = QLineEdit()
        self.form_number.setPlaceholderText("رقم الملف")
        btn_preview = QPushButton("معاينة قبل الطباعة")
        btn_preview.setProperty("primary", True)
        btn_preview.clicked.connect(self._preview_form)
        btn_pdf = QPushButton("حفظ PDF مباشرة")
        btn_pdf.clicked.connect(self._save_form_pdf)
        l0.addWidget(QLabel("رقم الملف:"))
        l0.addWidget(self.form_number)
        l0.addWidget(btn_preview)
        l0.addWidget(btn_pdf)
        l0.addStretch(1)
        layout.addWidget(g0)

        # -- التقارير ---------------------------------------------------------------
        g = TitledPanel("التقارير")
        grid = QGridLayout(g.content)
        grid.setSpacing(10)

        # فلاتر التقارير: جهة مستفيدة / جهة منفذة / مجال
        self.rep_benef = QComboBox()
        self.rep_impl = QComboBox()
        self.rep_field = QComboBox()
        grid.addWidget(QLabel("الجهة المستفيدة:"), 0, 4)
        grid.addWidget(self.rep_benef, 0, 5)
        grid.addWidget(QLabel("الجهة المنفذة:"), 0, 2)
        grid.addWidget(self.rep_impl, 0, 3)
        grid.addWidget(QLabel("المجال:"), 0, 0)
        grid.addWidget(self.rep_field, 0, 1)
        self._load_report_filters()

        # فترة للتقارير الزمنية (إدخال يدوي آمن كحقول التواريخ في بقية النظام)
        from datetime import timedelta
        self.date_from = DateField()
        self.date_from.set_iso((date.today() - timedelta(days=30)).isoformat())
        self.date_to = DateField()
        self.date_to.set_iso(date.today().isoformat())
        grid.addWidget(QLabel("من:"), 1, 3)
        grid.addWidget(self.date_from, 1, 4)
        grid.addWidget(QLabel("إلى:"), 1, 1)
        grid.addWidget(self.date_to, 1, 2)

        reports = [
            ("الملفات المستلمة خلال فترة", self._r_period),
            ("الملفات المكتملة والناقصة", self._r_complete),
            ("الملفات حسب الفرع", self._r_branch),
            ("البرامج حسب الجهة المستفيدة", self._r_beneficiary),
            ("البرامج حسب مجال التدريب", self._r_field),
            ("المطالبات والمبالغ المعتمدة والفروقات", self._r_financial),
            ("الملفات المتأخرة", self._r_overdue),
        ]
        for i, (title, fn) in enumerate(reports):
            btn = QPushButton(title)
            btn.clicked.connect(lambda _=False, f=fn, t=title: self._run_excel(f, t))
            grid.addWidget(btn, 2 + i // 2, (i % 2) * 2, 1, 2)
        layout.addWidget(g)

        # -- فلاتر إضافية (متطلب 9): تواريخ التنفيذ/العقد، مقارنات رقمية، المشرف، المنصرفة
        gf = TitledPanel("فلاتر إضافية للتقارير (تعمل منفردة ومجتمعة، وتنعكس على كل التقارير)")
        fl = QVBoxLayout(gf.content)

        def _date_pair(label, w_from, w_to):
            row = QHBoxLayout()
            row.addWidget(QLabel(label))
            row.addWidget(w_from, 1)
            row.addWidget(QLabel("إلى:"))
            row.addWidget(w_to, 1)
            return row

        self.f_exec_from, self.f_exec_to = DateField(), DateField()
        fl.addLayout(_date_pair("تاريخ التنفيذ من:", self.f_exec_from, self.f_exec_to))
        self.f_contract_from, self.f_contract_to = DateField(), DateField()
        fl.addLayout(_date_pair("تاريخ العقد من:", self.f_contract_from, self.f_contract_to))

        self.num_fields = {}
        for key, label in (("trainees", "عدد المتدربين حسب العقد"),
                           ("cost_per", "تكلفة الفرد حسب العقد (بالريال)"),
                           ("total", "التكلفة الإجمالية حسب العقد (بالريال)"),
                           ("hours", "عدد الساعات حسب العقد")):
            row = QHBoxLayout()
            op = QComboBox()
            op.addItems([">", "<", "="])
            val = QLineEdit()
            val.setPlaceholderText("القيمة (فارغ = بدون شرط)")
            row.addWidget(QLabel(label + ":"))
            row.addWidget(op)
            row.addWidget(val, 1)
            fl.addLayout(row)
            self.num_fields[key] = (op, val)

        srow = QHBoxLayout()
        self.rep_supervisor = QComboBox()
        srow.addWidget(QLabel("اسم المشرف:"))
        srow.addWidget(self.rep_supervisor, 1)
        self.rep_disbursed = QCheckBox("المنصرفة فقط (حالة الملف: منصرفة)")
        srow.addWidget(self.rep_disbursed)
        fl.addLayout(srow)

        crow = QHBoxLayout()
        btn_clear_filters = QPushButton("مسح كل الفلاتر")
        btn_clear_filters.clicked.connect(self._clear_filters)
        crow.addWidget(btn_clear_filters)
        crow.addStretch(1)
        fl.addLayout(crow)
        layout.addWidget(gf)
        self._load_report_filters()  # إعادة تحميل تشمل قائمة المشرفين الآن

        # -- استمارة التسميح --------------------------------------------------------------
        g3 = TitledPanel("استمارة التسميح")
        l3 = QHBoxLayout(g3.content)
        self.clear_number = QLineEdit()
        self.clear_number.setPlaceholderText("رقم الملف")
        btn_clear = QPushButton("معاينة استمارة التسميح")
        btn_clear.setProperty("primary", True)
        btn_clear.clicked.connect(self._preview_clearance)
        btn_clear_pdf = QPushButton("حفظ PDF")
        btn_clear_pdf.clicked.connect(self._save_clearance_pdf)
        l3.addWidget(QLabel("رقم الملف:"))
        l3.addWidget(self.clear_number)
        l3.addWidget(btn_clear)
        l3.addWidget(btn_clear_pdf)
        l3.addStretch(1)
        layout.addWidget(g3)

        # -- كشف ملف واحد / حركته -------------------------------------------------------
        g2 = TitledPanel("كشوفات ملف واحد")
        l2 = QHBoxLayout(g2.content)
        self.one_number = QLineEdit()
        self.one_number.setPlaceholderText("رقم الملف")
        btn_detail = QPushButton("كشف تفصيلي Excel")
        btn_detail.clicked.connect(self._r_detail)
        btn_hist = QPushButton("تقرير حركة الملف")
        btn_hist.clicked.connect(self._r_history)
        l2.addWidget(QLabel("رقم الملف:"))
        l2.addWidget(self.one_number)
        l2.addWidget(btn_detail)
        l2.addWidget(btn_hist)
        l2.addStretch(1)
        layout.addWidget(g2)
        layout.addStretch(1)

    # -- استمارة المراجعة --------------------------------------------------------------
    def _load_report_filters(self):
        conn = self.ctx.conn
        for cb, kind in ((self.rep_benef, "beneficiary"), (self.rep_impl, "implementing")):
            cb.clear()
            cb.addItem("الكل", None)
            for r in conn.execute(
                    "SELECT id, name FROM entities WHERE kind=? AND active=1 ORDER BY name", (kind,)):
                cb.addItem(r["name"], r["id"])
        self.rep_field.clear()
        self.rep_field.addItem("الكل", None)
        for r in conn.execute("SELECT id, name FROM program_fields WHERE active=1 ORDER BY name"):
            self.rep_field.addItem(r["name"], r["id"])
        # المشرفون: القيم الفعلية المخزنة في الملفات (لا جدول مرجعيًا للمشرفين)
        if not hasattr(self, "rep_supervisor"):
            return
        self.rep_supervisor.clear()
        self.rep_supervisor.addItem("الكل", None)
        for r in conn.execute(
                "SELECT DISTINCT supervisor_name FROM training_files"
                " WHERE supervisor_name IS NOT NULL AND TRIM(supervisor_name)<>''"
                " ORDER BY supervisor_name"):
            self.rep_supervisor.addItem(r["supervisor_name"], r["supervisor_name"])

    def _report_filters(self):
        """يبني قاموس الفلاتر ويتحقق من القيم — يرفع ValueError برسالة واضحة."""
        numeric = []
        for key, (op, val) in self.num_fields.items():
            text = val.text().strip()
            if not text:
                continue
            try:
                numeric.append((key, op.currentText(), float(text.replace(",", ""))))
            except ValueError:
                raise ValueError(f"قيمة رقمية غير صحيحة في أحد فلاتر الأرقام: «{text}»")
        return {
            "beneficiary_id": self.rep_benef.currentData(),
            "implementing_id": self.rep_impl.currentData(),
            "field_id": self.rep_field.currentData(),
            "exec_from": self.f_exec_from.iso_value("تاريخ التنفيذ من"),
            "exec_to": self.f_exec_to.iso_value("تاريخ التنفيذ إلى"),
            "contract_from": self.f_contract_from.iso_value("تاريخ العقد من"),
            "contract_to": self.f_contract_to.iso_value("تاريخ العقد إلى"),
            "numeric": numeric,
            "supervisor": self.rep_supervisor.currentData(),
            "disbursed_only": self.rep_disbursed.isChecked(),
        }

    def _clear_filters(self):
        """مسح كل الفلاتر (الأساسية والإضافية) وإعادة الصفحة لحالتها الأولى."""
        for cb in (self.rep_benef, self.rep_impl, self.rep_field, self.rep_supervisor):
            cb.setCurrentIndex(0)
        for f in (self.f_exec_from, self.f_exec_to,
                  self.f_contract_from, self.f_contract_to):
            f.set_iso(None)
        for op, val in self.num_fields.values():
            op.setCurrentIndex(0)
            val.clear()
        self.rep_disbursed.setChecked(False)

    def _get_form_record(self):
        try:
            num = int(self.form_number.text().strip())
        except ValueError:
            QMessageBox.warning(self, "تنبيه", "أدخل رقم ملف صحيحًا.")
            return None
        rec = self.ctx.files.get_by_number(num)
        if not rec:
            QMessageBox.warning(self, "تنبيه", f"لا يوجد ملف بالرقم {num}.")
            return None
        return rec

    def _build_form_pdf(self, rec):
        items = [{"document_name": it["document_name"], "result": it["result"], "notes": it["notes"]}
                 for it in self.ctx.files.review_items(rec["id"], visible_only=True)]
        # تنبيه المسودة: بيانات ناقصة أو مراجعة غير مكتملة
        from ..core.review_logic import review_summary
        s = review_summary([{"result": it["result"]} for it in items]) if items else {"is_technically_complete": False}
        draft = not s.get("is_technically_complete", False)
        out = config.exports_dir() / f"استمارة_مراجعة_{rec['file_number']}.pdf"
        build_review_form(rec, items, out, settings=self.ctx.settings(), draft=draft)
        return out, draft

    def _preview_form(self):
        rec = self._get_form_record()
        if not rec:
            return
        try:
            pdf, draft = self._build_form_pdf(rec)
        except Exception as exc:
            show_error(self, "خطأ", exc, "إنشاء الاستمارة")
            return
        dlg = PrintPreviewDialog(pdf, self)
        if draft:
            dlg.set_warning("تنبيه: بيانات الملف أو مراجعته غير مكتملة — تُطبع كمسودة مراجعة.")
        dlg.exec()

    def _save_form_pdf(self):
        rec = self._get_form_record()
        if not rec:
            return
        dest, _ = QFileDialog.getSaveFileName(self, "حفظ الاستمارة PDF",
                                              f"استمارة_مراجعة_{rec['file_number']}.pdf", "PDF (*.pdf)")
        if not dest:
            return
        try:
            pdf, _ = self._build_form_pdf(rec)
            import shutil
            shutil.copy2(pdf, dest)
            QMessageBox.information(self, "تم", "تم حفظ الاستمارة PDF.")
        except Exception as exc:
            show_error(self, "خطأ", exc, "إنشاء الاستمارة")

    def open_form_for_file(self, file_id: int):
        rec = self.ctx.files.get(file_id)
        if rec:
            self.form_number.setText(str(rec["file_number"]))
            self._preview_form()

    # -- تقارير Excel ----------------------------------------------------------------------
    def _ask_path(self, title, default):
        path, _ = QFileDialog.getSaveFileName(self, title, default, "Excel (*.xlsx)")
        return Path(path) if path else None

    def _run_excel(self, fn, title):
        try:
            self._report_filters()  # تحقق مبكر من قيم الفلاتر قبل أي عمل
            self.date_from.iso_value("من")
            self.date_to.iso_value("إلى")
        except ValueError as exc:
            QMessageBox.warning(self, "فلاتر غير صحيحة", str(exc))
            return
        path = self._ask_path(title, f"{title}.xlsx")
        if not path:
            return
        try:
            fn(path)
            QMessageBox.information(self, "تم", f"تم إنشاء التقرير:\n{path}")
        except Exception as exc:
            QMessageBox.critical(self, "خطأ", f"فشل إنشاء التقرير: {exc}")

    def _r_period(self, path):
        er.report_by_period(self.ctx.conn, path,
                            self.date_from.iso_or_none() or "0001-01-01",
                            self.date_to.iso_or_none() or "9999-12-31",
                            filters=self._report_filters())

    def _r_complete(self, path):
        er.report_complete_vs_missing(self.ctx.conn, path, filters=self._report_filters())

    def _r_branch(self, path):
        er.report_by_branch(self.ctx.conn, path, filters=self._report_filters())

    def _r_beneficiary(self, path):
        er.report_by_beneficiary(self.ctx.conn, path, filters=self._report_filters())

    def _r_field(self, path):
        er.report_by_field(self.ctx.conn, path, filters=self._report_filters())

    def _r_financial(self, path):
        er.report_financial(self.ctx.conn, path, filters=self._report_filters())

    def _r_overdue(self, path):
        er.report_overdue(self.ctx.conn, path,
                          int(self.ctx.settings().get("review_deadline_days", 30)),
                          filters=self._report_filters())

    def _file_num_or_warn(self):
        try:
            return int(self.one_number.text().strip())
        except ValueError:
            QMessageBox.warning(self, "تنبيه", "أدخل رقم ملف صحيحًا.")
            return None

    def _r_detail(self):
        num = self._file_num_or_warn()
        if not num:
            return
        rec = self.ctx.files.get_by_number(num)
        if not rec:
            QMessageBox.warning(self, "تنبيه", f"لا يوجد ملف بالرقم {num}.")
            return
        path = self._ask_path("كشف تفصيلي", f"كشف_ملف_{num}.xlsx")
        if not path:
            return
        from ..services.export_service import export_files
        export_files([rec], path, title=f"الكشف التفصيلي للملف رقم {num}")
        QMessageBox.information(self, "تم", "تم إنشاء الكشف التفصيلي.")

    def _r_history(self):
        num = self._file_num_or_warn()
        if not num:
            return
        rec = self.ctx.files.get_by_number(num)
        if not rec:
            QMessageBox.warning(self, "تنبيه", f"لا يوجد ملف بالرقم {num}.")
            return
        path = self._ask_path("تقرير حركة الملف", f"حركة_ملف_{num}.xlsx")
        if not path:
            return
        er.report_file_history(self.ctx.conn, path, rec["id"])
        QMessageBox.information(self, "تم", "تم إنشاء تقرير الحركة.")

    def _clearance_record(self):
        try:
            num = int(self.clear_number.text().strip())
        except ValueError:
            QMessageBox.warning(self, "تنبيه", "أدخل رقم ملف صحيحًا.")
            return None, None
        rec = self.ctx.files.get_by_number(num)
        if not rec:
            QMessageBox.warning(self, "تنبيه", f"لا يوجد ملف بالرقم {num}.")
            return None, None
        if not rec.get("beneficiary_id"):
            QMessageBox.warning(self, "تنبيه", "الملف بلا جهة مستفيدة — لا يمكن إصدار التسميح.")
            return None, None
        year = (rec.get("exec_start") or rec.get("received_date") or "")[:4]
        year = int(year) if year.isdigit() else date.today().year
        bal = contrib.balance_before_file(self.ctx.conn, rec["beneficiary_id"], year,
                                          rec["file_number"])
        return rec, bal

    def _build_clearance_pdf(self, rec, bal):
        out = config.exports_dir() / f"استمارة_تسميح_{rec['file_number']}.pdf"
        build_clearance_form(rec, bal, out, settings=self.ctx.settings())
        return out

    def _preview_clearance(self):
        rec, bal = self._clearance_record()
        if not rec:
            return
        try:
            pdf = self._build_clearance_pdf(rec, bal)
        except Exception as exc:
            show_error(self, "خطأ", exc, "إنشاء الاستمارة")
            return
        PrintPreviewDialog(pdf, self).exec()

    def _save_clearance_pdf(self):
        rec, bal = self._clearance_record()
        if not rec:
            return
        dest, _ = QFileDialog.getSaveFileName(self, "حفظ استمارة التسميح PDF",
                                              f"استمارة_تسميح_{rec['file_number']}.pdf",
                                              "PDF (*.pdf)")
        if not dest:
            return
        try:
            pdf = self._build_clearance_pdf(rec, bal)
            import shutil
            shutil.copy2(pdf, dest)
            QMessageBox.information(self, "تم", "تم حفظ استمارة التسميح PDF.")
        except Exception as exc:
            show_error(self, "خطأ", exc, "إنشاء الاستمارة")

    def refresh(self):
        self._load_report_filters()
        rtl_align(self)
