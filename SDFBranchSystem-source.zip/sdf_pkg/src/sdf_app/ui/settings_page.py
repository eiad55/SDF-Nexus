# -*- coding: utf-8 -*-
"""صفحة الإعدادات: القوائم المرجعية، إعدادات النظام، المستخدمون، النسخ الاحتياطي."""
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QApplication, QComboBox, QFileDialog, QFormLayout, QGroupBox,
                               QHBoxLayout, QLabel, QLineEdit, QListWidget, QMessageBox,
                               QPushButton, QTabWidget, QTableWidgetItem, QVBoxLayout,
                               QWidget, QDialog, QDialogButtonBox, QSpinBox)

from .. import config
from ..services import backup_service
from ..services.auth_service import (ADMIN_PROTECTED, ROLES, change_password, create_user,
                                     has_permission)


class SettingsPage(QWidget):
    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        layout = QVBoxLayout(self)
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)
        self.tabs.addTab(self._tab_lookups(), "القوائم المرجعية")
        self.tabs.addTab(self._tab_trainers(), "المدربون")
        self.tabs.addTab(self._tab_system(), "إعدادات النظام")
        if has_permission(ctx.user, "user.manage", ctx.conn):
            self.tabs.addTab(self._tab_users(), "المستخدمون")
            self.tabs.addTab(self._tab_permissions(), "الصلاحيات")
        if has_permission(ctx.user, "backup", ctx.conn):
            self.tabs.addTab(self._tab_backup(), "النسخ الاحتياطي")

    # -- القوائم ------------------------------------------------------------------
    def _tab_lookups(self):
        w = QWidget()
        l = QVBoxLayout(w)
        row = QHBoxLayout()
        self.lookup_cb = QComboBox()
        self.lookup_cb.addItem("الفروع", ("branches", None))
        self.lookup_cb.addItem("مجالات البرامج", ("program_fields", None))
        self.lookup_cb.addItem("البرامج التدريبية", ("programs", None))
        self.lookup_cb.addItem("الجهات المستفيدة", ("entities", "beneficiary"))
        self.lookup_cb.addItem("الجهات المنفذة", ("entities", "implementing"))
        self.lookup_cb.addItem("أنواع الوثائق", ("document_types", None))
        self.lookup_cb.currentIndexChanged.connect(self._load_lookup)
        row.addWidget(QLabel("القائمة:"))
        row.addWidget(self.lookup_cb, 1)
        l.addLayout(row)
        # بحث فوري داخل القائمة الحالية (متطلب 11.2) — يسرّع الوصول ويقلل التكرار
        self.lookup_search = QLineEdit()
        self.lookup_search.setPlaceholderText("بحث في القائمة الحالية…")
        self.lookup_search.textChanged.connect(lambda *_: self._render_lookup())
        l.addWidget(self.lookup_search)
        self.lookup_list = QListWidget()
        l.addWidget(self.lookup_list, 1)
        btn_row = QHBoxLayout()
        self.new_name = QLineEdit()
        self.new_name.setPlaceholderText("اسم جديد")
        btn_add = QPushButton("إضافة")
        btn_add.clicked.connect(self._lookup_add)
        btn_del = QPushButton("حذف")
        btn_del.clicked.connect(self._lookup_del)
        btn_row.addWidget(self.new_name, 1)
        btn_row.addWidget(btn_add)
        btn_row.addWidget(btn_del)
        self.btn_licenses = QPushButton("تراخيص الجهة المنفذة")
        self.btn_licenses.clicked.connect(self._open_licenses)
        btn_row.addWidget(self.btn_licenses)
        l.addLayout(btn_row)
        self.lookup_list.currentItemChanged.connect(lambda *_: self._sync_license_btn())
        self.lookup_cb.currentIndexChanged.connect(lambda *_: self._sync_license_btn())
        self._load_lookup()
        self._sync_license_btn()
        return w

    def _sync_license_btn(self):
        table, kind = self._lookup_info()
        self.btn_licenses.setEnabled(
            table == "entities" and kind == "implementing"
            and self.lookup_list.currentItem() is not None)

    def _open_licenses(self):
        item = self.lookup_list.currentItem()
        if not item:
            return
        dlg = EntityLicensesDialog(self.ctx, item.data(Qt.UserRole), item.text(), parent=self)
        dlg.exec()

    def _lookup_info(self):
        return self.lookup_cb.currentData()

    def _audit(self, action, entity, entity_id, details=""):
        uid = self.ctx.user["id"] if self.ctx.user else None
        username = self.ctx.user["username"] if self.ctx.user else None
        self.ctx.conn.execute(
            "INSERT INTO audit_log (user_id, username, action, entity, entity_id, details)"
            " VALUES (?,?,?,?,?,?)", (uid, username, action, entity, entity_id, details))

    def _load_lookup(self):
        table, kind = self._lookup_info()
        if table == "entities":
            rows = self.ctx.conn.execute(
                "SELECT id, name FROM entities WHERE kind=? AND active=1 ORDER BY name", (kind,))
        elif table == "document_types":
            # الأنواع المعطّلة لا تظهر في قائمة الإدارة نفسها (اتساق 11.1)
            rows = self.ctx.conn.execute(
                "SELECT id, name FROM document_types WHERE active=1 ORDER BY sort_order")
        else:
            rows = self.ctx.conn.execute(f"SELECT id, name FROM {table} WHERE active=1 ORDER BY name")
        self._lookup_rows = [(r["id"], r["name"]) for r in rows]
        self._render_lookup()

    def _render_lookup(self):
        q = self.lookup_search.text().strip() if hasattr(self, "lookup_search") else ""
        self.lookup_list.clear()
        for rid, name in getattr(self, "_lookup_rows", []):
            if q and q not in name:
                continue
            self.lookup_list.addItem(f"{name}")
            self.lookup_list.item(self.lookup_list.count() - 1).setData(Qt.UserRole, rid)
        self._sync_license_btn()

    def _lookup_add(self):
        name = self.new_name.text().strip()
        if not name:
            return
        table, kind = self._lookup_info()
        conn = self.ctx.conn
        # منع التكرار: اسم موجود نشطًا = تنبيه؛ موجود معطّلًا = إعادة تفعيل لا صف مكرر
        if table == "entities":
            ex = conn.execute("SELECT id, active FROM entities WHERE name=? AND kind=?",
                              (name, kind)).fetchone()
        else:
            ex = conn.execute(f"SELECT id, active FROM {table} WHERE name=?", (name,)).fetchone()
        if ex and ex["active"]:
            QMessageBox.information(self, "تنبيه", f"«{name}» موجود مسبقًا في هذه القائمة.")
            return
        try:
            if ex:
                conn.execute(f"UPDATE {table} SET active=1 WHERE id=?", (ex["id"],))
                self._audit("lookup.reactivate", table, ex["id"], f"إعادة تفعيل «{name}»")
            elif table == "entities":
                cur = conn.execute("INSERT INTO entities (name, kind) VALUES (?,?)", (name, kind))
                self._audit("lookup.add", table, cur.lastrowid, f"إضافة «{name}»")
            elif table == "document_types":
                cur = conn.execute("INSERT INTO document_types (name) VALUES (?)", (name,))
                self._audit("lookup.add", table, cur.lastrowid, f"إضافة «{name}»")
            else:
                cur = conn.execute(f"INSERT INTO {table} (name) VALUES (?)", (name,))
                self._audit("lookup.add", table, cur.lastrowid, f"إضافة «{name}»")
            conn.commit()
        except Exception as exc:
            QMessageBox.warning(self, "تنبيه", f"تعذر الإضافة: {exc}")
            return
        self.new_name.clear()
        self._load_lookup()

    def _lookup_del(self):
        item = self.lookup_list.currentItem()
        if not item:
            return
        if QMessageBox.question(self, "تأكيد", f"حذف «{item.text()}»؟\n(لن تُحذف السجلات التاريخية المرتبطة)") != QMessageBox.Yes:
            return
        table, kind = self._lookup_info()
        _id = item.data(Qt.UserRole)
        if table in ("branches", "program_fields", "programs"):
            self.ctx.conn.execute(f"UPDATE {table} SET active=0 WHERE id=?", (_id,))
        elif table == "entities":
            self.ctx.conn.execute("UPDATE entities SET active=0 WHERE id=?", (_id,))
        else:
            self.ctx.conn.execute("UPDATE document_types SET active=0 WHERE id=?", (_id,))
        self._audit("lookup.deactivate", table, _id, f"تعطيل «{item.text()}»")
        self.ctx.conn.commit()
        self._load_lookup()

    # -- المدربون ----------------------------------------------------------------------
    def _tab_trainers(self):
        from PySide6.QtWidgets import QTableWidget, QTableWidgetItem
        w = QWidget()
        l = QVBoxLayout(w)
        self.trainers_table = QTableWidget()
        self.trainers_table.setColumnCount(4)
        self.trainers_table.setHorizontalHeaderLabels(
            ["اسم المدرب", "المؤهل والتخصص", "الخبرة", "جهة إصدار الترخيص"])
        self.trainers_table.verticalHeader().setVisible(False)
        self.trainers_table.horizontalHeader().setStretchLastSection(True)
        l.addWidget(self.trainers_table, 1)
        row = QHBoxLayout()
        btn_add = QPushButton("إضافة مدرب")
        btn_add.setProperty("primary", True)
        btn_add.clicked.connect(self._trainer_add)
        btn_edit = QPushButton("تعديل")
        btn_edit.clicked.connect(self._trainer_edit)
        btn_del = QPushButton("حذف")
        btn_del.clicked.connect(self._trainer_del)
        row.addWidget(btn_add)
        row.addWidget(btn_edit)
        row.addWidget(btn_del)
        row.addStretch(1)
        l.addLayout(row)
        self._load_trainers()
        return w

    def _load_trainers(self):
        rows = self.ctx.conn.execute(
            "SELECT id, name, qualification, experience, license_issuer FROM trainers"
            " WHERE active=1 ORDER BY name"
        ).fetchall()
        self._trainer_rows = [dict(r) for r in rows]
        self.trainers_table.setRowCount(len(self._trainer_rows))
        for i, r in enumerate(self._trainer_rows):
            for j, key in enumerate(["name", "qualification", "experience", "license_issuer"]):
                item = QTableWidgetItem(str(r.get(key) or "—"))
                item.setData(Qt.UserRole, r["id"])
                self.trainers_table.setItem(i, j, item)
        self.trainers_table.resizeColumnsToContents()

    def _selected_trainer_id(self):
        row = self.trainers_table.currentRow()
        if row < 0:
            return None
        return self.trainers_table.item(row, 0).data(Qt.UserRole)

    def _trainer_add(self):
        dlg = TrainerDialog(self.ctx, parent=self)
        if dlg.exec():
            self._load_trainers()

    def _trainer_edit(self):
        tid = self._selected_trainer_id()
        if not tid:
            QMessageBox.information(self, "تنبيه", "اختر مدربًا أولًا.")
            return
        dlg = TrainerDialog(self.ctx, trainer_id=tid, parent=self)
        if dlg.exec():
            self._load_trainers()

    def _trainer_del(self):
        # حذف ناعم (تعطيل) لا فعلي: سجل المدرب يبقى مرجعًا تاريخيًا للملفات
        # المرتبطة به، ويُفرض إذن إدارة الإعدادات ويُدوَّن في سجل التدقيق
        if not has_permission(self.ctx.user, "settings.manage", self.ctx.conn):
            QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية إدارة الإعدادات.")
            return
        tid = self._selected_trainer_id()
        if not tid:
            return
        if QMessageBox.question(self, "تأكيد",
                                "تعطيل هذا المدرب؟ (سيختفي من قوائم الاختيار "
                                "وتبقى ملفاته التاريخية مرتبطة به)") != QMessageBox.Yes:
            return
        self.ctx.conn.execute("UPDATE trainers SET active=0 WHERE id=?", (tid,))
        self._audit("trainer.deactivate", "trainers", tid, "تعطيل مدرب من الإعدادات")
        self.ctx.conn.commit()
        self._load_trainers()

    # -- إعدادات النظام ---------------------------------------------------------------
    def _tab_system(self):
        w = QWidget()
        form = QFormLayout(w)
        form.setLabelAlignment(Qt.AlignRight)
        s = self.ctx.settings()
        self.set_deadline = QSpinBox()
        self.set_deadline.setRange(1, 365)
        self.set_deadline.setValue(int(s.get("review_deadline_days", 30)))
        form.addRow("مدة المراجعة (يوم) للتنبيه بالتأخير:", self.set_deadline)

        self.set_funding = QComboBox()
        self.set_funding.addItem("التكلفة الإجمالية المعتمدة", "approved_total")
        self.set_funding.addItem("التكلفة المعتمدة من الفرع", "branch_approved")
        self.set_funding.addItem("بدون اقتراح (إدخال يدوي)", "empty")
        self.set_funding.setCurrentIndex(
            self.set_funding.findData(s.get("funding_default_rule", "approved_total")))
        form.addRow("القاعدة الافتراضية لاقتراح مبلغ التمويل:", self.set_funding)

        self.set_hour_cost = QSpinBox()
        self.set_hour_cost.setRange(100, 1000000)
        try:
            self.set_hour_cost.setValue(int(float(s.get("hour_cost_standard", 5000))))
        except ValueError:
            self.set_hour_cost.setValue(5000)
        form.addRow("تكلفة الساعة المعيارية (ر.ي) — للتنبيه عند تجاوزها:", self.set_hour_cost)

        self.set_org = QLineEdit(s.get("org_name", ""))
        self.set_work = QLineEdit(s.get("office_name", ""))
        self.set_title = QLineEdit(s.get("form_title", ""))
        form.addRow("اسم الجهة في التقارير:", self.set_org)
        form.addWidget(self.set_work)
        form.addRow("اسم المكتب:", self.set_work)
        form.addRow("عنوان الاستمارة:", self.set_title)

        # الموقّعون على استمارة المراجعة الفنية — الأسماء من هنا، والألقاب ثابتة في الاستمارة
        from ..reports.review_form import SIGNATORIES_MEMO1, SIGNATORY_EXECUTIVE
        form.addRow(QLabel("— الموقّعون على استمارة المراجعة الفنية —"))
        self.sig_fields = {}
        for key, title in list(SIGNATORIES_MEMO1) + [SIGNATORY_EXECUTIVE]:
            le = QLineEdit(s.get(key, ""))
            le.setPlaceholderText("اسم الموقّع (يُترك فارغًا لسطر نقطي)")
            self.sig_fields[key] = le
            form.addRow(f"{title}:", le)

        btn = QPushButton("حفظ الإعدادات")
        btn.setProperty("primary", True)
        btn.clicked.connect(self._save_system)
        form.addRow(btn)
        wrap = QVBoxLayout()
        wrap.addWidget(w)
        wrap.addStretch(1)
        page = QWidget()
        page.setLayout(wrap)
        return page

    def _save_system(self):
        self.ctx.set_setting("review_deadline_days", str(self.set_deadline.value()))
        self.ctx.set_setting("funding_default_rule", self.set_funding.currentData())
        self.ctx.set_setting("hour_cost_standard", str(self.set_hour_cost.value()))
        self.ctx.set_setting("org_name", self.set_org.text().strip())
        self.ctx.set_setting("office_name", self.set_work.text().strip())
        self.ctx.set_setting("form_title", self.set_title.text().strip())
        for key, le in getattr(self, "sig_fields", {}).items():
            self.ctx.set_setting(key, le.text().strip())
        QMessageBox.information(self, "تم", "تم حفظ الإعدادات.")

    # -- المستخدمون ----------------------------------------------------------------------
    def _tab_users(self):
        w = QWidget()
        l = QVBoxLayout(w)
        self.users_list = QListWidget()
        l.addWidget(self.users_list, 1)
        row = QHBoxLayout()
        btn_add = QPushButton("مستخدم جديد")
        btn_add.clicked.connect(self._user_add)
        btn_pass = QPushButton("تعيين كلمة مرور")
        btn_pass.clicked.connect(self._user_pass)
        btn_toggle = QPushButton("تفعيل/تعطيل")
        btn_toggle.clicked.connect(self._user_toggle)
        row.addWidget(btn_add)
        row.addWidget(btn_pass)
        row.addWidget(btn_toggle)
        row.addStretch(1)
        l.addLayout(row)
        self._load_users()
        return w

    def _load_users(self):
        self.users_list.clear()
        for r in self.ctx.conn.execute("SELECT id, username, full_name, role, active FROM users ORDER BY username"):
            status = "نشط" if r["active"] else "معطّل"
            self.users_list.addItem(f"{r['full_name']} ({r['username']}) — {ROLES.get(r['role'], '')} — {status}")
            self.users_list.item(self.users_list.count() - 1).setData(Qt.UserRole, r["id"])

    def _selected_user_id(self):
        item = self.users_list.currentItem()
        return item.data(Qt.UserRole) if item else None

    def _user_add(self):
        dlg = UserDialog(self)
        if dlg.exec():
            try:
                create_user(self.ctx.conn, dlg.username.text().strip(), dlg.fullname.text().strip(),
                            dlg.password.text(), dlg.role.currentData(),
                            actor_id=self.ctx.user["id"])
                self._load_users()
            except ValueError as exc:
                QMessageBox.warning(self, "تنبيه", str(exc))

    def _user_pass(self):
        uid = self._selected_user_id()
        if not uid:
            return
        dlg = PasswordDialog(self)
        if dlg.exec():
            try:
                change_password(self.ctx.conn, uid, dlg.password.text())
                QMessageBox.information(self, "تم", "تم تغيير كلمة المرور.")
            except ValueError as exc:
                QMessageBox.warning(self, "تنبيه", str(exc))

    def _user_toggle(self):
        uid = self._selected_user_id()
        if not uid:
            return
        if uid == self.ctx.user["id"]:
            QMessageBox.warning(self, "تنبيه", "لا يمكنك تعطيل حسابك الحالي.")
            return
        self.ctx.conn.execute("UPDATE users SET active = 1 - active WHERE id=?", (uid,))
        self.ctx.conn.commit()
        self._load_users()

    # -- مصفوفة الصلاحيات ---------------------------------------------------------------
    def _tab_permissions(self):
        from ..services.auth_service import (PERMISSION_CATALOG, clear_role_permission,
                                             clear_user_permission, set_role_permission,
                                             set_user_permission)
        from PySide6.QtWidgets import QTableWidget, QTableWidgetItem
        w = QWidget()
        l = QVBoxLayout(w)
        top = QHBoxLayout()
        self.perm_mode = QComboBox()
        self.perm_mode.addItem("حسب الدور", "role")
        self.perm_mode.addItem("حسب المستخدم", "user")
        self.perm_mode.currentIndexChanged.connect(self._reload_perm_subjects)
        self.perm_subject = QComboBox()
        self.perm_subject.currentIndexChanged.connect(self._load_perm_matrix)
        top.addWidget(QLabel("النمط:"))
        top.addWidget(self.perm_mode)
        top.addWidget(QLabel("الدور / المستخدم:"))
        top.addWidget(self.perm_subject, 1)
        l.addLayout(top)
        l.addWidget(QLabel("علّم الصلاحية لمنحها أو أزل العلامة لحظرها. «إعادة للافتراضي» يمسح التخصيص."))
        self.perm_table = QTableWidget()
        self.perm_table.setColumnCount(4)
        self.perm_table.setHorizontalHeaderLabels(
            ["الصلاحية", "الافتراضي", "مخصصة", "منح"])
        self.perm_table.verticalHeader().setVisible(False)
        l.addWidget(self.perm_table, 1)
        row = QHBoxLayout()
        btn_save = QPushButton("حفظ المصفوفة")
        btn_save.setProperty("primary", True)
        btn_save.clicked.connect(self._save_perm_matrix)
        btn_reset = QPushButton("إعادة المحدد للافتراضي")
        btn_reset.clicked.connect(self._reset_perm_rows)
        row.addWidget(btn_save)
        row.addWidget(btn_reset)
        row.addStretch(1)
        l.addLayout(row)
        self._perm_catalog = PERMISSION_CATALOG
        self._perm_svc = (set_role_permission, set_user_permission,
                          clear_role_permission, clear_user_permission)
        self._reload_perm_subjects()
        return w

    def _reload_perm_subjects(self):
        self.perm_subject.blockSignals(True)
        self.perm_subject.clear()
        if self.perm_mode.currentData() == "role":
            for code, name in ROLES.items():
                self.perm_subject.addItem(name, code)
        else:
            for r in self.ctx.conn.execute(
                    "SELECT id, full_name, username FROM users WHERE active=1 ORDER BY full_name"):
                self.perm_subject.addItem(f"{r['full_name']} ({r['username']})", r["id"])
        self.perm_subject.blockSignals(False)
        self._load_perm_matrix()

    def _perm_default(self, code, subject):
        """الحالة الافتراضية قبل التخصيص."""
        from ..services.auth_service import PERMISSIONS, has_permission
        if self.perm_mode.currentData() == "role":
            return code in PERMISSIONS.get(subject, set()) or "*" in PERMISSIONS.get(subject, set())
        user = self.ctx.conn.execute("SELECT role FROM users WHERE id=?", (subject,)).fetchone()
        if not user:
            return False
        # الافتراضي للمستخدم = صلاحيات دوره (مع تجاوزات الدور) دون تجاوزات المستخدم
        return has_permission({"id": -1, "role": user["role"]}, code, self.ctx.conn)

    def _load_perm_matrix(self):
        from PySide6.QtWidgets import QTableWidgetItem, QCheckBox
        from PySide6.QtCore import Qt
        if not hasattr(self, "perm_table"):
            return
        mode = self.perm_mode.currentData()
        subject = self.perm_subject.currentData()
        if subject is None:
            # أعد تحميل المواضيع عند تبديل النمط
            if self.perm_subject.count() == 0:
                self._reload_perm_subjects()
                return
        self.perm_table.setRowCount(len(self._perm_catalog))
        self._perm_checks = []
        if mode == "role":
            subject_role = subject
        else:
            _r = self.ctx.conn.execute("SELECT role FROM users WHERE id=?", (subject,)).fetchone()
            subject_role = _r["role"] if _r else None
        for i, (code, label) in enumerate(self._perm_catalog):
            self.perm_table.setItem(i, 0, QTableWidgetItem(label))
            default = self._perm_default(code, subject)
            d_item = QTableWidgetItem("ممنوحة" if default else "محظورة")
            d_item.setFlags(d_item.flags() & ~Qt.ItemIsEditable)
            self.perm_table.setItem(i, 1, d_item)
            if mode == "role":
                ov = self.ctx.conn.execute(
                    "SELECT allowed FROM role_permissions WHERE role=? AND permission=?",
                    (subject, code)).fetchone()
            else:
                ov = self.ctx.conn.execute(
                    "SELECT allowed FROM user_permissions WHERE user_id=? AND permission=?",
                    (subject, code)).fetchone()
            custom_item = QTableWidgetItem("نعم" if ov else "لا")
            custom_item.setFlags(custom_item.flags() & ~Qt.ItemIsEditable)
            self.perm_table.setItem(i, 2, custom_item)
            chk = QCheckBox()
            protected = subject_role == "admin" and code in ADMIN_PROTECTED
            chk.setChecked(True if protected else (bool(ov["allowed"]) if ov else default))
            chk.setEnabled(not protected)  # لا تُحجب عن مدير النظام (حماية من قفل النظام)
            chk.setProperty("perm_code", code)
            self.perm_table.setCellWidget(i, 3, chk)
            self._perm_checks.append(chk)
        self.perm_table.resizeColumnsToContents()

    def _save_perm_matrix(self):
        set_role, set_user, _cr, _cu = self._perm_svc
        mode = self.perm_mode.currentData()
        subject = self.perm_subject.currentData()
        if subject is None:
            return
        uid = self.ctx.user["id"] if self.ctx.user else None
        labels = dict(self._perm_catalog)
        refused = []
        for chk in self._perm_checks:
            code = chk.property("perm_code")
            allowed = chk.isChecked()
            try:
                if mode == "role":
                    set_role(self.ctx.conn, subject, code, allowed, actor_id=uid)
                else:
                    set_user(self.ctx.conn, subject, code, allowed, actor_id=uid)
            except ValueError:
                refused.append(labels.get(code, code))
        if refused:
            QMessageBox.warning(
                self, "صلاحيات محمية",
                "لا يمكن حجب الصلاحيات التالية عن مدير النظام (حماية من قفل النظام):\n• "
                + "\n• ".join(refused) + "\n\nحُفظ ما عداها.")
        else:
            QMessageBox.information(self, "تم", "تم حفظ مصفوفة الصلاحيات.")
        self._load_perm_matrix()

    def _reset_perm_rows(self):
        _sr, _su, clear_role, clear_user = self._perm_svc
        mode = self.perm_mode.currentData()
        subject = self.perm_subject.currentData()
        rows = {idx.row() for idx in self.perm_table.selectedIndexes()}
        if not rows:
            QMessageBox.information(self, "تنبيه", "اختر صفًا أو أكثر أولًا.")
            return
        for r in rows:
            code = self._perm_catalog[r][0]
            if mode == "role":
                clear_role(self.ctx.conn, subject, code)
            else:
                clear_user(self.ctx.conn, subject, code)
        self._load_perm_matrix()

    # -- النسخ الاحتياطي -----------------------------------------------------------------------
    def _tab_backup(self):
        w = QWidget()
        l = QVBoxLayout(w)
        row = QHBoxLayout()
        btn_now = QPushButton("إنشاء نسخة احتياطية الآن")
        btn_now.setProperty("primary", True)
        btn_now.clicked.connect(self._backup_now)
        btn_restore = QPushButton("استعادة من نسخة...")
        btn_restore.clicked.connect(self._backup_restore)
        row.addWidget(btn_now)
        row.addWidget(btn_restore)
        row.addStretch(1)
        l.addLayout(row)
        self.backup_list = QListWidget()
        l.addWidget(self.backup_list, 1)
        self._load_backups()
        # منطقة الخطر: إعادة تهيئة النظام — لمدير النظام فقط (تُفرض أيضًا في الخدمة)
        if self.ctx.user and self.ctx.user.get("role") == "admin":
            danger = QGroupBox("منطقة الخطر")
            dl = QVBoxLayout(danger)
            dl.addWidget(QLabel(
                "إعادة تهيئة النظام تحذف نهائيًا كل البيانات الحالية (الملفات "
                "والمراجعات والمرفقات والمستخدمون) وتبدأ بقاعدة فارغة. تُنشأ قبلها "
                "نسخة احتياطية كاملة موثقة تبقى في مجلد النسخ الاحتياطية."))
            btn_reset = QPushButton("إعادة تهيئة النظام (حذف كل البيانات)")
            btn_reset.clicked.connect(self._reset_system)
            dl.addWidget(btn_reset)
            l.addWidget(danger)
        return w

    def _reset_system(self):
        """متطلب 12: نسخة موثقة أولًا — فشلها يُجهض كل شيء — ثم تأكيد صريح أخير."""
        from .. import config as cfg
        from ..services import reset_service
        uid = self.ctx.user["id"] if self.ctx.user else None
        scope = (
            "ما سيُحذف نهائيًا:\n"
            "• قاعدة البيانات كاملة (الملفات، المراجعات، الصرف، المستخدمون، الإعدادات)\n"
            "• كل ملفات المرفقات\n\n"
            "ما سيبقى:\n"
            "• ملفات البرنامج نفسه\n"
            "• مجلد النسخ الاحتياطية — وستُنشأ فيه الآن نسخة كاملة من وضعك الحالي\n"
            "• قاعدة جديدة فارغة بحساب مدير مؤقت (admin) يفرض تغيير كلمة المرور\n\n"
            "الخطوة الأولى: إنشاء النسخة الاحتياطية والتحقق منها. متابعة؟")
        if QMessageBox.question(self, "إعادة تهيئة النظام", scope) != QMessageBox.Yes:
            return
        try:
            backup_path = reset_service.prepare_reset(self.ctx.conn, uid)
        except (PermissionError, RuntimeError) as exc:
            QMessageBox.critical(self, "أُجهضت إعادة التهيئة", str(exc))
            return
        except Exception as exc:
            QMessageBox.critical(self, "أُجهضت إعادة التهيئة",
                                 f"فشل إنشاء النسخة الاحتياطية: {exc}\nلم تُمسح أي بيانات.")
            return
        final = QMessageBox(self)
        final.setWindowTitle("التأكيد الأخير")
        final.setIcon(QMessageBox.Warning)
        final.setText(
            "النسخة الاحتياطية جاهزة وموثقة في:\n"
            f"{backup_path}\n\n"
            "هل تنفّذ الآن حذف كل البيانات وإعادة التهيئة؟ لا يمكن التراجع.")
        btn_yes = final.addButton("نعم، نفّذ الحذف", QMessageBox.YesRole)
        btn_no = final.addButton("إلغاء", QMessageBox.NoRole)
        final.setDefaultButton(btn_no)  # Enter الافتراضي = إلغاء، لا تنفيذ
        final.exec()
        if final.clickedButton() is not btn_yes:
            return
        try:
            self.ctx.db.close()
            reset_service.execute_wipe(cfg.db_path(), cfg.attachments_dir())
            reset_service.reinitialize(cfg.db_path())
        except Exception as exc:
            QMessageBox.critical(self, "خطأ أثناء إعادة التهيئة",
                                 f"حدث خطأ: {exc}\nالنسخة الاحتياطية محفوظة في:\n{backup_path}")
            QApplication.quit()
            return
        QMessageBox.information(
            self, "اكتملت إعادة التهيئة",
            "تمت إعادة تهيئة النظام بقاعدة بيانات جديدة فارغة.\n"
            f"نسخة بياناتك السابقة محفوظة وموثقة في:\n{backup_path}\n\n"
            "سيُغلق البرنامج الآن؛ عند فتحه سجّل الدخول بالحساب المؤقت "
            "admin وستُطالب بتغيير كلمة المرور فورًا.")
        QApplication.quit()

    def _load_backups(self):
        self.backup_list.clear()
        for r in self.ctx.conn.execute("SELECT path, created_at, size_bytes, verified FROM backup_history ORDER BY created_at DESC"):
            kb = (r["size_bytes"] or 0) / 1024
            v = "✓ تم التحقق" if r["verified"] else ""
            self.backup_list.addItem(f"{r['created_at'][:16]} — {Path(r['path']).name} ({kb:.0f} KB) {v}")

    def _backup_now(self):
        try:
            path = backup_service.create_backup(self.ctx.conn, include_attachments=True)
            backup_service.cleanup_old_backups(self.ctx.conn, keep=10)
            self._load_backups()
            QMessageBox.information(self, "تم", f"تم إنشاء النسخة الاحتياطية:\n{path}")
        except Exception as exc:
            QMessageBox.critical(self, "فشل النسخ الاحتياطي", f"تنبيه: فشل إنشاء النسخة!\n{exc}")

    def _backup_restore(self):
        path, _ = QFileDialog.getOpenFileName(self, "اختر ملف النسخة الاحتياطية", "", "ZIP (*.zip)")
        if not path:
            return
        if QMessageBox.question(
                self, "تأكيد الاستعادة",
                "سيتم استبدال قاعدة البيانات الحالية بالنسخة المحددة.\n"
                "تأكد من وجود نسخة احتياطية حديثة قبل المتابعة.\n\nمتابعة؟") != QMessageBox.Yes:
            return
        try:
            # نسخة أمان تلقائية قبل الاستعادة
            backup_service.create_backup(self.ctx.conn, notes="تلقائية قبل الاستعادة")
            # تُغلق القاعدة المفتوحة وتُزال ملفات WAL القديمة قبل استبدال الملف
            backup_service.restore_backup(Path(path), confirm=True, database=self.ctx.db,
                                          actor=self.ctx.user)
            QMessageBox.information(
                self, "تم", "تمت الاستعادة بنجاح.\nسيُغلق البرنامج الآن؛ افتحه من جديد "
                "لتحميل البيانات المستعادة.")
            QApplication.quit()
        except Exception as exc:
            QMessageBox.critical(self, "خطأ", f"فشلت الاستعادة: {exc}")
            if not self.ctx.db.is_open:  # أُغلقت القاعدة قبل الفشل: لا يصلح الاتصال القديم للاستخدام
                QMessageBox.information(self, "إعادة التشغيل", "سيُغلق البرنامج؛ افتحه من جديد.")
                QApplication.quit()

    # خريطة مفاتيح التنقل إلى تبويبات الصفحة (تُستدعى من النافذة الرئيسية)
    SECTION_TABS = {"settings": "القوائم المرجعية", "users": "المستخدمون",
                    "backup": "النسخ الاحتياطي"}

    def show_section(self, key: str):
        title = self.SECTION_TABS.get(key)
        if not title:
            return
        for i in range(self.tabs.count()):
            if self.tabs.tabText(i) == title:
                self.tabs.setCurrentIndex(i)
                return

    def refresh(self):
        pass


class TrainerDialog(QDialog):
    def __init__(self, ctx, trainer_id=None, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.trainer_id = trainer_id
        self.setWindowTitle("إضافة مدرب" if not trainer_id else "تعديل مدرب")
        form = QFormLayout(self)
        form.setLabelAlignment(Qt.AlignRight)
        self.name = QLineEdit()
        self.qual = QLineEdit()
        self.exp = QLineEdit()
        self.lic = QLineEdit()
        form.addRow("اسم المدرب *:", self.name)
        form.addRow("المؤهل والتخصص:", self.qual)
        form.addRow("الخبرة:", self.exp)
        form.addRow("جهة إصدار الترخيص:", self.lic)
        btns = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        btns.button(QDialogButtonBox.Save).setText("حفظ")
        btns.button(QDialogButtonBox.Save).setProperty("primary", True)
        btns.button(QDialogButtonBox.Cancel).setText("إلغاء")
        btns.accepted.connect(self.save)
        btns.rejected.connect(self.reject)
        form.addRow(btns)
        if trainer_id:
            r = ctx.conn.execute("SELECT * FROM trainers WHERE id=?", (trainer_id,)).fetchone()
            if r:
                self.name.setText(r["name"] or "")
                self.qual.setText(r["qualification"] or "")
                self.exp.setText(r["experience"] or "")
                self.lic.setText(r["license_issuer"] or "")
        from .widgets import install_enter_navigation, rtl_align
        rtl_align(self)
        install_enter_navigation(self)

    def save(self):
        name = self.name.text().strip()
        if not name:
            QMessageBox.warning(self, "تنبيه", "اسم المدرب إلزامي.")
            return
        try:
            if self.trainer_id:
                self.ctx.conn.execute(
                    "UPDATE trainers SET name=?, qualification=?, experience=?, license_issuer=?"
                    " WHERE id=?",
                    (name, self.qual.text().strip() or None, self.exp.text().strip() or None,
                     self.lic.text().strip() or None, self.trainer_id))
            else:
                self.ctx.conn.execute(
                    "INSERT INTO trainers (name, qualification, experience, license_issuer)"
                    " VALUES (?,?,?,?)",
                    (name, self.qual.text().strip() or None, self.exp.text().strip() or None,
                     self.lic.text().strip() or None))
            self.ctx.conn.commit()
            self.accept()
        except Exception as exc:
            QMessageBox.warning(self, "تعذر الحفظ", f"ربما الاسم مكرر: {exc}")


class UserDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("مستخدم جديد")
        l = QFormLayout(self)
        l.setLabelAlignment(Qt.AlignRight)
        self.username = QLineEdit()
        self.fullname = QLineEdit()
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)
        self.role = QComboBox()
        for code, name in ROLES.items():
            self.role.addItem(name, code)
        l.addRow("اسم المستخدم:", self.username)
        l.addRow("الاسم الكامل:", self.fullname)
        l.addRow("كلمة المرور:", self.password)
        l.addRow("الدور:", self.role)
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.button(QDialogButtonBox.Ok).setText("إضافة")
        btns.button(QDialogButtonBox.Cancel).setText("إلغاء")
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        l.addRow(btns)
        from .widgets import install_enter_navigation
        install_enter_navigation(self)


class PasswordDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("تعيين كلمة مرور")
        l = QFormLayout(self)
        l.setLabelAlignment(Qt.AlignRight)
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)
        l.addRow("كلمة المرور الجديدة:", self.password)
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.button(QDialogButtonBox.Ok).setText("تعيين")
        btns.button(QDialogButtonBox.Cancel).setText("إلغاء")
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        l.addRow(btns)


class EntityLicensesDialog(QDialog):
    """إدارة تراخيص جهة منفذة (متطلب 10.5): سجل تراخيص متعدد محفوظ التاريخ.
    أحدث ترخيص (بنهاية الصلاحية) هو ما يظهر في نموذج الملف الجديد."""

    def __init__(self, ctx, entity_id, entity_name, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.entity_id = entity_id
        self.setWindowTitle(f"تراخيص الجهة المنفذة: {entity_name}")
        self.resize(520, 420)
        from .widgets import DateField, rtl_align
        self.DateField = DateField
        l = QVBoxLayout(self)
        self.list = QListWidget()
        l.addWidget(self.list, 1)
        row = QHBoxLayout()
        self.issuer = QLineEdit()
        self.issuer.setPlaceholderText("جهة إصدار الترخيص")
        self.start = DateField()
        self.end = DateField()
        row.addWidget(self.issuer, 2)
        row.addWidget(self.start, 1)
        row.addWidget(self.end, 1)
        l.addLayout(row)
        btns = QHBoxLayout()
        btn_add = QPushButton("إضافة ترخيص")
        btn_add.setProperty("primary", True)
        btn_add.clicked.connect(self._add)
        btn_del = QPushButton("حذف المحدد")
        btn_del.clicked.connect(self._del)
        btn_close = QPushButton("إغلاق")
        btn_close.clicked.connect(self.accept)
        btns.addWidget(btn_add)
        btns.addWidget(btn_del)
        btns.addStretch(1)
        btns.addWidget(btn_close)
        l.addLayout(btns)
        self._reload()
        rtl_align(self)

    def _reload(self):
        from ..services import license_service
        self.list.clear()
        for r in license_service.list_licenses(self.ctx.conn, self.entity_id):
            text = (f"{r['license_issuer'] or '—'} — من {r['license_start'] or '—'} "
                    f"إلى {r['license_end'] or '—'}")
            self.list.addItem(text)
            self.list.item(self.list.count() - 1).setData(Qt.UserRole, r["id"])

    def _add(self):
        from ..services import license_service
        try:
            start = self.start.iso_value("بداية الترخيص")
            end = self.end.iso_value("نهاية الترخيص")
            license_service.add_license(self.ctx.conn, self.entity_id,
                                        self.issuer.text(), start, end)
        except ValueError as exc:
            QMessageBox.warning(self, "تعذر الإضافة", str(exc))
            return
        self.issuer.clear()
        self.start.set_iso(None)
        self.end.set_iso(None)
        self._reload()

    def _del(self):
        item = self.list.currentItem()
        if not item:
            return
        if QMessageBox.question(self, "تأكيد", "حذف هذا الترخيص من سجل الجهة؟") != QMessageBox.Yes:
            return
        from ..services import license_service
        license_service.delete_license(self.ctx.conn, item.data(Qt.UserRole))
        self._reload()
