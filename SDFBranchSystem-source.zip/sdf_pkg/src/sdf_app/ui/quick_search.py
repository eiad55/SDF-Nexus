# -*- coding: utf-8 -*-
"""بحث عام فوري (Ctrl+K): رقم ملف أو اسم برنامج أو جهة — من أي شاشة.

يبحث في الملفات عبر خدمة البحث القائمة (رقم/برنامج/جهة/مدرب) وفي الجهات
بالاسم، ويعيد اختيار المستخدم عبر ردّ نداء واحد: ("file", id) أو
("entity", id) — والتنقل الفعلي مسؤولية النافذة الرئيسية.
"""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QDialog, QLabel, QLineEdit, QListWidget,
                               QListWidgetItem, QVBoxLayout)

MAX_RESULTS = 15


class QuickSearchDialog(QDialog):
    def __init__(self, ctx, on_open, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.on_open = on_open
        self.setWindowTitle("بحث سريع")
        self.resize(560, 420)
        lay = QVBoxLayout(self)
        self.q = QLineEdit()
        self.q.setPlaceholderText("اكتب رقم ملف أو اسم برنامج أو جهة…")
        self.q.textChanged.connect(self._refresh)
        lay.addWidget(self.q)
        self.list = QListWidget()
        self.list.itemActivated.connect(self._activate)
        lay.addWidget(self.list, 1)
        hint = QLabel("Enter أو نقر مزدوج للفتح — Esc للإغلاق")
        hint.setStyleSheet("color: #8A97AD; font-size: 11px;")
        lay.addWidget(hint)
        from .widgets import rtl_align
        rtl_align(self)
        self.q.setFocus()

    def _refresh(self, text: str):
        self.list.clear()
        text = (text or "").strip()
        if len(text) < 2:
            return
        rows, _total = self.ctx.files.search({"q": text}, page=1,
                                             per_page=MAX_RESULTS)
        for r in rows:
            label = f"ملف {r.get('file_number')} — {r.get('program_name') or ''}"
            if r.get("branch_name"):
                label += f" ({r['branch_name']})"
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, ("file", r["id"]))
            self.list.addItem(item)
        like = f"%{text}%"
        for r in self.ctx.conn.execute(
                "SELECT id, name, kind FROM entities WHERE active=1 AND name LIKE ? "
                "ORDER BY name LIMIT ?", (like, MAX_RESULTS)):
            kind = "جهة منفذة" if r["kind"] == "implementing" else "جهة مستفيدة"
            item = QListWidgetItem(f"{kind}: {r['name']}")
            item.setData(Qt.UserRole, ("entity", r["id"]))
            self.list.addItem(item)
        if self.list.count():
            self.list.setCurrentRow(0)

    def _activate(self, item):
        if item is None:
            return
        kind, ident = item.data(Qt.UserRole)
        self.accept()
        if self.on_open:
            self.on_open(kind, ident)

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key_Return, Qt.Key_Enter):
            self._activate(self.list.currentItem())
            return
        super().keyPressEvent(event)
