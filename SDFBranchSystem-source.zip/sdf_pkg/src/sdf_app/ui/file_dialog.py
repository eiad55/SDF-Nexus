# -*- coding: utf-8 -*-
"""نموذج الملف التدريبي: تبويبات البيانات + المرفقات + الحالة والسجل (حزمة v2)."""
from datetime import date

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QComboBox, QDialog, QDialogButtonBox,
                               QDoubleSpinBox, QFileDialog, QFormLayout,
                               QHBoxLayout, QInputDialog, QLabel, QLineEdit,
                               QListWidget, QMessageBox, QPushButton, QSpinBox,
                               QTableWidget, QTableWidgetItem, QTabWidget,
                               QTextEdit, QVBoxLayout, QWidget, QScrollArea)

from ..core import finance
from ..core.field_values import EMPTY_INT, spin_to_value, value_to_spin
from ..core.review_logic import suggest_approved_count
from ..core.workflow import STATUS_NAMES, next_statuses_for
from ..services import contribution_service as contrib
from ..services.auth_service import has_permission
from ..services.file_service import ApprovalBlocked, LockedFields
from .widgets import DateField, rtl_align, TitledPanel, HintLineEdit

MATCH_OPTIONS = ["", "مطابق", "غير مطابق"]


def _money_spin():
    s = QDoubleSpinBox()
    s.setRange(0, 999999999)
    s.setDecimals(2)
    s.setGroupSeparatorShown(True)
    return s


class FileDialog(QDialog):
    # الحقول العامة الإلزامية عند إنشاء ملف جديد
    REQUIRED_GENERAL = [
        ("file_number", "رقم الملف"),
        ("branch_id", "الفرع"),
        ("program_id", "اسم البرنامج التدريبي"),
        ("beneficiary_id", "الجهة المستفيدة"),
    ]

    def __init__(self, ctx, file_id=None, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.file_id = file_id
        self.record = ctx.files.get(file_id) if file_id else {}
        self.setWindowTitle("ملف جديد" if not file_id else f"ملف رقم {self.record.get('file_number')}")
        # حجم واعٍ بالشاشة المضيفة: لا يتجاوز 94% من ارتفاعها المتاح أبدًا
        try:
            avail = self.screen().availableGeometry()
            self.resize(min(980, avail.width() - 40), min(740, int(avail.height() * 0.94)))
        except Exception:
            self.resize(960, 720)
        self.widgets = {}
        self.field_labels = {}
        self._loading = False
        self._license_snapshot = (None, None, None)
        self._beneficiary_names = {}  # id -> name (لجدول الترشيح)

        layout = QVBoxLayout(self)
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)

        self.tabs.addTab(self._tab_general(), "البيانات العامة")
        self.tabs.addTab(self._tab_contract(), "بيانات العقد")
        self.tabs.addTab(self._tab_nomination(), "بيانات الترشيح")
        self.tabs.addTab(self._tab_attendance(), "الحضور والتنفيذ")
        self.tabs.addTab(self._tab_trainer(), "المدرب والجهة المنفذة")
        self.tabs.addTab(self._tab_certs(), "الشهادات والمادة العلمية")
        self.tabs.addTab(self._tab_finance(), "البيانات المالية")
        if file_id:
            self.tabs.addTab(self._tab_attachments(), "المرفقات")
            self.tabs.addTab(self._tab_status(), "الحالة والسجل")

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Save).setText("حفظ")
        buttons.button(QDialogButtonBox.Save).setProperty("primary", True)
        buttons.button(QDialogButtonBox.Cancel).setText("إلغاء")
        buttons.accepted.connect(self.save)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        # متطلب 10.2: Enter ينقل التركيز للحقل التالي ولا يحفظ أبدًا —
        # نلغي «الزر الافتراضي» الذي كان يجعل Enter = حفظ
        for b in buttons.buttons():
            b.setAutoDefault(False)
            b.setDefault(False)
        self.installEventFilter(self)
        # تغيير الجهة المنفذة (تفاعل مستخدم) يحدّث بيانات الترخيص المعروضة
        impl_w, _ = self.widgets["implementing_id"]
        impl_w.currentIndexChanged.connect(lambda *_: self._on_entity_changed())

        if file_id:
            self._load_record()
        else:
            self._show_license_snapshot("اختر الجهة المنفذة لعرض أحدث ترخيص مسجل لها.")
        rtl_align(self)

    def eventFilter(self, obj, event):
        """متطلب 10.2: Enter في حقول النموذج ينقل التركيز للحقل التالي ولا يحفظ.

        يُستثنى: المحررات متعددة الأسطر (Enter = سطر جديد)، القائمة المنسدلة
        المفتوحة (Enter = اختيار)، الأزرار (تفعيل صريح)، ومحررات خلايا الجداول.
        """
        from PySide6.QtCore import QEvent
        from PySide6.QtWidgets import QAbstractButton
        if event.type() == QEvent.KeyPress and event.key() in (Qt.Key_Return, Qt.Key_Enter):
            fw = self.focusWidget()
            if fw is not None and fw is not self:
                if isinstance(fw, (QTextEdit, QAbstractButton)):
                    return super().eventFilter(obj, event)
                if isinstance(fw, QComboBox) and fw.view() is not None \
                        and fw.view().isVisible():
                    return super().eventFilter(obj, event)
                parent = fw.parentWidget()
                while parent is not None:
                    if isinstance(parent, QTableWidget):
                        return super().eventFilter(obj, event)
                    parent = parent.parentWidget()
                self.focusNextChild()
                return True
        return super().eventFilter(obj, event)

    def _val(self, key):
        """القيمة الحالية لحقل رقمي: None إن كان فارغًا (الفارغ ≠ صفر)."""
        w, kind = self.widgets[key]
        v = w.value()
        if kind == "int":
            return spin_to_value(v)
        return v if v else None

    def _can_do(self, permission):
        return has_permission(self.ctx.user, permission, self.ctx.conn)

    # -- أدوات بناء الحقول ------------------------------------------------------
    def _field(self, key, label, kind="text", **kw):
        if kind == "text":
            w = HintLineEdit()
        elif kind == "int":
            w = QSpinBox()
            w.setRange(EMPTY_INT, 1000000)
            w.setSpecialValueText("—")  # الحد الأدنى = «فارغ»؛ يختلف عن الصفر
            w.setValue(EMPTY_INT)
        elif kind == "money":
            w = _money_spin()
        elif kind == "date":
            w = DateField()
        elif kind == "combo":
            w = QComboBox()
            w.setEditable(True)
        elif kind == "idcombo":
            w = QComboBox()
            w.setEditable(False)  # مقيدة: لا يقبل نصًا خارج القائمة
        elif kind == "match":
            w = QComboBox()
            w.setEditable(False)
            w.addItems(MATCH_OPTIONS)
        elif kind == "notes":
            w = QTextEdit()
            w.setMaximumHeight(90)
        else:
            w = HintLineEdit()
        self.widgets[key] = (w, kind)
        self.field_labels[key] = label
        row = QHBoxLayout()
        lbl = QLabel(label)
        lbl.setMinimumWidth(190)
        # RTL: التسمية تُضاف أولًا فتظهر يمين الحقل
        row.addWidget(lbl, 0)
        row.addWidget(w, 1)
        return row

    def _lookup_combo(self, key, label, table, kind=None):
        """قائمة منسدلة مقيدة من جدول مرجعي — تُدار من الإعدادات حصرًا."""
        row = self._field(key, label, kind="idcombo")
        w, _ = self.widgets[key]
        w.clear()
        if table == "entities":
            rows = self.ctx.conn.execute(
                "SELECT id, name FROM entities WHERE kind=? AND active=1 ORDER BY name", (kind,))
        else:
            cols = {c[1] for c in self.ctx.conn.execute(f"PRAGMA table_info({table})")}
            active_filter = "WHERE active=1" if "active" in cols else ""
            rows = self.ctx.conn.execute(
                f"SELECT id, name FROM {table} {active_filter} ORDER BY name")
        for r in rows:
            w.addItem(r["name"], r["id"])
        w.setCurrentIndex(-1)
        return row

    def _group(self, title, rows):
        g = TitledPanel(title)
        l = QVBoxLayout(g.content)
        for r in rows:
            l.addLayout(r)
        return g

    def _scroll(self, widget):
        s = QScrollArea()
        s.setWidgetResizable(True)
        s.setWidget(widget)
        s.setFrameShape(QScrollArea.NoFrame)
        return s

    def _info_row(self, label, widget):
        row = QHBoxLayout()
        lbl = QLabel(label)
        lbl.setMinimumWidth(220)
        lbl.setStyleSheet("font-weight: bold; color: #1F3A5F;")
        row.addWidget(lbl, 0)
        row.addWidget(widget, 1)
        return row

    # -- التبويبات ------------------------------------------------------------------
    def _tab_general(self):
        w = QWidget()
        l = QVBoxLayout(w)
        # رقم الملف في الفرع + رقم التسميح جنبًا إلى جنب
        row_nums = QHBoxLayout()
        self._field("branch_file_number", "رقم الملف لدى الفرع")
        self._field("clearance_number", "رقم التسميح")
        bw, _ = self.widgets["branch_file_number"]
        cw, _ = self.widgets["clearance_number"]
        r1 = QHBoxLayout(); r1.addWidget(bw, 1); r1.addWidget(QLabel("رقم الملف لدى الفرع"), 0)
        r2 = QHBoxLayout(); r2.addWidget(cw, 1); r2.addWidget(QLabel("رقم التسميح"), 0)
        row_nums.addLayout(r1, 1)
        row_nums.addLayout(r2, 1)
        l.addWidget(self._group("بيانات الملف", [
            self._field("file_number", "رقم الملف *", kind="int"),
            row_nums,
            self._field("received_date", "تاريخ استلام الملف", kind="date"),
            self._lookup_combo("branch_id", "الفرع *", "branches"),
            self._lookup_combo("program_id", "اسم البرنامج التدريبي *", "programs"),
            self._field("group_name", "المجموعة"),
            self._field("level", "المستوى"),
            self._field("exec_place", "مكان التنفيذ"),
            self._lookup_combo("field_id", "مجال البرنامج", "program_fields"),
            self._lookup_combo("beneficiary_id", "الجهة المستفيدة *", "entities", kind="beneficiary"),
            self._lookup_combo("implementing_id", "الجهة المنفذة", "entities", kind="implementing"),
            self._field("exec_start", "تاريخ بداية التنفيذ", kind="date"),
            self._field("exec_end", "تاريخ نهاية التنفيذ", kind="date"),
        ]))
        l.addWidget(QLabel("الحقول المعلّمة بـ * إلزامية عند إنشاء ملف جديد."))
        l.addStretch(1)
        return self._scroll(w)

    def _tab_contract(self):
        w = QWidget()
        l = QVBoxLayout(w)
        # العملة + سعر الصرف
        cur_row = self._field("cost_currency", "عملة التكلفة", kind="idcombo")
        cw, _ = self.widgets["cost_currency"]
        cw.addItem("ريال يمني", "YER")
        cw.addItem("دولار أمريكي", "USD")
        cw.setCurrentIndex(0)
        cw.currentIndexChanged.connect(self._on_currency_changed)
        l.addWidget(self._group("بيانات العقد", [
            self._field("contract_number", "رقم العقد"),
            self._field("contract_date", "تاريخ العقد", kind="date"),
            self._field("contract_trainees", "عدد المتدربين حسب العقد", kind="int"),
            self._field("contract_hours", "عدد الساعات حسب العقد", kind="money"),
            self._field("contract_cost_per_trainee", "تكلفة الفرد حسب العقد", kind="money"),
            cur_row,
            self._field("exchange_rate", "سعر الصرف الحالي (للدولار)", kind="money"),
        ]))
        self.contract_total_lbl = QLabel("—")
        self.contract_hour_lbl = QLabel("—")
        self.hour_alert_lbl = QLabel("")
        self.hour_alert_lbl.setStyleSheet("color: #C0392B; font-weight: bold;")
        l.addWidget(self._group("محسوبة تلقائيًا", [
            self._info_row("التكلفة الإجمالية حسب العقد:", self.contract_total_lbl),
            self._info_row("تكلفة الساعة حسب العقد (بالريال):", self.contract_hour_lbl),
            self._info_row("", self.hour_alert_lbl),
        ]))
        for key in ("contract_trainees", "contract_hours", "contract_cost_per_trainee",
                    "exchange_rate"):
            self.widgets[key][0].valueChanged.connect(self._recalc_contract)
        self._on_currency_changed()
        l.addStretch(1)
        return self._scroll(w)

    def _on_currency_changed(self):
        is_usd = self.widgets["cost_currency"][0].currentData() == "USD"
        w, _ = self.widgets["exchange_rate"]
        w.setEnabled(is_usd)
        self._recalc_contract()

    def _contract_summary(self):
        """مؤشرات العقد بالريال من محرك الحساب المركزي (يشمل تحويل الدولار)."""
        return finance.summarize({
            "contract_trainees": self._val("contract_trainees"),
            "contract_hours": self._val("contract_hours"),
            "contract_cost_per_trainee": self._val("contract_cost_per_trainee"),
            "cost_currency": self.widgets["cost_currency"][0].currentData() or "YER",
            "exchange_rate": self._val("exchange_rate"),
        })

    def _hour_cost_yer(self):
        """تكلفة الساعة بالريال مع مراعاة العملة وسعر الصرف."""
        return self._contract_summary()["contract_hour_cost"]

    def _recalc_contract(self):
        s = self._contract_summary()
        total, hc = s["contract_total"], s["contract_hour_cost"]
        if s["contract_rate_missing"]:
            self.contract_total_lbl.setText("— (أدخل سعر الصرف)")
            self.contract_hour_lbl.setText("— (أدخل سعر الصرف)")
        else:
            self.contract_total_lbl.setText(finance.format_money(total) if total is not None else "—")
            self.contract_hour_lbl.setText(
                finance.format_money(hc) if hc else "— (الساعات صفر أو فارغة)")
        # تنبيه تجاوز تكلفة الساعة المعيارية
        try:
            standard = float(self.ctx.settings().get("hour_cost_standard", 5000) or 5000)
        except ValueError:
            standard = 5000
        if hc and float(hc) > standard:
            self.hour_alert_lbl.setText(
                f"⚠ تنبيه: تكلفة الساعة ({finance.format_money(hc)}) تتجاوز المعيارية"
                f" ({finance.format_money(standard)})")
        else:
            self.hour_alert_lbl.setText("")

    # -- الترشيح: جدول أسماء + جهة لكل مرشح -------------------------------------------
    def _tab_nomination(self):
        w = QWidget()
        l = QVBoxLayout(w)
        l.addWidget(self._group("بيانات الترشيح", [
            self._field("nominees_count", "عدد المرشحين (للمرجع)", kind="int"),
            self._field("nomination_date", "تاريخ الترشيح", kind="date"),
        ]))
        g = TitledPanel("أسماء المرشحين والجهة المستفيدة لكل مرشح")
        gl = QVBoxLayout(g.content)
        self.nom_table = QTableWidget()
        self.nom_table.setColumnCount(3)
        self.nom_table.setHorizontalHeaderLabels(["م", "اسم المرشح", "الجهة المستفيدة"])
        self.nom_table.verticalHeader().setVisible(False)
        self.nom_table.horizontalHeader().setStretchLastSection(True)
        gl.addWidget(self.nom_table)
        row = QHBoxLayout()
        btn_add = QPushButton("إضافة مرشح")
        btn_add.clicked.connect(self._nom_add_row)
        btn_del = QPushButton("حذف المحدد")
        btn_del.clicked.connect(self._nom_del_row)
        self.nom_warn_lbl = QLabel("")
        self.nom_warn_lbl.setStyleSheet("color: #B7791F; font-weight: bold;")
        row.addWidget(btn_add)
        row.addWidget(btn_del)
        row.addWidget(self.nom_warn_lbl, 1)
        gl.addLayout(row)
        l.addWidget(g)
        l.addStretch(1)
        # تحديث التحذير عند تغير عدد العقد
        self.widgets["contract_trainees"][0].valueChanged.connect(self._nom_check_count)
        return self._scroll(w)

    def _beneficiary_items(self):
        rows = self.ctx.conn.execute(
            "SELECT id, name FROM entities WHERE kind='beneficiary' AND active=1 ORDER BY name")
        return [(r["name"], r["id"]) for r in rows]

    def _nom_add_row(self, name="", benef_id=None):
        t = self.nom_table
        r = t.rowCount()
        t.insertRow(r)
        seq = QTableWidgetItem(str(r + 1))
        seq.setFlags(seq.flags() & ~Qt.ItemIsEditable)
        seq.setTextAlignment(Qt.AlignCenter)
        t.setItem(r, 0, seq)
        t.setItem(r, 1, QTableWidgetItem(name))
        cb = QComboBox()
        cb.setEditable(False)
        for nm, bid in self._beneficiary_items():
            cb.addItem(nm, bid)
        if benef_id:
            idx = cb.findData(benef_id)
            if idx >= 0:
                cb.setCurrentIndex(idx)
        else:
            cb.setCurrentIndex(-1)
        t.setCellWidget(r, 2, cb)
        self._nom_check_count()

    def _nom_del_row(self):
        r = self.nom_table.currentRow()
        if r >= 0:
            self.nom_table.removeRow(r)
            self._nom_check_count()

    def _nom_rows(self):
        out = []
        t = self.nom_table
        for r in range(t.rowCount()):
            name_item = t.item(r, 1)
            cb = t.cellWidget(r, 2)
            out.append({
                "seq": r + 1,
                "full_name": (name_item.text().strip() if name_item else ""),
                "beneficiary_id": cb.currentData() if cb else None,
            })
        return [x for x in out if x["full_name"]]

    def _nom_check_count(self):
        contract_n = self._val("contract_trainees")
        n = len(self._nom_rows())
        if contract_n and n and n != contract_n:
            self.nom_warn_lbl.setText(
                f"⚠ عدد المرشحين ({n}) يختلف عن عدد المتدربين في العقد ({contract_n})")
        else:
            self.nom_warn_lbl.setText("")

    # -- الحضور والتنفيذ ------------------------------------------------------------------
    def _tab_attendance(self):
        w = QWidget()
        l = QVBoxLayout(w)
        l.addWidget(self._group("بيانات الحضور والتنفيذ", [
            self._field("attendance_exec_match", "تاريخ التنفيذ حسب كشوفات الحضور", kind="match"),
            self._field("attendance_trainees", "عدد المتدربين حسب كشف الحضور", kind="int"),
            self._field("program_duration", "مدة البرنامج"),
            self._field("supervision_date", "تاريخ يوم الإشراف", kind="date"),
        ]))
        l.addWidget(self._group("تقرير الإشراف", [
            self._field("supervisor_name", "اسم المشرف"),
            self._field("supervision_level", "مستوى التنفيذ وفق تقرير الإشراف"),
        ]))
        g = TitledPanel("كشف الحضور (تُنقل الأسماء من الترشيح)")
        gl = QVBoxLayout(g.content)
        self.att_table = QTableWidget()
        self.att_table.setColumnCount(4)
        self.att_table.setHorizontalHeaderLabels(
            ["م", "اسم المتدرب", "عدد أيام الحضور", "التواجد في تقرير الإشراف"])
        self.att_table.verticalHeader().setVisible(False)
        gl.addWidget(self.att_table)
        row = QHBoxLayout()
        btn_carry = QPushButton("نقل الأسماء من الترشيح")
        btn_carry.setProperty("primary", True)
        btn_carry.clicked.connect(self._att_carry_from_nomination)
        btn_add = QPushButton("إضافة اسم")
        btn_add.clicked.connect(lambda: self._att_add_row())
        btn_del = QPushButton("حذف المحدد")
        btn_del.clicked.connect(self._att_del_row)
        self.att_info_lbl = QLabel("")
        self.att_info_lbl.setWordWrap(True)
        row.addWidget(btn_carry)
        row.addWidget(btn_add)
        row.addWidget(btn_del)
        gl.addLayout(row)
        gl.addWidget(self.att_info_lbl)
        gl.addWidget(QLabel("يُلوَّن اسم المتدرب الذي تقل نسبة حضوره عن 80% أو غير الموجود في تقرير الإشراف."))
        l.addWidget(g)
        l.addStretch(1)
        return self._scroll(w)

    def _program_days(self):
        """عدد أيام البرنامج من بداية/نهاية التنفيذ."""
        try:
            s = self.widgets["exec_start"][0].iso_or_none()
            e = self.widgets["exec_end"][0].iso_or_none()
            if not s:
                return None
            from datetime import date as _date
            d1 = _date.fromisoformat(s)
            d2 = _date.fromisoformat(e) if e else d1
            return max(1, (d2 - d1).days + 1)
        except Exception:
            return None

    def _att_add_row(self, name="", days=0, in_report=None):
        t = self.att_table
        r = t.rowCount()
        t.insertRow(r)
        seq = QTableWidgetItem(str(r + 1))
        seq.setFlags(seq.flags() & ~Qt.ItemIsEditable)
        seq.setTextAlignment(Qt.AlignCenter)
        t.setItem(r, 0, seq)
        t.setItem(r, 1, QTableWidgetItem(name))
        spin = QSpinBox()
        spin.setRange(0, 1000)
        spin.setValue(days or 0)
        spin.valueChanged.connect(self._att_recolor)
        t.setCellWidget(r, 2, spin)
        cb = QComboBox()
        cb.setEditable(False)
        cb.addItem("", None)
        cb.addItem("صح", 1)
        cb.addItem("خطأ", 0)
        if in_report is not None:
            cb.setCurrentIndex(1 if in_report else 2)
        cb.currentIndexChanged.connect(self._att_recolor)
        t.setCellWidget(r, 3, cb)
        self._att_recolor()

    def _att_del_row(self):
        r = self.att_table.currentRow()
        if r >= 0:
            self.att_table.removeRow(r)
            self._att_recolor()

    def _att_carry_from_nomination(self):
        rows = self._nom_rows()
        if not rows:
            QMessageBox.information(self, "تنبيه", "لا توجد أسماء في جدول الترشيح.")
            return
        existing = {self.att_table.item(r, 1).text().strip()
                    for r in range(self.att_table.rowCount()) if self.att_table.item(r, 1)}
        added = 0
        for x in rows:
            if x["full_name"] not in existing:
                self._att_add_row(name=x["full_name"])
                added += 1
        QMessageBox.information(self, "تم", f"تم نقل {added} اسمًا إلى كشف الحضور.")

    def _att_rows(self):
        out = []
        t = self.att_table
        for r in range(t.rowCount()):
            name_item = t.item(r, 1)
            spin = t.cellWidget(r, 2)
            cb = t.cellWidget(r, 3)
            out.append({
                "seq": r + 1,
                "full_name": (name_item.text().strip() if name_item else ""),
                "days_attended": spin.value() if spin else 0,
                "in_supervision_report": cb.currentData() if cb else None,
            })
        return [x for x in out if x["full_name"]]

    def _att_recolor(self):
        days_total = self._program_days()
        threshold = (days_total * 0.8) if days_total else None
        t = self.att_table
        bad = 0
        for r in range(t.rowCount()):
            spin = t.cellWidget(r, 2)
            cb = t.cellWidget(r, 3)
            days = spin.value() if spin else 0
            in_rep = cb.currentData() if cb else None
            is_bad = (in_rep == 0) or (threshold is not None and days < threshold)
            if is_bad:
                bad += 1
            color = QColor("#FDE8E8") if is_bad else QColor("#FFFFFF")
            for c in (0, 1):
                item = t.item(r, c)
                if item:
                    item.setBackground(color)
        if threshold is not None:
            self.att_info_lbl.setText(
                f"مدة البرنامج: {days_total} يوم — الحد الأدنى للحضور (80%): {threshold:.1f} يوم — "
                f"غير مستوفين: {bad}")
        else:
            self.att_info_lbl.setText(
                "أدخل بداية/نهاية التنفيذ في البيانات العامة لاحتساب نسبة الحضور.")

    # -- المدرب والجهة المنفذة ---------------------------------------------------------------
    def _tab_trainer(self):
        w = QWidget()
        l = QVBoxLayout(w)
        l.addWidget(self._group("بيانات المدرب (تُدار من الإعدادات)", [
            self._lookup_combo("trainer_id", "اسم المدرب", "trainers"),
            self._field("trainer_qualification", "المؤهل والتخصص"),
            self._field("trainer_experience", "الخبرة"),
        ]))
        trainer_w, _ = self.widgets["trainer_id"]
        trainer_w.currentIndexChanged.connect(lambda *_: self._on_trainer_picked())
        # الترخيص يُدار من بيانات الجهة المنفذة (متطلب 10.5) — هنا عرض فقط لأحدث
        # ترخيص مسجل للجهة المختارة، ويُحفظ في الملف كنسخة تاريخية عند الحفظ
        self.license_info_lbl = QLabel("—")
        self.license_info_lbl.setWordWrap(True)
        lic_group = TitledPanel("ترخيص الجهة المنفذة (يُدار من إعدادات الجهة)")
        ll = QVBoxLayout(lic_group)
        ll.addWidget(self.license_info_lbl)
        l.addWidget(lic_group)
        l.addWidget(self._group("الجهة المنفذة", [
            self._field("implementing_field", "مجال الجهة المنفذة"),
        ]))
        l.addStretch(1)
        return self._scroll(w)

    def _on_trainer_picked(self):
        """متطلب 10.4: اختيار مدرب يملأ بياناته المرتبطة (المؤهل/الخبرة) من سجله."""
        if self._loading:
            return
        w, _ = self.widgets["trainer_id"]
        tid = w.currentData()
        if not tid:
            return
        row = self.ctx.conn.execute(
            "SELECT qualification, experience FROM trainers WHERE id=?",
            (tid,)).fetchone()
        if not row:
            return
        if row["qualification"]:
            self.widgets["trainer_qualification"][0].setText(row["qualification"])
        if row["experience"]:
            self.widgets["trainer_experience"][0].setText(row["experience"])

    def _on_entity_changed(self):
        """متطلب 10.5: تغيير الجهة المنفذة يعرض أحدث ترخيص مسجل لها."""
        if self._loading:
            return
        from ..services import license_service
        w, _ = self.widgets["implementing_id"]
        lic = license_service.latest_license(self.ctx.conn, w.currentData())
        if lic:
            self._license_snapshot = (lic["license_issuer"], lic["license_start"],
                                      lic["license_end"])
            self._show_license_snapshot(
                f"جهة الإصدار: {lic['license_issuer'] or '—'} — "
                f"من {lic['license_start'] or '—'} إلى {lic['license_end'] or '—'}"
                " (أحدث ترخيص مسجل للجهة)")
        else:
            self._license_snapshot = (None, None, None)
            self._show_license_snapshot(
                "لا توجد بيانات ترخيص مسجلة لهذه الجهة المنفذة — "
                "تُضاف التراخيص من شاشة إعدادات الجهة المنفذة.")

    def _show_license_snapshot(self, text=None):
        if text is None:
            issuer, start, end = self._license_snapshot
            if issuer or start or end:
                text = (f"جهة الإصدار: {issuer or '—'} — من {start or '—'} "
                        f"إلى {end or '—'}")
            else:
                text = "لا توجد بيانات ترخيص."
        if hasattr(self, "license_info_lbl"):
            self.license_info_lbl.setText(text)

    # -- الشهادات والمادة العلمية ---------------------------------------------------------------
    def _tab_certs(self):
        w = QWidget()
        l = QVBoxLayout(w)
        l.addWidget(self._group("بيانات الشهادات", [
            self._field("cert_program_match", "اسم البرنامج في الشهادة", kind="match"),
            self._field("cert_exec_match", "تاريخ التنفيذ في الشهادة", kind="match"),
            self._field("certificates_count", "عدد الشهادات المرفقة", kind="int"),
        ]))
        g = TitledPanel("المادة العلمية")
        gl = QVBoxLayout(g.content)
        self._field("material_match", "مدى مطابقة محتوى المادة العلمية", kind="match")
        mw, _ = self.widgets["material_match"]
        row_m = QHBoxLayout()
        row_m.addWidget(mw, 1)
        row_m.addWidget(QLabel("مدى مطابقة محتوى المادة العلمية"), 0)
        gl.addLayout(row_m)
        gl.addWidget(QLabel("إرفاق المادة من تبويب «المرفقات»، أو ربطها بمادة علمية لبرنامج آخر:"))
        self._field("material_file_id", "ربط بمادة برنامج آخر", kind="idcombo")
        mfw, _ = self.widgets["material_file_id"]
        mfw.clear()
        for r in self.ctx.conn.execute(
                """SELECT DISTINCT f.id, f.file_number, f.program_name FROM training_files f
                   JOIN attachments a ON a.file_id=f.id
                   ORDER BY f.file_number DESC LIMIT 200"""):
            label = f"ملف {r['file_number']} — {r['program_name'] or ''}"
            mfw.addItem(label, r["id"])
        mfw.setCurrentIndex(-1)
        row_mf = QHBoxLayout()
        row_mf.addWidget(mfw, 1)
        row_mf.addWidget(QLabel("ربط بمادة برنامج آخر"), 0)
        gl.addLayout(row_mf)
        l.addWidget(g)
        l.addStretch(1)
        return self._scroll(w)

    # -- البيانات المالية -------------------------------------------------------------------------
    def _tab_finance(self):
        w = QWidget()
        l = QVBoxLayout(w)
        l.addWidget(self._group("البيانات المالية", [
            self._field("claimed_amount", "المبلغ المطالب به من الجهة المنفذة", kind="money"),
            self._field("branch_approved_amount", "التكلفة المعتمدة من الفرع", kind="money"),
            self._field("approved_trainees", "العدد المعتمد للمتدربين", kind="int"),
            self._field("approved_hours", "عدد الساعات المعتمدة", kind="money"),
            self._field("approved_cost_per_trainee", "تكلفة المتدرب المعتمدة", kind="money"),
            self._field("funding_amount", "مبلغ التمويل", kind="money"),
            self._field("claim_date", "تاريخ المطالبة", kind="date"),
            self._field("notes", "ملاحظات المراجع", kind="notes"),
        ]))
        # رصيد الجهة (للعلم فقط — غير ملزم)
        self.entity_balance_lbl = QLabel("")
        self.entity_balance_lbl.setWordWrap(True)
        self.entity_balance_lbl.setStyleSheet(
            "background: #FFF8E1; border: 1px solid #E8D48B; border-radius: 6px; padding: 8px;")
        l.addWidget(self.entity_balance_lbl)
        # اقتراح العدد المعتمد
        sug_row = QHBoxLayout()
        self.suggest_lbl = QLabel("—")
        btn_sug = QPushButton("اقتراح العدد المعتمد")
        btn_sug.clicked.connect(self._suggest_count)
        sug_row.addWidget(self.suggest_lbl, 1)
        sug_row.addWidget(btn_sug, 0)
        l.addLayout(sug_row)

        self.approved_total_lbl = QLabel("—")
        self.approved_hour_lbl = QLabel("—")
        self.diff1_lbl = QLabel("—")
        self.diff2_lbl = QLabel("—")
        l.addWidget(self._group("محسوبة تلقائيًا", [
            self._info_row("التكلفة الإجمالية المعتمدة:", self.approved_total_lbl),
            self._info_row("تكلفة الساعة المعتمدة:", self.approved_hour_lbl),
            self._info_row("الفارق: التمويل − المطالب به:", self.diff1_lbl),
            self._info_row("الفارق: المطالب به − المعتمد:", self.diff2_lbl),
        ]))
        for key in ("approved_trainees", "approved_hours", "approved_cost_per_trainee",
                    "claimed_amount", "funding_amount"):
            self.widgets[key][0].valueChanged.connect(self._recalc_finance)
        self.widgets["beneficiary_id"][0].currentIndexChanged.connect(self._update_entity_balance)
        l.addStretch(1)
        return self._scroll(w)

    def _update_entity_balance(self):
        """عرض الرصيد المتبقي للجهة عند المراجعة المالية — للعلم فقط (غير ملزم)."""
        bid = self.widgets["beneficiary_id"][0].currentData()
        if not bid:
            self.entity_balance_lbl.setText("اختر الجهة المستفيدة لعرض رصيدها (للعلم فقط).")
            return
        year = date.today().year
        try:
            bal = contrib.entity_balance(self.ctx.conn, bid, year)
            self.entity_balance_lbl.setText(
                f"رصيد الجهة التدريبي لسنة {year} (للعلم فقط — غير ملزم لاستكمال الإجراءات):\n"
                f"المساهمات: {finance.format_money(bal['contributions'])} × "
                f"{bal['effective_rate'] * 100:.0f}% = {finance.format_money(bal['training_balance'])} — "
                f"المستخدم (تمويل): {finance.format_money(bal['funding_used'])} — "
                f"المتبقي: {finance.format_money(bal['remaining'])}")
        except Exception:
            self.entity_balance_lbl.setText("تعذر حساب رصيد الجهة.")

    def _suggest_count(self):
        r = suggest_approved_count(
            contract=self._val("contract_trainees"),
            nominees=self._val("nominees_count"),
            attendance=self._val("attendance_trainees"),
            certificates=self._val("certificates_count"),
        )
        if r["value"] is None:
            self.suggest_lbl.setText("لا تتوفر بيانات كافية للاقتراح.")
            return
        msg = f"العدد المقترح: {r['value']} (أقل الأعداد المتوفرة)"
        if r["warnings"]:
            msg += "\n" + "\n".join(r["warnings"])
        self.suggest_lbl.setText(msg)
        if QMessageBox.question(self, "اعتماد الاقتراح",
                                msg + "\n\nهل تريد اعتماد هذا العدد؟") == QMessageBox.Yes:
            self.widgets["approved_trainees"][0].setValue(value_to_spin(r["value"]))

    def _recalc_finance(self):
        n = self._val("approved_trainees")
        c = self._val("approved_cost_per_trainee")
        h = self._val("approved_hours")
        claimed = self._val("claimed_amount")
        funding = self._val("funding_amount")
        at = finance.approved_total(n, c)
        self.approved_total_lbl.setText(finance.format_money(at) if at is not None else "—")
        ah = finance.approved_hour_cost(c, h)
        self.approved_hour_lbl.setText(finance.format_money(ah) if ah else "—")
        d1 = finance.diff_funding_claimed(funding, claimed)
        d2 = finance.diff_claimed_approved(claimed, at)
        self.diff1_lbl.setText(finance.format_money(d1) if d1 is not None else "—")
        self.diff2_lbl.setText(finance.format_money(d2) if d2 is not None else "—")

    # -- المرفقات (كما كانت) ------------------------------------------------------------------
    def _tab_attachments(self):
        w = QWidget()
        l = QVBoxLayout(w)
        self.attach_list = QListWidget()
        l.addWidget(self.attach_list, 1)
        row = QHBoxLayout()
        btn_add = QPushButton("إرفاق ملف")
        btn_add.clicked.connect(self._attach_add)
        btn_open = QPushButton("فتح")
        btn_open.clicked.connect(self._attach_open)
        btn_del = QPushButton("حذف")
        btn_del.clicked.connect(self._attach_del)
        row.addWidget(btn_add)
        row.addWidget(btn_open)
        row.addWidget(btn_del)
        row.addStretch(1)
        l.addLayout(row)
        self._refresh_attachments()
        return w

    def _refresh_attachments(self):
        self.attach_list.clear()
        for r in self.ctx.conn.execute(
                "SELECT id, original_name, added_at FROM attachments WHERE file_id=? ORDER BY added_at",
                (self.file_id,)):
            self.attach_list.addItem(f"{r['original_name']}  ({r['added_at'][:10]})")
            self.attach_list.item(self.attach_list.count() - 1).setData(Qt.UserRole, r["id"])

    def _attach_add(self):
        if not self._can_do("attachment.manage"):
            QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية إدارة المرفقات.")
            return
        path, _ = QFileDialog.getOpenFileName(self, "اختر المرفق")
        if not path:
            return
        try:
            self.ctx.files.add_attachment(
                self.file_id, path, user_id=self.ctx.user["id"] if self.ctx.user else None)
        except ValueError as exc:
            QMessageBox.warning(self, "تعذر الإرفاق", str(exc))
            return
        self._refresh_attachments()

    def _attach_open(self):
        from .. import config as cfg
        from PySide6.QtGui import QDesktopServices
        from PySide6.QtCore import QUrl
        item = self.attach_list.currentItem()
        if not item:
            return
        r = self.ctx.conn.execute(
            "SELECT stored_name FROM attachments WHERE id=? AND file_id=?",
            (item.data(Qt.UserRole), self.file_id)).fetchone()
        if r:
            QDesktopServices.openUrl(QUrl.fromLocalFile(
                str(cfg.attachments_dir() / str(self.file_id) / r["stored_name"])))

    def _attach_del(self):
        item = self.attach_list.currentItem()
        if not item:
            return
        if not self._can_do("attachment.manage"):
            QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية إدارة المرفقات.")
            return
        if QMessageBox.question(self, "تأكيد", "حذف هذا المرفق نهائيًا؟") != QMessageBox.Yes:
            return
        att_id = item.data(Qt.UserRole)
        try:
            deleted = self.ctx.files.delete_attachment(
                self.file_id, att_id,
                user_id=self.ctx.user["id"] if self.ctx.user else None)
        except ValueError as exc:
            QMessageBox.warning(self, "تعذر الحذف", str(exc))
            return
        if deleted:
            self._refresh_attachments()
        else:
            QMessageBox.warning(self, "تنبيه", "تعذر حذف المرفق.")

    def _tab_status(self):
        w = QWidget()
        l = QVBoxLayout(w)
        g = TitledPanel("تغيير حالة الملف")
        gl = QVBoxLayout(g.content)
        row = QHBoxLayout()
        self.status_cb = QComboBox()
        self.status_notes = HintLineEdit()
        self.status_notes.setPlaceholderText("ملاحظات تغيير الحالة")
        btn = QPushButton("تطبيق")
        btn.setProperty("primary", True)
        btn.clicked.connect(self._change_status)
        self.status_apply_btn = btn
        self.status_hint_lbl = QLabel("")
        row.addWidget(QLabel("الحالة الجديدة:"))
        row.addWidget(self.status_cb)
        row.addWidget(self.status_notes, 1)
        row.addWidget(btn)
        gl.addLayout(row)
        gl.addWidget(self.status_hint_lbl)
        self._fill_status_options()
        l.addWidget(g)
        g2 = TitledPanel("سجل حركة الملف")
        l2 = QVBoxLayout(g2.content)
        self.history_list = QListWidget()
        for h in self.ctx.files.history(self.file_id):
            text = f"{h['changed_at'][:16]} — {h['from_name'] or '—'} ← {h['to_name'] or '—'}"
            if h["user_name"]:
                text += f" ({h['user_name']})"
            if h["notes"]:
                text += f" — {h['notes']}"
            self.history_list.addItem(text)
        l2.addWidget(self.history_list)
        l.addWidget(g2, 1)
        return w

    def _fill_status_options(self):
        """الحالات التالية التي تسمح بها صلاحيات المستخدم الحالي فقط."""
        self.status_cb.clear()
        current = self.record.get("status_code")
        codes = next_statuses_for(current, self._can_do) if current else []
        for code in codes:
            self.status_cb.addItem(STATUS_NAMES.get(code, code), code)
        self.status_apply_btn.setEnabled(bool(codes))
        self.status_hint_lbl.setText(
            "" if codes else "لا تملك صلاحية نقل الملف من حالته الحالية إلى حالة أخرى.")

    def _apply_status(self, code, notes, force):
        """ينفّذ الانتقال. يعيد True عند النجاح؛ وموانع الاعتماد تُرفع لمعالجتها بالاستثناء الموثق."""
        try:
            self.ctx.files.change_status(
                self.file_id, code, user_id=self.ctx.user["id"] if self.ctx.user else None,
                notes=notes, force_exception=force)
        except ApprovalBlocked:
            raise
        except ValueError as exc:  # يشمل رفض الصلاحية
            QMessageBox.warning(self, "تعذر التغيير", str(exc))
            return False
        QMessageBox.information(self, "تم", "تم تغيير الحالة.")
        self.record = self.ctx.files.get(self.file_id)
        self._load_record()
        self._fill_status_options()
        return True

    def _change_status(self):
        code = self.status_cb.currentData()
        if not code:
            return
        notes = self.status_notes.text()
        try:
            self._apply_status(code, notes, False)
        except ApprovalBlocked as blocked:
            self._approve_with_exception(code, notes, blocked)

    def _approve_with_exception(self, code, notes, blocked):
        """اعتماد رغم الموانع: يتطلب صلاحية الاعتماد المالي وسببًا مكتوبًا يُسجَّل في سجل التدقيق."""
        if not self._can_do("finance.approve"):
            QMessageBox.warning(self, "تعذر الاعتماد", str(blocked))
            return
        listing = "\n• ".join(blocked.blockers)
        if QMessageBox.question(
                self, "اعتماد باستثناء موثق",
                f"توجد موانع للاعتماد:\n• {listing}\n\nهل تريد الاعتماد باستثناء موثق؟"
                " (يتطلب كتابة السبب ويُسجَّل في سجل التدقيق)") != QMessageBox.Yes:
            return
        reason, ok = QInputDialog.getText(self, "سبب الاستثناء", "اكتب سبب الاعتماد رغم الموانع:")
        if not ok or not reason.strip():
            QMessageBox.warning(self, "سبب مطلوب", "لا يُعتمد باستثناء موثق دون كتابة السبب.")
            return
        full = f"{notes} — {reason.strip()}" if notes.strip() else reason.strip()
        try:
            self._apply_status(code, full, True)
        except ApprovalBlocked as again:  # لا يُتوقع، للحماية فقط
            QMessageBox.warning(self, "تعذر الاعتماد", str(again))

    # -- تحميل / حفظ -------------------------------------------------------------------
    def _load_record(self):
        self._loading = True
        try:
            self._load_record_inner()
        finally:
            self._loading = False
        # ترخيص الملف كما حُفظ تاريخيًا (لا يُستبدل تلقائيًا بترخيص الجهة الحالي)
        r = self.record
        self._license_snapshot = (r.get("license_issuer"), r.get("license_start"),
                                  r.get("license_end"))
        self._show_license_snapshot()

    def _load_record_inner(self):
        r = self.record
        for key, (w, kind) in self.widgets.items():
            val = r.get(key)
            try:
                if kind == "text":
                    w.setText(str(val) if val not in (None,) else "")
                elif kind == "notes":
                    w.setPlainText(str(val) if val else "")
                elif kind == "int":
                    w.setValue(value_to_spin(val))
                elif kind == "money":
                    w.setValue(float(val or 0))
                elif kind == "date":
                    w.set_iso(val)
                elif kind == "combo":
                    if val:
                        w.setCurrentText(str(val))
                elif kind == "idcombo":
                    if val:
                        idx = w.findData(val)
                        if idx >= 0:
                            w.setCurrentIndex(idx)
                elif kind == "match":
                    if val in MATCH_OPTIONS:
                        w.setCurrentText(val)
            except Exception:
                pass
        self._load_nomination()
        self._load_attendance()
        self._recalc_contract()
        self._recalc_finance()
        self._update_entity_balance()
        self._att_recolor()

    def _load_nomination(self):
        self.nom_table.setRowCount(0)
        if not self.file_id:
            return
        for r in self.ctx.conn.execute(
                "SELECT full_name, beneficiary_id FROM trainees_nomination"
                " WHERE file_id=? ORDER BY seq", (self.file_id,)):
            self._nom_add_row(name=r["full_name"], benef_id=r["beneficiary_id"])
        self._nom_check_count()

    def _load_attendance(self):
        self.att_table.setRowCount(0)
        if not self.file_id:
            return
        for r in self.ctx.conn.execute(
                "SELECT full_name, days_attended, in_supervision_report FROM trainees_attendance"
                " WHERE file_id=? ORDER BY seq", (self.file_id,)):
            self._att_add_row(name=r["full_name"], days=r["days_attended"] or 0,
                              in_report=r["in_supervision_report"])
        self._att_recolor()

    def _collect(self):
        data = {}
        for key, (w, kind) in self.widgets.items():
            if kind == "text":
                data[key] = w.text().strip() or None
            elif kind == "notes":
                data[key] = w.toPlainText().strip() or None
            elif kind == "int":
                data[key] = spin_to_value(w.value())
            elif kind == "money":
                v = w.value()
                data[key] = v if v != 0 else None
            elif kind == "date":
                # يرفع ValueError برسالة واضحة عند إدخال غير صالح — لا حفظ صامت
                data[key] = w.iso_value(self.field_labels.get(key, key))
            elif kind == "combo":
                data[key] = w.currentText().strip() or None
            elif kind == "idcombo":
                data[key] = w.currentData()
            elif kind == "match":
                data[key] = w.currentText().strip() or None
        # ترخيص الجهة: نسخة لحظة الحفظ من أحدث ترخيص للجهة (أو المحفوظ بالملف)
        (data["license_issuer"], data["license_start"],
         data["license_end"]) = self._license_snapshot
        # نهاية التنفيذ لا تسبق بدايتها (تحقق لحظي + خدمي في طبقة الخدمات)
        if data.get("exec_start") and data.get("exec_end") \
                and data["exec_end"] < data["exec_start"]:
            raise ValueError(
                f"تاريخ نهاية التنفيذ ({data['exec_end']}) يسبق تاريخ بداية "
                f"التنفيذ ({data['exec_start']}). صحّح التاريخين قبل الحفظ.")
        return data

    def _save_name_tables(self, file_id):
        conn = self.ctx.conn
        conn.execute("DELETE FROM trainees_nomination WHERE file_id=?", (file_id,))
        for x in self._nom_rows():
            conn.execute(
                "INSERT INTO trainees_nomination (file_id, seq, full_name, beneficiary_id)"
                " VALUES (?,?,?,?)",
                (file_id, x["seq"], x["full_name"], x["beneficiary_id"]))
        conn.execute("DELETE FROM trainees_attendance WHERE file_id=?", (file_id,))
        for x in self._att_rows():
            conn.execute(
                "INSERT INTO trainees_attendance (file_id, seq, full_name, days_attended,"
                " in_supervision_report) VALUES (?,?,?,?,?)",
                (file_id, x["seq"], x["full_name"], x["days_attended"],
                 x["in_supervision_report"]))

    def _is_empty(self, key):
        w, kind = self.widgets[key]
        if kind == "int":
            return spin_to_value(w.value()) is None
        if kind == "idcombo":
            return w.currentData() is None
        return not (w.currentText().strip() if hasattr(w, "currentText") else w.text().strip())

    def save(self):
        # الحقول العامة الإلزامية عند الإنشاء
        if not self.file_id:
            missing = [label for key, label in self.REQUIRED_GENERAL if self._is_empty(key)]
            if missing:
                QMessageBox.warning(self, "حقول إلزامية",
                                    "الحقول التالية إلزامية قبل حفظ الملف:\n• " + "\n• ".join(missing))
                return
        try:
            data = self._collect()
        except ValueError as exc:
            QMessageBox.warning(self, "تعذر الحفظ", str(exc))
            return
        # مزامنة اسم البرنامج النصي مع القائمة المقيدة
        pid = data.get("program_id")
        if pid:
            prow = self.ctx.conn.execute("SELECT name FROM programs WHERE id=?", (pid,)).fetchone()
            data["program_name"] = prow["name"] if prow else None
        uid = self.ctx.user["id"] if self.ctx.user else None
        try:
            if self.file_id:
                if not has_permission(self.ctx.user, "file.update", self.ctx.conn):
                    QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية التعديل.")
                    return
                try:
                    self.ctx.files.update(self.file_id, data, user_id=uid)
                except LockedFields as lock:
                    # بعد الاعتماد: التعديل المالي يتطلب صلاحية الاعتماد وسببًا موثقًا
                    if not self._can_do("finance.approve"):
                        QMessageBox.warning(
                            self, "حقول مالية مقفلة",
                            str(lock) + "\n\nتعديلها بعد الاعتماد يتطلب صلاحية الاعتماد المالي.")
                        return
                    reason, ok = QInputDialog.getText(
                        self, "تعديل موثق بعد الاعتماد",
                        str(lock) + "\n\nاكتب سبب التعديل (يُسجَّل في سجل التدقيق):")
                    if not ok or not reason.strip():
                        return
                    self.ctx.files.update(self.file_id, data, user_id=uid,
                                          allow_locked=True, reason=reason)
                self._save_name_tables(self.file_id)
                self.ctx.conn.commit()
            else:
                if not has_permission(self.ctx.user, "file.create", self.ctx.conn):
                    QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية الإضافة.")
                    return
                new_id = self.ctx.files.create(data, user_id=uid)
                self._save_name_tables(new_id)
                self.ctx.conn.commit()
            self.accept()
        except ValueError as exc:
            QMessageBox.warning(self, "خطأ في البيانات", str(exc))
