# -*- coding: utf-8 -*-
"""صفحة إدارة الملفات: بحث وتصفية وجدول وترقيم صفحات وتصدير."""
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox,
                               QFileDialog, QFormLayout, QGridLayout,
                               QHBoxLayout, QLabel, QMessageBox, QPushButton,
                               QTableWidget, QTableWidgetItem, QVBoxLayout,
                               QWidget, QLineEdit, QSpinBox)

from ..core.finance import format_money
from ..core.workflow import STATUS_NAMES
from ..services.auth_service import has_permission
from ..services.export_service import export_files
from .widgets import rtl_align


class FilesPage(QWidget):
    COLUMNS = [
        ("file_number", "رقم الملف"),
        ("branch_file_number", "رقم الملف في الفرع"),
        ("clearance_number", "رقم التسميح"),
        ("branch_name", "الفرع"),
        ("program_name", "البرنامج"),
        ("beneficiary_name", "الجهة المستفيدة"),
        ("received_date", "تاريخ الاستلام"),
        ("contract_trainees", "عدد العقد"),
        ("approved_trainees", "العدد المعتمد"),
        ("approved_total", "الإجمالي المعتمد"),
        ("status_name", "الحالة"),
    ]

    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.page = 1
        self.per_page = 50
        self.total = 0
        self.filters = {}
        self.current_rows = []
        self.on_open_file = None  # تُضبط من main

        layout = QVBoxLayout(self)

        # -- شريط البحث والتصفية ------------------------------------------------
        filt = QGridLayout()
        filt.setSpacing(8)
        self.q = QLineEdit()
        self.q.setPlaceholderText("بحث: رقم الملف، البرنامج، الجهة، المدرب...")
        self.q.returnPressed.connect(lambda: self.search(1))
        filt.addWidget(QLabel("بحث:"), 0, 5)
        filt.addWidget(self.q, 0, 4, 1, 1)

        self.branch_cb = QComboBox()
        self.field_cb = QComboBox()
        self.status_cb = QComboBox()
        self.benef_cb = QComboBox()
        self.impl_cb = QComboBox()
        filt.addWidget(QLabel("الفرع:"), 0, 3)
        filt.addWidget(self.branch_cb, 0, 2)
        filt.addWidget(QLabel("المجال:"), 1, 3)
        filt.addWidget(self.field_cb, 1, 2)
        filt.addWidget(QLabel("الحالة:"), 1, 5)
        filt.addWidget(self.status_cb, 1, 4)
        filt.addWidget(QLabel("الجهة المستفيدة:"), 2, 5)
        filt.addWidget(self.benef_cb, 2, 4)
        filt.addWidget(QLabel("الجهة المنفذة:"), 2, 3)
        filt.addWidget(self.impl_cb, 2, 2)

        btn_search = QPushButton("بحث")
        btn_search.setProperty("primary", True)
        btn_search.clicked.connect(lambda: self.search(1))
        filt.addWidget(btn_search, 0, 0)
        btn_clear = QPushButton("مسح")
        btn_clear.clicked.connect(self.clear_filters)
        filt.addWidget(btn_clear, 1, 0)
        layout.addLayout(filt)

        # -- أزرار الإجراءات ------------------------------------------------------
        actions = QHBoxLayout()
        self.btn_add = QPushButton("＋ ملف جديد")
        self.btn_add.setProperty("primary", True)
        self.btn_add.clicked.connect(self.add_file)
        self.btn_edit = QPushButton("تعديل")
        self.btn_edit.clicked.connect(self.edit_file)
        self.btn_copy = QPushButton("نسخ ملف")
        self.btn_copy.clicked.connect(self.copy_file)
        self.btn_review_form = QPushButton("طباعة استمارة المراجعة")
        self.btn_review_form.setProperty("ok", True)
        self.btn_review_form.clicked.connect(self.print_review_form)
        self.btn_export = QPushButton("تصدير إلى Excel")
        self.btn_export.clicked.connect(self.export_current)
        actions.addWidget(self.btn_add)
        actions.addWidget(self.btn_edit)
        actions.addWidget(self.btn_copy)
        actions.addWidget(self.btn_review_form)
        actions.addWidget(self.btn_export)
        actions.addStretch(1)
        layout.addLayout(actions)

        # -- الجدول ------------------------------------------------------------------
        self.table = QTableWidget()
        self.table.setColumnCount(len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels([t for _, t in self.COLUMNS])
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.doubleClicked.connect(self.edit_file)
        layout.addWidget(self.table, 1)

        # -- ترقيم الصفحات -------------------------------------------------------------
        pager = QHBoxLayout()
        self.btn_prev = QPushButton("السابق")
        self.btn_next = QPushButton("التالي")
        self.btn_prev.clicked.connect(lambda: self.search(self.page - 1))
        self.btn_next.clicked.connect(lambda: self.search(self.page + 1))
        self.page_lbl = QLabel("")
        self.page_lbl.setAlignment(Qt.AlignCenter)
        pager.addWidget(self.btn_prev)
        pager.addWidget(self.page_lbl, 1)
        pager.addWidget(self.btn_next)
        layout.addLayout(pager)

        self._load_lookups()

    def _load_lookups(self):
        conn = self.ctx.conn
        self.branch_cb.clear()
        self.branch_cb.addItem("الكل", None)
        for r in conn.execute("SELECT id, name FROM branches WHERE active=1 ORDER BY name"):
            self.branch_cb.addItem(r["name"], r["id"])
        self.field_cb.clear()
        self.field_cb.addItem("الكل", None)
        for r in conn.execute("SELECT id, name FROM program_fields WHERE active=1 ORDER BY name"):
            self.field_cb.addItem(r["name"], r["id"])
        self.status_cb.clear()
        self.status_cb.addItem("الكل", None)
        for r in conn.execute("SELECT code, name FROM file_statuses WHERE active=1 ORDER BY sort_order"):
            self.status_cb.addItem(r["name"], r["code"])
        self.benef_cb.clear()
        self.benef_cb.addItem("الكل", None)
        for r in conn.execute("SELECT id, name FROM entities WHERE kind='beneficiary' AND active=1 ORDER BY name"):
            self.benef_cb.addItem(r["name"], r["id"])
        self.impl_cb.clear()
        self.impl_cb.addItem("الكل", None)
        for r in conn.execute("SELECT id, name FROM entities WHERE kind='implementing' AND active=1 ORDER BY name"):
            self.impl_cb.addItem(r["name"], r["id"])
        rtl_align(self)

    def set_filters(self, filters: dict):
        """فلاتر قادمة من لوحة التحكم."""
        self.filters = dict(filters)
        # إعادة ضبط عناصر الواجهة البسيطة
        self.q.setText("")
        self.search(1)

    def clear_filters(self):
        self.filters = {}
        self.q.setText("")
        self.branch_cb.setCurrentIndex(0)
        self.field_cb.setCurrentIndex(0)
        self.status_cb.setCurrentIndex(0)
        self.benef_cb.setCurrentIndex(0)
        self.impl_cb.setCurrentIndex(0)
        self.search(1)

    def _collect_filters(self):
        f = dict(self.filters)
        if self.q.text().strip():
            f["q"] = self.q.text().strip()
        if self.branch_cb.currentData():
            f["branch_id"] = self.branch_cb.currentData()
        if self.field_cb.currentData():
            f["field_id"] = self.field_cb.currentData()
        if self.status_cb.currentData():
            f["status_code"] = self.status_cb.currentData()
        if self.benef_cb.currentData():
            f["beneficiary_id"] = self.benef_cb.currentData()
        if self.impl_cb.currentData():
            f["implementing_id"] = self.impl_cb.currentData()
        # فلاتر خاصة من لوحة التحكم
        if f.pop("in_review", False):
            f["status_codes"] = ["tech_review", "finance_review", "ready_approve"]
        if f.pop("rejected_or_returned", False):
            f["status_codes"] = ["rejected", "returned"]
        if f.pop("overdue", False):
            f["overdue"] = True
        return f

    def search(self, page: int):
        if page < 1:
            return
        filters = self._collect_filters()
        rows, total = self._do_search(filters, page)
        self.current_rows = rows
        self.total = total
        self.page = page
        self._fill_table(rows)
        pages = max(1, (total + self.per_page - 1) // self.per_page)
        self.page_lbl.setText(f"صفحة {page} من {pages} — إجمالي {total} ملف")
        self.btn_prev.setEnabled(page > 1)
        self.btn_next.setEnabled(page < pages)

    def _do_search(self, filters, page):
        if filters.pop("overdue", False):
            filters["overdue_days"] = int(self.ctx.settings().get("review_deadline_days", 30))
        return self.ctx.files.search(filters, page=page, per_page=self.per_page)

    def _fill_table(self, rows):
        self.table.setRowCount(len(rows))
        for i, r in enumerate(rows):
            for j, (key, _t) in enumerate(self.COLUMNS):
                val = r.get(key)
                if key == "approved_total":
                    text = format_money(val)
                elif val is None:
                    text = "—"
                else:
                    text = str(val)
                item = QTableWidgetItem(text)
                item.setData(Qt.UserRole, r["id"])
                if key in ("file_number", "contract_trainees", "approved_trainees"):
                    item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(i, j, item)
        self.table.resizeColumnsToContents()

    def selected_file_id(self):
        row = self.table.currentRow()
        if row < 0:
            return None
        item = self.table.item(row, 0)
        return item.data(Qt.UserRole) if item else None

    def add_file(self):
        if not has_permission(self.ctx.user, "file.create", self.ctx.conn):
            QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية إضافة ملف.")
            return
        from .file_dialog import FileDialog
        dlg = FileDialog(self.ctx, parent=self)
        if dlg.exec():
            self.search(self.page)

    def edit_file(self):
        fid = self.selected_file_id()
        if not fid:
            QMessageBox.information(self, "تنبيه", "اختر ملفًا من الجدول أولًا.")
            return
        if self.on_open_file:
            self.on_open_file(fid)
        else:
            from .file_dialog import FileDialog
            dlg = FileDialog(self.ctx, file_id=fid, parent=self)
            if dlg.exec():
                self.search(self.page)

    def copy_file(self):
        fid = self.selected_file_id()
        if not fid:
            QMessageBox.information(self, "تنبيه", "اختر ملفًا من الجدول أولًا.")
            return
        if not has_permission(self.ctx.user, "file.create", self.ctx.conn):
            QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية إضافة ملف.")
            return
        rec = self.ctx.files.get(fid)
        dlg = QDialog(self)
        dlg.setWindowTitle(f"نسخ الملف رقم {rec.get('file_number')}")
        form = QFormLayout(dlg)
        form.setLabelAlignment(Qt.AlignRight)
        num_spin = QSpinBox()
        num_spin.setRange(1, 999999)
        num_spin.setValue((rec.get("file_number") or 0) + 1)
        chk_nom = QCheckBox("نسخ أسماء المرشحين")
        chk_nom.setChecked(True)
        chk_att = QCheckBox("نسخ كشف الحضور")
        chk_att.setChecked(True)
        form.addRow("رقم الملف الجديد:", num_spin)
        form.addRow(chk_nom)
        form.addRow(chk_att)
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.button(QDialogButtonBox.Ok).setText("نسخ")
        btns.button(QDialogButtonBox.Cancel).setText("إلغاء")
        btns.accepted.connect(dlg.accept)
        btns.rejected.connect(dlg.reject)
        form.addRow(btns)
        rtl_align(dlg)
        if dlg.exec() != QDialog.Accepted:
            return
        try:
            new_id = self.ctx.files.duplicate_file(
                fid, num_spin.value(),
                copy_nomination=chk_nom.isChecked(),
                copy_attendance=chk_att.isChecked(),
                user_id=self.ctx.user["id"] if self.ctx.user else None)
            QMessageBox.information(self, "تم", f"تم نسخ الملف إلى الرقم {num_spin.value()}.")
            self.search(self.page)
        except ValueError as exc:
            QMessageBox.warning(self, "تعذر النسخ", str(exc))

    def print_review_form(self):
        fid = self.selected_file_id()
        if not fid:
            QMessageBox.information(self, "تنبيه", "اختر ملفًا من الجدول أولًا.")
            return
        if self.on_open_file:
            self.on_open_file(fid, open_review=True)

    def export_current(self):
        if not has_permission(self.ctx.user, "export", self.ctx.conn):
            QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية التصدير.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "تصدير إلى Excel", "كشف_الملفات.xlsx", "Excel (*.xlsx)")
        if not path:
            return
        filters = self._collect_filters()
        rows, _total = self.ctx.files.search(filters, page=1, per_page=100000)
        try:
            export_files(rows, Path(path), title="كشف الملفات",
                         filters_desc=self._filters_desc(filters))
            QMessageBox.information(self, "تم", f"تم تصدير {len(rows)} سجلًا بنجاح.")
        except Exception as exc:
            QMessageBox.critical(self, "خطأ", f"فشل التصدير: {exc}")

    def _filters_desc(self, filters):
        parts = []
        if filters.get("q"):
            parts.append(f"بحث={filters['q']}")
        return "، ".join(parts) if parts else "بدون تصفية"

    def refresh(self):
        self._load_lookups()
        self.search(1)
