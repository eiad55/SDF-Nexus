# -*- coding: utf-8 -*-
"""صفحة إدارة الملفات: بحث وتصفية وجدول وترقيم صفحات وتصدير."""
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox,
                               QFileDialog, QFormLayout, QFrame, QGridLayout,
                               QHBoxLayout, QLabel, QMenu, QMessageBox,
                               QProgressBar, QPushButton, QTableWidget,
                               QTableWidgetItem, QToolButton, QVBoxLayout,
                               QWidget, QLineEdit, QSpinBox)

from ..core.finance import format_money
from ..core.workflow import STATUS_NAMES
from ..services.auth_service import has_permission
from ..services.export_service import export_files
from .widgets import rtl_align


class FilesPage(QWidget):
    COLUMNS = [
        ("file_number", "رقم الملف"),
        ("branch_file_number", "رقم الملف في الفرع"),
        ("clearance_number", "رقم التسميح"),
        ("branch_name", "الفرع"),
        ("program_name", "البرنامج"),
        ("beneficiary_name", "الجهة المستفيدة"),
        ("received_date", "تاريخ الاستلام"),
        ("contract_trainees", "عدد العقد"),
        ("approved_trainees", "العدد المعتمد"),
        ("approved_total", "الإجمالي المعتمد"),
        ("status_name", "الحالة"),
        ("completion", "اكتمال المستندات"),
    ]

    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.page = 1
        self.per_page = 50
        self.total = 0
        self.filters = {}
        self.current_rows = []
        self.on_open_file = None  # تُضبط من main

        layout = QVBoxLayout(self)

        # -- شريط البحث والتصفية ------------------------------------------------
        filt = QGridLayout()
        filt.setSpacing(8)
        self.q = QLineEdit()
        self.q.setPlaceholderText("بحث: رقم الملف، البرنامج، الجهة، المدرب...")
        self.q.returnPressed.connect(lambda: self.search(1))
        filt.addWidget(QLabel("بحث:"), 0, 4)
        filt.addWidget(self.q, 0, 5, 1, 1)

        self.branch_cb = QComboBox()
        self.field_cb = QComboBox()
        self.status_cb = QComboBox()
        self.benef_cb = QComboBox()
        self.impl_cb = QComboBox()
        # عرض أقصى موحّد: بلا حقول فارغة ممتدة بعرض الشاشة (تدقيق صور v16)
        for _cb in (self.branch_cb, self.field_cb, self.status_cb,
                    self.benef_cb, self.impl_cb):
            _cb.setMaximumWidth(300)
        filt.addWidget(QLabel("الفرع:"), 0, 2)
        filt.addWidget(self.branch_cb, 0, 3)
        filt.addWidget(QLabel("المجال:"), 1, 2)
        filt.addWidget(self.field_cb, 1, 3)
        filt.addWidget(QLabel("الحالة:"), 1, 4)
        filt.addWidget(self.status_cb, 1, 5)
        filt.addWidget(QLabel("الجهة المستفيدة:"), 2, 4)
        filt.addWidget(self.benef_cb, 2, 5)
        filt.addWidget(QLabel("الجهة المنفذة:"), 2, 2)
        filt.addWidget(self.impl_cb, 2, 3)

        btn_search = QPushButton("بحث")
        btn_search.setProperty("primary", True)
        btn_search.clicked.connect(lambda: self.search(1))
        filt.addWidget(btn_search, 0, 0)
        btn_clear = QPushButton("مسح")
        btn_clear.clicked.connect(self.clear_filters)
        filt.addWidget(btn_clear, 1, 0)
        layout.addLayout(filt)

        # -- أزرار الإجراءات ------------------------------------------------------
        actions = QHBoxLayout()
        self.btn_add = QPushButton("＋ ملف جديد")
        self.btn_add.setProperty("primary", True)
        self.btn_add.setToolTip("إضافة ملف تدريبي جديد")
        self.btn_add.clicked.connect(self.add_file)
        self.btn_edit = QPushButton("تعديل")
        self.btn_edit.setToolTip("فتح الملف المحدد للتعديل (أو Enter / نقر مزدوج)")
        self.btn_edit.clicked.connect(self.edit_file)
        self.btn_copy = QPushButton("نسخ ملف")
        self.btn_copy.setToolTip("إنشاء نسخة من الملف المحدد برقم ملف جديد")
        self.btn_copy.clicked.connect(self.copy_file)
        self.btn_review_form = QPushButton("طباعة استمارة المراجعة")
        self.btn_review_form.setProperty("ok", True)
        self.btn_review_form.setToolTip("فتح الملف المحدد في المراجعة الفنية لطباعة الاستمارة")
        self.btn_review_form.clicked.connect(self.print_review_form)
        self.btn_export = QPushButton("تصدير إلى Excel")
        self.btn_export.setToolTip("تصدير القائمة المعروضة الآن (بنفس البحث والفلاتر) إلى Excel")
        self.btn_export.clicked.connect(self.export_current)
        # حذف الملفات: لمدير النظام فقط (يُفرض أيضًا في طبقة الخدمة)
        self.btn_delete = QPushButton("حذف المحدد")
        self.btn_delete.setToolTip("حذف الملفات المحددة نهائيًا — لمدير النظام فقط، مع تأكيد وتدقيق")
        self.btn_delete.clicked.connect(self.delete_selected)
        self.btn_delete.setVisible(bool(ctx.user) and ctx.user.get("role") == "admin")
        actions.addWidget(self.btn_add)
        actions.addWidget(self.btn_edit)
        actions.addWidget(self.btn_copy)
        actions.addWidget(self.btn_review_form)
        actions.addWidget(self.btn_export)
        actions.addWidget(self.btn_delete)
        # إظهار/إخفاء الأعمدة (يُحفظ اختيار المستخدم)
        self.btn_columns = QToolButton()
        self.btn_columns.setText("الأعمدة ▾")
        self.btn_columns.setToolTip("اختيار الأعمدة الظاهرة في الجدول")
        self.btn_columns.setPopupMode(QToolButton.InstantPopup)
        self._columns_menu = QMenu(self.btn_columns)
        self.btn_columns.setMenu(self._columns_menu)
        actions.addWidget(self.btn_columns)
        # إجراءات جماعية موسعة على الملفات المحددة
        self.btn_bulk = QToolButton()
        self.btn_bulk.setText("إجراءات جماعية ▾")
        self.btn_bulk.setToolTip("إجراءات على كل الملفات المحددة في الجدول دفعة واحدة")
        self.btn_bulk.setPopupMode(QToolButton.InstantPopup)
        bulk_menu = QMenu(self.btn_bulk)
        bulk_menu.addAction("طباعة استمارات المراجعة للمحدد (PDF واحد)",
                            self.print_selected_forms)
        bulk_menu.addAction("تصدير المحدد إلى Excel", self.export_selected)
        if self.btn_delete.isVisible():
            bulk_menu.addSeparator()
            bulk_menu.addAction("حذف المحدد نهائيًا", self.delete_selected)
        self.btn_bulk.setMenu(bulk_menu)
        actions.addWidget(self.btn_bulk)
        # معاينة سريعة جانبية
        self.btn_preview = QPushButton("معاينة سريعة")
        self.btn_preview.setCheckable(True)
        self.btn_preview.setToolTip("لوحة جانبية تلخص الملف المحدد دون فتحه")
        self.btn_preview.toggled.connect(self._toggle_preview)
        actions.addWidget(self.btn_preview)
        actions.addStretch(1)
        layout.addLayout(actions)

        # -- الجدول ------------------------------------------------------------------
        self.table = QTableWidget()
        self.table.setColumnCount(len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels([t for _, t in self.COLUMNS])
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.doubleClicked.connect(self.edit_file)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._context_menu)
        self.table.installEventFilter(self)
        self.table.itemSelectionChanged.connect(self._update_preview)
        self.table.itemSelectionChanged.connect(self._update_sel_count)
        body = QHBoxLayout()
        table_box = QVBoxLayout()
        table_box.addWidget(self.table, 1)
        body.addLayout(table_box, 1)
        # لوحة المعاينة السريعة
        self.preview = QFrame()
        self.preview.setObjectName("previewPanel")
        self.preview.setFixedWidth(272)
        self.preview.setStyleSheet(
            "#previewPanel { background: white; border: 1px solid #D5DCE8;"
            " border-radius: 10px; }")
        pv = QVBoxLayout(self.preview)
        pv.setContentsMargins(12, 12, 12, 12)
        pv_title = QLabel("معاينة سريعة")
        pv_title.setStyleSheet("font-weight: bold; font-size: 14px; color: #1F3A5F;")
        pv.addWidget(pv_title)
        self.pv_body = QLabel("اختر ملفًا من الجدول لعرض ملخصه هنا.")
        self.pv_body.setWordWrap(True)
        self.pv_body.setAlignment(Qt.AlignRight | Qt.AlignTop)
        pv.addWidget(self.pv_body)
        self.pv_bar = QProgressBar()
        self.pv_bar.setRange(0, 100)
        self.pv_bar.setAlignment(Qt.AlignCenter)
        pv.addWidget(self.pv_bar)
        pv.addStretch(1)
        self.preview.setVisible(False)
        body.addWidget(self.preview)
        layout.addLayout(body, 1)
        # تلميح الحالة الفارغة (يظهر فوق الجدول عند غياب النتائج)
        self.empty_hint = QLabel("لا توجد ملفات لعرضها — أضف ملفًا جديدًا أو عدّل شروط البحث", self.table)
        self.empty_hint.setAlignment(Qt.AlignCenter)
        self.empty_hint.setStyleSheet(
            "color: #8A97AD; font-size: 14px; background: transparent;")
        self.empty_hint.hide()

        # -- ترقيم الصفحات -------------------------------------------------------------
        pager = QHBoxLayout()
        self.btn_prev = QPushButton("السابق")
        self.btn_next = QPushButton("التالي")
        self.btn_prev.clicked.connect(lambda: self.search(self.page - 1))
        self.btn_next.clicked.connect(lambda: self.search(self.page + 1))
        self.page_lbl = QLabel("")
        self.page_lbl.setAlignment(Qt.AlignCenter)
        self.sel_lbl = QLabel("")
        self.sel_lbl.setStyleSheet("color: #1F3A5F; font-weight: bold;")
        pager.addWidget(self.sel_lbl)
        pager.addWidget(self.btn_prev)
        pager.addWidget(self.page_lbl, 1)
        pager.addWidget(self.btn_next)
        layout.addLayout(pager)

        self._build_columns_menu()
        self._restore_view_prefs()
        self._load_lookups()

    # -- تفضيلات العرض (أعمدة/معاينة) --------------------------------------
    def _view_settings(self):
        from PySide6.QtCore import QSettings
        return QSettings("SkillsDevelopmentFund", "SDFBranchSystem")

    def _user_key(self, what):
        user = (self.ctx.user or {}).get("username", "anon")
        return f"ui/{user}/{what}"

    def _build_columns_menu(self):
        self._columns_menu.clear()
        for j, (_key, title) in enumerate(self.COLUMNS):
            act = self._columns_menu.addAction(title)
            act.setCheckable(True)
            act.setChecked(True)
            act.toggled.connect(lambda on, col=j: self._set_column_visible(col, on))

    def _set_column_visible(self, col: int, on: bool):
        self.table.setColumnHidden(col, not on)
        st = self._view_settings()
        hidden = [j for j in range(len(self.COLUMNS)) if self.table.isColumnHidden(j)]
        st.setValue(self._user_key("files_hidden_columns"), hidden)

    def _restore_view_prefs(self):
        st = self._view_settings()
        hidden = st.value(self._user_key("files_hidden_columns"), []) or []
        for j in hidden:
            try:
                j = int(j)
            except (TypeError, ValueError):
                continue
            if 0 <= j < len(self.COLUMNS):
                self.table.setColumnHidden(j, True)
                self._columns_menu.actions()[j].setChecked(False)
        show_pv = st.value(self._user_key("files_preview"), False)
        if show_pv in (True, "true", "True", 1, "1"):
            self.btn_preview.setChecked(True)

    def _toggle_preview(self, on: bool):
        self.preview.setVisible(on)
        self._view_settings().setValue(self._user_key("files_preview"), bool(on))
        if on:
            self._update_preview()

    # -- معاينة سريعة ---------------------------------------------------------
    def _update_preview(self):
        if not self.preview.isVisible():
            return
        fid = self.selected_file_id()
        if not fid:
            self.pv_body.setText("اختر ملفًا من الجدول لعرض ملخصه هنا.")
            self.pv_bar.setValue(0)
            return
        rec = self.ctx.files.get(fid) or {}
        comp = self.ctx.files.completion_map([fid]).get(fid, 0)
        hist = self.ctx.files.last_history(fid)
        lines = [
            f"الملف رقم {rec.get('file_number')} — {rec.get('program_name') or ''}",
            f"الحالة: {rec.get('status_name') or '—'}",
            f"الفرع: {rec.get('branch_name') or '—'}",
            f"الجهة المنفذة: {rec.get('implementing_name') or '—'}",
            f"المشرف: {rec.get('supervisor_name') or '—'}",
            f"المتدربون المعتمدون: {rec.get('approved_trainees') or '—'}",
            f"الإجمالي المعتمد: {format_money(rec.get('approved_total'))}",
        ]
        if hist:
            move = hist.get("to_name") or hist.get("notes") or "تغيير حالة"
            lines.append(f"آخر حركة: {move} ({(hist.get('changed_at') or '')[:10]})")
        self.pv_body.setText(chr(10).join(lines))
        self.pv_bar.setValue(comp)
        self.pv_bar.setFormat(f"اكتمال المستندات: {comp}%")

    # -- قائمة سياق وفتح بلوحة المفاتيح ----------------------------------------
    def _context_menu(self, pos):
        fid = self.selected_file_id()
        if not fid:
            return
        menu = QMenu(self)
        menu.addAction("فتح / تعديل", self.edit_file)
        menu.addAction("طباعة استمارة المراجعة", self.print_review_form)
        menu.addAction("نسخ الملف", self.copy_file)
        menu.addSeparator()
        menu.addAction("تصدير القائمة إلى Excel", self.export_current)
        if self.btn_delete.isVisible():
            menu.addSeparator()
            menu.addAction("حذف المحدد نهائيًا", self.delete_selected)
        menu.exec(self.table.viewport().mapToGlobal(pos))

    def eventFilter(self, obj, event):
        from PySide6.QtCore import QEvent
        if obj is self.table and event.type() == QEvent.KeyPress \
                and event.key() in (Qt.Key_Return, Qt.Key_Enter):
            if self.selected_file_id():
                self.edit_file()
                return True
        return super().eventFilter(obj, event)

    def reveal_file(self, file_id: int):
        """إظهار ملف بعينه في الجدول (من البحث العام): مسح التصفية ثم تحديده."""
        self.clear_filters()
        rows, _t = self.ctx.files.search({}, page=1, per_page=100000)
        ids = [r["id"] for r in rows]
        if file_id not in ids:
            return
        page = ids.index(file_id) // self.per_page + 1
        self.search(page)
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 0)
            if item is not None and item.data(Qt.UserRole) == file_id:
                self.table.selectRow(row)
                self.table.setCurrentCell(row, 0)
                self.table.scrollToItem(item)
                break
        self._update_preview()

    def _toast(self, text: str):
        win = self.window()
        if win is not None and hasattr(win, "notify"):
            win.notify(text)

    # -- إجراءات جماعية موسعة ------------------------------------------------
    def _selected_ids(self):
        ids = []
        for idx in self.table.selectedIndexes():
            item = self.table.item(idx.row(), 0)
            if item is not None and item.data(Qt.UserRole) is not None:
                if item.data(Qt.UserRole) not in ids:
                    ids.append(item.data(Qt.UserRole))
        return ids

    def _sync_empty_hint(self, total):
        show = total == 0
        self.empty_hint.setVisible(show)
        if show:
            self.empty_hint.setGeometry(0, 40, self.table.width(),
                                        max(40, self.table.height() - 80))

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if getattr(self, "total", 0) == 0 and hasattr(self, "empty_hint"):
            self._sync_empty_hint(0)

    def _update_sel_count(self):
        n = len(self._selected_ids())
        self.sel_lbl.setText(f"المحدد: {n}" if n else "")

    def print_selected_forms(self):
        ids = self._selected_ids()
        if not ids:
            QMessageBox.information(self, "تنبيه", "حدّد ملفًا واحدًا على الأقل من الجدول.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "حفظ استمارات المراجعة", f"استمارات_مراجعة_{len(ids)}_ملف.pdf",
            "PDF (*.pdf)")
        if not path:
            return
        from ..reports.bulk_forms import build_forms_bundle
        try:
            build_forms_bundle(self.ctx.files, self.ctx.settings(), ids, Path(path))
        except Exception as exc:
            QMessageBox.critical(self, "خطأ", f"فشل إنشاء الاستمارات: {exc}")
            return
        self._toast(f"أُنشئ PDF واحد يضم استمارات {len(ids)} ملف")

    def export_selected(self):
        if not has_permission(self.ctx.user, "export", self.ctx.conn):
            QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية التصدير.")
            return
        ids = set(self._selected_ids())
        if not ids:
            QMessageBox.information(self, "تنبيه", "حدّد ملفًا واحدًا على الأقل من الجدول.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "تصدير المحدد إلى Excel", "كشف_الملفات_المحددة.xlsx", "Excel (*.xlsx)")
        if not path:
            return
        rows = [r for r in self.current_rows if r["id"] in ids]
        try:
            export_files(rows, Path(path), title="كشف الملفات المحددة",
                         filters_desc=f"تحديد يدوي من الجدول: {len(rows)} ملف")
            self._toast(f"صُدّر {len(rows)} ملف محدد إلى Excel")
        except Exception as exc:
            QMessageBox.critical(self, "خطأ", f"فشل التصدير: {exc}")

    def _load_lookups(self):
        conn = self.ctx.conn
        self.branch_cb.clear()
        self.branch_cb.addItem("الكل", None)
        for r in conn.execute("SELECT id, name FROM branches WHERE active=1 ORDER BY name"):
            self.branch_cb.addItem(r["name"], r["id"])
        self.field_cb.clear()
        self.field_cb.addItem("الكل", None)
        for r in conn.execute("SELECT id, name FROM program_fields WHERE active=1 ORDER BY name"):
            self.field_cb.addItem(r["name"], r["id"])
        self.status_cb.clear()
        self.status_cb.addItem("الكل", None)
        for r in conn.execute("SELECT code, name FROM file_statuses WHERE active=1 ORDER BY sort_order"):
            self.status_cb.addItem(r["name"], r["code"])
        self.benef_cb.clear()
        self.benef_cb.addItem("الكل", None)
        for r in conn.execute("SELECT id, name FROM entities WHERE kind='beneficiary' AND active=1 ORDER BY name"):
            self.benef_cb.addItem(r["name"], r["id"])
        self.impl_cb.clear()
        self.impl_cb.addItem("الكل", None)
        for r in conn.execute("SELECT id, name FROM entities WHERE kind='implementing' AND active=1 ORDER BY name"):
            self.impl_cb.addItem(r["name"], r["id"])
        rtl_align(self)

    def set_filters(self, filters: dict):
        """فلاتر قادمة من لوحة التحكم."""
        self.filters = dict(filters)
        # إعادة ضبط عناصر الواجهة البسيطة
        self.q.setText("")
        self.search(1)

    def clear_filters(self):
        self.filters = {}
        self.q.setText("")
        self.branch_cb.setCurrentIndex(0)
        self.field_cb.setCurrentIndex(0)
        self.status_cb.setCurrentIndex(0)
        self.benef_cb.setCurrentIndex(0)
        self.impl_cb.setCurrentIndex(0)
        self.search(1)

    def _collect_filters(self):
        f = dict(self.filters)
        if self.q.text().strip():
            f["q"] = self.q.text().strip()
        if self.branch_cb.currentData():
            f["branch_id"] = self.branch_cb.currentData()
        if self.field_cb.currentData():
            f["field_id"] = self.field_cb.currentData()
        if self.status_cb.currentData():
            f["status_code"] = self.status_cb.currentData()
        if self.benef_cb.currentData():
            f["beneficiary_id"] = self.benef_cb.currentData()
        if self.impl_cb.currentData():
            f["implementing_id"] = self.impl_cb.currentData()
        # فلاتر خاصة من لوحة التحكم
        if f.pop("in_review", False):
            f["status_codes"] = ["tech_review", "finance_review", "ready_approve"]
        if f.pop("rejected_or_returned", False):
            f["status_codes"] = ["rejected", "returned"]
        if f.pop("overdue", False):
            f["overdue"] = True
        return f

    def search(self, page: int):
        if page < 1:
            return
        filters = self._collect_filters()
        rows, total = self._do_search(filters, page)
        self.current_rows = rows
        self.total = total
        self.page = page
        self._fill_table(rows)
        self._sync_empty_hint(total)
        pages = max(1, (total + self.per_page - 1) // self.per_page)
        filtered = bool(self.q.text().strip() or self.filters
                        or self.branch_cb.currentData() or self.field_cb.currentData()
                        or self.status_cb.currentData() or self.benef_cb.currentData()
                        or self.impl_cb.currentData())
        if filtered:
            _rows, grand = self.ctx.files.search({}, page=1, per_page=1)
            self.page_lbl.setText(
                f"صفحة {page} من {pages} — عرض {len(rows)} من {total} ملف (بعد التصفية من إجمالي {grand})")
        else:
            self.page_lbl.setText(f"صفحة {page} من {pages} — إجمالي {total} ملف")
        self.btn_prev.setEnabled(page > 1)
        self.btn_next.setEnabled(page < pages)

    def _do_search(self, filters, page):
        if filters.pop("overdue", False):
            filters["overdue_days"] = int(self.ctx.settings().get("review_deadline_days", 30))
        return self.ctx.files.search(filters, page=page, per_page=self.per_page)

    def _fill_table(self, rows):
        self.table.setRowCount(len(rows))
        comp_map = self.ctx.files.completion_map([r["id"] for r in rows])
        for i, r in enumerate(rows):
            for j, (key, _t) in enumerate(self.COLUMNS):
                if key == "completion":
                    item = QTableWidgetItem("")
                    item.setData(Qt.UserRole, r["id"])
                    self.table.setItem(i, j, item)
                    pct = comp_map.get(r["id"], 0)
                    bar = QProgressBar()
                    bar.setRange(0, 100)
                    bar.setValue(pct)
                    bar.setFormat(f"{pct}%")
                    bar.setAlignment(Qt.AlignCenter)
                    bar.setMaximumHeight(16)
                    bar.setToolTip(f"اكتمال مستندات الملف: {pct}%")
                    self.table.setCellWidget(i, j, bar)
                    continue
                val = r.get(key)
                if key == "approved_total":
                    text = format_money(val)
                elif val is None:
                    text = "—"
                else:
                    text = str(val)
                item = QTableWidgetItem(text)
                item.setData(Qt.UserRole, r["id"])
                if key in ("file_number", "contract_trainees", "approved_trainees"):
                    item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(i, j, item)
        self.table.resizeColumnsToContents()

    def selected_file_id(self):
        row = self.table.currentRow()
        if row < 0:
            # احتياط: صف محدد بلا خلية جارية (يحدث برمجيًا في بعض المنصات)
            selected = self.table.selectionModel().selectedRows()
            if not selected:
                return None
            row = selected[0].row()
        item = self.table.item(row, 0)
        return item.data(Qt.UserRole) if item else None

    def add_file(self):
        if not has_permission(self.ctx.user, "file.create", self.ctx.conn):
            QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية إضافة ملف.")
            return
        from .file_dialog import FileDialog
        dlg = FileDialog(self.ctx, parent=self)
        if dlg.exec():
            self.search(self.page)
            self._toast("أُضيف ملف تدريبي جديد")

    def edit_file(self):
        fid = self.selected_file_id()
        if not fid:
            QMessageBox.information(self, "تنبيه", "اختر ملفًا من الجدول أولًا.")
            return
        if self.on_open_file:
            self.on_open_file(fid)
        else:
            from .file_dialog import FileDialog
            dlg = FileDialog(self.ctx, file_id=fid, parent=self)
            if dlg.exec():
                self.search(self.page)
                self._toast("حُفظت تعديلات الملف")

    def delete_selected(self):
        """حذف ملف/ملفات محددة (10.3): تأكيد صريح بالعدد والأرقام قبل التنفيذ."""
        rows = sorted({i.row() for i in self.table.selectedIndexes()})
        ids, numbers = [], []
        for r in rows:
            item = self.table.item(r, 0)
            if item is not None and item.data(Qt.UserRole) is not None:
                ids.append(item.data(Qt.UserRole))
                numbers.append(item.text())
        if not ids:
            QMessageBox.information(self, "تنبيه", "اختر ملفًا واحدًا على الأقل لحذفه.")
            return
        shown = "، ".join(numbers[:10]) + ("…" if len(numbers) > 10 else "")
        if QMessageBox.question(
                self, "تأكيد الحذف النهائي",
                f"سيُحذف نهائيًا {len(ids)} ملف: {shown}\n"
                "يشمل الحذف بنود المراجعة وقوائم المتدربين والمرفقات وسجل حركة "
                "الملف، ويُسجَّل في سجل التدقيق. لا يمكن التراجع.\nمتابعة؟",
        ) != QMessageBox.Yes:
            return
        try:
            res = self.ctx.files.delete_files(
                ids, user_id=self.ctx.user["id"] if self.ctx.user else None)
        except (PermissionError, ValueError) as exc:
            QMessageBox.warning(self, "تعذر الحذف", str(exc))
            return
        self.search(self.page)
        self._toast(f"حُذف {res['count']} ملف نهائيًا")

    def copy_file(self):
        fid = self.selected_file_id()
        if not fid:
            QMessageBox.information(self, "تنبيه", "اختر ملفًا من الجدول أولًا.")
            return
        if not has_permission(self.ctx.user, "file.create", self.ctx.conn):
            QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية إضافة ملف.")
            return
        rec = self.ctx.files.get(fid)
        dlg = QDialog(self)
        dlg.setWindowTitle(f"نسخ الملف رقم {rec.get('file_number')}")
        form = QFormLayout(dlg)
        form.setLabelAlignment(Qt.AlignRight)
        num_spin = QSpinBox()
        num_spin.setRange(1, 999999)
        num_spin.setValue((rec.get("file_number") or 0) + 1)
        chk_nom = QCheckBox("نسخ أسماء المرشحين")
        chk_nom.setChecked(True)
        chk_att = QCheckBox("نسخ كشف الحضور")
        chk_att.setChecked(True)
        form.addRow("رقم الملف الجديد:", num_spin)
        form.addRow(chk_nom)
        form.addRow(chk_att)
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.button(QDialogButtonBox.Ok).setText("نسخ")
        btns.button(QDialogButtonBox.Cancel).setText("إلغاء")
        btns.accepted.connect(dlg.accept)
        btns.rejected.connect(dlg.reject)
        form.addRow(btns)
        rtl_align(dlg)
        if dlg.exec() != QDialog.Accepted:
            return
        try:
            new_id = self.ctx.files.duplicate_file(
                fid, num_spin.value(),
                copy_nomination=chk_nom.isChecked(),
                copy_attendance=chk_att.isChecked(),
                user_id=self.ctx.user["id"] if self.ctx.user else None)
            self.search(self.page)
            self._toast(f"نُسخ الملف إلى الرقم {num_spin.value()}")
        except ValueError as exc:
            QMessageBox.warning(self, "تعذر النسخ", str(exc))

    def print_review_form(self):
        fid = self.selected_file_id()
        if not fid:
            QMessageBox.information(self, "تنبيه", "اختر ملفًا من الجدول أولًا.")
            return
        if self.on_open_file:
            self.on_open_file(fid, open_review=True)

    def export_current(self):
        if not has_permission(self.ctx.user, "export", self.ctx.conn):
            QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية التصدير.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "تصدير إلى Excel", "كشف_الملفات.xlsx", "Excel (*.xlsx)")
        if not path:
            return
        filters = self._collect_filters()
        rows, _total = self.ctx.files.search(filters, page=1, per_page=100000)
        try:
            export_files(rows, Path(path), title="كشف الملفات",
                         filters_desc=self._filters_desc(filters))
            self._toast(f"صُدّر {len(rows)} سجلًا إلى Excel")
        except Exception as exc:
            QMessageBox.critical(self, "خطأ", f"فشل التصدير: {exc}")

    def _filters_desc(self, filters):
        parts = []
        if filters.get("q"):
            parts.append(f"بحث={filters['q']}")
        return "، ".join(parts) if parts else "بدون تصفية"

    def refresh(self):
        self._load_lookups()
        self.search(1)
