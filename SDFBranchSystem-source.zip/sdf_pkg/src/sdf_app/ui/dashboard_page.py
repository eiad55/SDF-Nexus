# -*- coding: utf-8 -*-
"""لوحة التحكم: بطاقات تفاعلية + ترشيح ذاتي + طباعة وتصدير PDF."""
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtPrintSupport import QPrintDialog, QPrinter
from PySide6.QtWidgets import (QFileDialog, QGridLayout, QGroupBox, QHBoxLayout,
                               QLabel, QMessageBox, QPushButton, QScrollArea,
                               QVBoxLayout, QWidget)

from .. import config
from ..core.finance import format_money
from .widgets import BarChart, StatCard, rtl_align


class DashboardPage(QWidget):
    def __init__(self, ctx, on_navigate, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.on_navigate = on_navigate  # دالة (page_key, filters)
        self.cards = {}
        self.active_filter = {}  # {"branch_id":..} أو {"field_id":..} أو {"ym":..}
        self._filter_label = ""
        self._branch_ids = {}
        self._field_ids = {}

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        inner = QWidget()
        self.layout = QVBoxLayout(inner)
        self.layout.setSpacing(14)
        scroll.setWidget(inner)
        self._scroll = scroll

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        # -- صف علوي: الترشيح النشط + الطباعة ---------------------------------
        top = QHBoxLayout()
        self.filter_lbl = QLabel("")
        self.filter_lbl.setStyleSheet("font-weight: bold; color: #B7791F;")
        self.btn_clear_filter = QPushButton("إلغاء الترشيح ✕")
        self.btn_clear_filter.setVisible(False)
        self.btn_clear_filter.clicked.connect(self.clear_filter)
        top.addWidget(self.btn_clear_filter)
        top.addWidget(self.filter_lbl, 1)
        self.btn_print = QPushButton("طباعة اللوحة")
        self.btn_print.clicked.connect(self._print_dashboard)
        self.btn_pdf = QPushButton("تصدير PDF")
        self.btn_pdf.setProperty("ok", True)
        self.btn_pdf.clicked.connect(self._export_pdf)
        top.addWidget(self.btn_print)
        top.addWidget(self.btn_pdf)
        self.layout.addLayout(top)

        # -- بطاقة إجمالي الملفات (مميزة) ---------------------------------------
        self.total_card = StatCard("total", "إجمالي الملفات")
        self.total_card.setStyleSheet(
            "#statCard { border-top: 6px solid #1F3A5F; background: #EAF0F9; }"
            "#statValue { font-size: 40px; }")
        self.total_card.clicked.connect(self._card_clicked)
        self.layout.addWidget(self.total_card)

        # -- بطاقات الحالات -------------------------------------------------------
        grid = QGridLayout()
        grid.setSpacing(12)
        self.card_defs = [
            ("tech_review", "قيد المراجعة الفنية", "#B7791F", {"status_code": "tech_review"}),
            ("finance_review", "قيد المراجعة المالية", "#1565C0", {"status_code": "finance_review"}),
            ("ready_disburse", "جاهزة للصرف", "#2E7D6F", {"status_code": "ready_disburse"}),
            ("disbursed", "منصرفة", "#1E7E34", {"status_code": "disbursed"}),
            ("missing", "لاستكمال النواقص", "#C0392B", {"status_codes": ["missing_docs", "returned"]}),
            ("rejected", "مرفوضة", "#7B1FA2", {"status_code": "rejected"}),
        ]
        for i, (key, title, accent, _) in enumerate(self.card_defs):
            card = StatCard(key, title)
            card.clicked.connect(self._card_clicked)
            card.setStyleSheet(f"#statCard {{ border-top: 4px solid {accent}; }}")
            self.cards[key] = card
            grid.addWidget(card, i // 3, i % 3)
        self.layout.addLayout(grid)

        # -- البطاقات المالية ------------------------------------------------------
        fin_grid = QGridLayout()
        fin_grid.setSpacing(12)
        self.fin_cards = {}
        for i, (key, title) in enumerate([("claimed", "إجمالي المبالغ المطالب بها"),
                                         ("funding", "إجمالي مبالغ التمويل"),
                                         ("diff", "إجمالي الفروقات (مطالب − تمويل)"),
                                         ("trainees", "عدد المتدربين (المعتمد)")]):
            card = StatCard("fin_" + key, title)
            self.fin_cards[key] = card
            fin_grid.addWidget(card, 0, i)
        self.layout.addLayout(fin_grid)

        # -- الرسوم البيانية (قابلة للنقر للترشيح) ----------------------------------
        charts = QHBoxLayout()
        charts.setSpacing(12)

        box1 = QGroupBox("ملفات حسب الفرع — اضغط للترشيح")
        l1 = QVBoxLayout(box1)
        self.chart_branch = BarChart()
        self.chart_branch.barClicked.connect(self._branch_clicked)
        l1.addWidget(self.chart_branch)
        charts.addWidget(box1, 1)

        box2 = QGroupBox("ملفات حسب المجال التدريبي — اضغط للترشيح")
        l2 = QVBoxLayout(box2)
        self.chart_field = BarChart(bar_color="#2E7D6F")
        self.chart_field.barClicked.connect(self._field_clicked)
        l2.addWidget(self.chart_field)
        charts.addWidget(box2, 1)

        box3 = QGroupBox("ملفات حسب شهر التنفيذ — اضغط للترشيح")
        l3 = QVBoxLayout(box3)
        self.chart_month = BarChart(bar_color="#B7791F")
        self.chart_month.barClicked.connect(self._month_clicked)
        l3.addWidget(self.chart_month)
        charts.addWidget(box3, 1)

        self.layout.addLayout(charts)
        self.layout.addStretch(1)
        outer.addWidget(scroll)
        rtl_align(self)

    # -- الترشيح -------------------------------------------------------------------
    def _apply_filter(self, f: dict, label: str):
        self.active_filter = f
        self._filter_label = label
        self.refresh()

    def clear_filter(self):
        self.active_filter = {}
        self._filter_label = ""
        self.refresh()

    def _branch_clicked(self, name: str):
        bid = self._branch_ids.get(name)
        if bid:
            self._apply_filter({"branch_id": bid}, f"الفرع: {name}")

    def _field_clicked(self, name: str):
        fid = self._field_ids.get(name)
        if fid:
            self._apply_filter({"field_id": fid}, f"المجال: {name}")

    def _month_clicked(self, ym: str):
        self._apply_filter({"ym": ym}, f"شهر التنفيذ: {ym}")

    def _card_clicked(self, key: str):
        if key == "total":
            self.on_navigate("files", {})
            return
        for k, _t, _a, filters in self.card_defs:
            if k == key and filters:
                self.on_navigate("files", filters)
                return

    # -- العرض ----------------------------------------------------------------------
    def refresh(self):
        stats = self.ctx.files.dashboard_stats(
            deadline_days=int(self.ctx.settings().get("review_deadline_days", 30)),
            filters=self.active_filter)
        by = stats["by_status"]

        has_f = bool(self.active_filter)
        self.btn_clear_filter.setVisible(has_f)
        self.filter_lbl.setText(f"ترشيح اللوحة: {self._filter_label}" if has_f else "")

        self.total_card.set_value(f"{stats['total']:,}",
                                  "اضغط لعرض كل الملفات" if not has_f else self._filter_label,
                                  "#1F3A5F")
        values = {
            "tech_review": (f"{by.get('tech_review', 0):,}", ""),
            "finance_review": (f"{by.get('finance_review', 0):,}", ""),
            "ready_disburse": (f"{by.get('ready_disburse', 0):,}", ""),
            "disbursed": (f"{by.get('disbursed', 0):,}", ""),
            "missing": (f"{by.get('missing_docs', 0) + by.get('returned', 0):,}", "نواقص + معادة"),
            "rejected": (f"{by.get('rejected', 0):,}", ""),
        }
        accents = {k: a for k, _t, a, _f in self.card_defs}
        for key, card in self.cards.items():
            v, s = values[key]
            card.set_value(v, s, accents[key])

        sums = stats["sums"]
        self.fin_cards["claimed"].set_value(format_money(sums["claimed"]), "", "#1F3A5F")
        self.fin_cards["funding"].set_value(format_money(sums["funding"]), "", "#1E7E34")
        diff = sums["claimed"] - sums["funding"]
        self.fin_cards["diff"].set_value(
            format_money(diff), "سالب = التمويل أعلى" if diff < 0 else "", "#C0392B")
        self.fin_cards["trainees"].set_value(f"{stats['trainees_total']:,}", "مجموع المعتمد", "#5A6B85")

        branches = [(r["name"] or "غير محدد", r["c"]) for r in stats["by_branch"]][:8]
        self._branch_ids = {r["name"] or "غير محدد": r["id"] for r in stats["by_branch"]}
        self.chart_branch.set_data(branches)
        fields = [(r["name"] or "غير محدد", r["c"]) for r in stats["by_field"]][:8]
        self._field_ids = {r["name"] or "غير محدد": r["id"] for r in stats["by_field"]}
        self.chart_field.set_data(fields)
        self.chart_month.set_data([(r["ym"], r["c"]) for r in stats["by_month"]])

    # -- الطباعة والتصدير -------------------------------------------------------------
    # متطلب 6: الطباعة والتصدير PDF يستخدمان مُصيِّرًا واحدًا يرسم محتوى اللوحة
    # الفعلي كما يظهر على الشاشة (البطاقات والرسوم والأقسام نفسها) — لا جداول
    # بديلة — مع تقسيم سليم على صفحات A4 بهوامش، بدل ضغط اللقطة في صفحة واحدة.
    def _paint_dashboard(self, painter, rect, new_page):
        import math
        from PySide6.QtCore import QRectF
        content = self._scroll.widget()
        # منطقة التمرير تُظهر جزءًا من المحتوى فقط: نمدّ الودجت مؤقتًا لارتفاعه
        # الكامل حتى يُرسم كل المحتوى (لا قصّ لما هو أسفل التمرير) ثم نعيده
        orig_size = content.size()
        full_h = content.sizeHint().height()
        resized = full_h > orig_size.height()
        if resized:
            content.resize(orig_size.width(), full_h)
            if content.layout():
                content.layout().activate()
        try:
            cw = max(1, content.width())
            ch = max(1, content.height())
            scale = rect.width() / cw
            slice_h = rect.height() / scale
            pages = max(1, math.ceil(ch / slice_h))
            for i in range(pages):
                if i:
                    new_page()
                painter.save()
                painter.translate(rect.x(), rect.y())
                painter.scale(scale, scale)
                painter.translate(0, -i * slice_h)
                painter.setClipRect(QRectF(0, i * slice_h, cw, slice_h))
                from PySide6.QtCore import QPoint
                content.render(painter, QPoint(0, 0))
                painter.restore()
        finally:
            if resized:
                content.resize(orig_size)

    def _print_dashboard(self):
        from PySide6.QtGui import QPageSize, QPainter
        printer = QPrinter(QPrinter.HighResolution)
        printer.setPageSize(QPageSize(QPageSize.A4))
        dlg = QPrintDialog(printer, self)
        if dlg.exec() != QPrintDialog.Accepted:
            return
        painter = QPainter(printer)
        try:
            rect = printer.pageLayout().paintRectPixels(printer.resolution())
            self._paint_dashboard(painter, rect, printer.newPage)
        finally:
            painter.end()
        QMessageBox.information(self, "تم", "تم إرسال اللوحة إلى الطابعة.")

    def _export_pdf(self):
        path, _ = QFileDialog.getSaveFileName(self, "تصدير لوحة التحكم PDF",
                                              "لوحة_التحكم.pdf", "PDF (*.pdf)")
        if not path:
            return
        try:
            from PySide6.QtCore import QMarginsF
            from PySide6.QtGui import QPageLayout, QPageSize, QPainter, QPdfWriter
            writer = QPdfWriter(path)
            writer.setPageSize(QPageSize(QPageSize.A4))
            writer.setPageMargins(QMarginsF(10, 10, 10, 10), QPageLayout.Millimeter)
            writer.setResolution(300)  # حدّة عالية للنصوص والرسوم كما على الشاشة
            painter = QPainter(writer)
            try:
                rect = writer.pageLayout().paintRectPixels(writer.resolution())
                self._paint_dashboard(painter, rect, writer.newPage)
            finally:
                painter.end()
            QMessageBox.information(self, "تم", f"تم حفظ PDF:\n{path}")
        except Exception as exc:
            QMessageBox.critical(self, "خطأ", f"فشل التصدير: {exc}")
