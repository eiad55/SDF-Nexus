# -*- coding: utf-8 -*-
"""صفحة الصرف: قائمة تراكمية للملفات المقرر صرفها + بيانات الصرف + تأكيد التسليم."""
from datetime import date

from PySide6.QtCore import Qt, QDate
from PySide6.QtWidgets import (QDateEdit, QDialog, QDialogButtonBox, QDoubleSpinBox,
                               QFormLayout, QGroupBox, QHBoxLayout, QLabel,
                               QLineEdit, QMessageBox, QPushButton, QTableWidget,
                               QTableWidgetItem, QVBoxLayout, QWidget, QFileDialog)

from .. import config
from ..core.finance import format_money
from ..reports.disbursement_report import build_disbursement_statement
from ..services.auth_service import has_permission
from .widgets import rtl_align


class DisbursementPage(QWidget):
    COLUMNS = [
        ("file_number", "رقم الملف"),
        ("program_name", "البرنامج"),
        ("beneficiary_name", "الجهة المستفيدة"),
        ("funding_amount", "مبلغ التمويل"),
        ("status_name", "الحالة"),
        ("disburse_amount", "مبلغ الصرف"),
        ("ledger_number", "رقم القيد"),
        ("check_number", "رقم الشيك"),
        ("check_received_date", "تاريخ استلام الشيك"),
        ("recipient_name", "اسم المستلم"),
    ]

    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.items = []  # قائمة تراكمية من file_id
        layout = QVBoxLayout(self)

        # -- بحث وإضافة --------------------------------------------------------------
        g = QGroupBox("إضافة ملفات لقائمة الصرف")
        gl = QVBoxLayout(g)
        row = QHBoxLayout()
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("رقم الملف أو اسم البرنامج ثم Enter")
        self.search_box.returnPressed.connect(self._add_by_search)
        btn_add = QPushButton("إضافة للقائمة")
        btn_add.setProperty("primary", True)
        btn_add.clicked.connect(self._add_by_search)
        row.addWidget(QLabel("بحث:"))
        row.addWidget(self.search_box, 1)
        row.addWidget(btn_add)
        gl.addLayout(row)
        row2 = QHBoxLayout()
        self.lc_search = QLineEdit()
        self.lc_search.setPlaceholderText("رقم القيد أو الشيك للبحث في المنصرفة")
        self.lc_search.returnPressed.connect(self._search_ledger)
        btn_lc = QPushButton("بحث في المنصرفة")
        btn_lc.clicked.connect(self._search_ledger)
        row2.addWidget(QLabel("بحث صرف:"))
        row2.addWidget(self.lc_search, 1)
        row2.addWidget(btn_lc)
        gl.addLayout(row2)
        layout.addWidget(g)

        # -- الجدول التراكمي ------------------------------------------------------------
        self.table = QTableWidget()
        self.table.setColumnCount(len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels([t for _, t in self.COLUMNS])
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.itemSelectionChanged.connect(self._row_selected)
        layout.addWidget(self.table, 1)

        # -- بيانات الصرف للصف المحدد ------------------------------------------------------
        gf = QGroupBox("بيانات الصرف للملف المحدد")
        fl = QHBoxLayout(gf)
        self.f_amount = QDoubleSpinBox()
        self.f_amount.setRange(0, 999999999)
        self.f_amount.setDecimals(2)
        self.f_ledger = QLineEdit()
        self.f_check = QLineEdit()
        from .widgets import DateField
        self.f_check_date = DateField()
        self.f_recipient = QLineEdit()
        for lbl, w in [("مبلغ الصرف:", self.f_amount), ("رقم القيد:", self.f_ledger),
                       ("رقم الشيك:", self.f_check), ("تاريخ استلام الشيك:", self.f_check_date),
                       ("اسم المستلم:", self.f_recipient)]:
            fl.addWidget(w, 1)
            fl.addWidget(QLabel(lbl), 0)
        self.btn_save_row = QPushButton("حفظ بيانات الصرف")
        self.btn_save_row.setProperty("primary", True)
        self.btn_save_row.clicked.connect(self._save_row)
        fl.addWidget(self.btn_save_row)
        layout.addWidget(gf)

        # -- إجراءات -------------------------------------------------------------------------
        acts = QHBoxLayout()
        self.btn_bulk = QPushButton("تعبئة جماعية")
        self.btn_bulk.clicked.connect(self._bulk_fill)
        self.btn_print = QPushButton("طباعة الكشف")
        self.btn_print.setProperty("ok", True)
        self.btn_print.clicked.connect(self._print_statement)
        self.btn_confirm = QPushButton("تأكيد التسليم لمكتب المدير التنفيذي")
        self.btn_confirm.setProperty("primary", True)
        self.btn_confirm.clicked.connect(self._confirm_delivery)
        self.btn_remove = QPushButton("حذف من القائمة")
        self.btn_remove.clicked.connect(self._remove_selected)
        acts.addWidget(self.btn_bulk)
        acts.addWidget(self.btn_print)
        acts.addWidget(self.btn_confirm)
        acts.addWidget(self.btn_remove)
        acts.addStretch(1)
        layout.addLayout(acts)
        self.hint_lbl = QLabel("القائمة تراكمية: أضف الملفات واحدًا واحدًا دون اختفاء السابق.")
        self.hint_lbl.setStyleSheet("color: #5A6B85;")
        layout.addWidget(self.hint_lbl)
        rtl_align(self)

    def _can(self):
        return has_permission(self.ctx.user, "disburse.manage", self.ctx.conn)

    # -- القائمة التراكمية ---------------------------------------------------------------
    def _add_by_search(self):
        q = self.search_box.text().strip()
        if not q:
            return
        rec = None
        if q.isdigit():
            rec = self.ctx.files.get_by_number(int(q))
        if not rec:
            rows, _t = self.ctx.files.search({"q": q}, page=1, per_page=5)
            if rows:
                rec = rows[0]
        if not rec:
            QMessageBox.information(self, "تنبيه", "لم يُعثر على ملف مطابق.")
            return
        if rec["id"] in self.items:
            QMessageBox.information(self, "تنبيه", "الملف موجود في القائمة مسبقًا.")
            return
        self.items.append(rec["id"])
        self.search_box.clear()
        self._reload_table()

    def _reload_table(self):
        self.table.setRowCount(len(self.items))
        for i, fid in enumerate(self.items):
            r = self.ctx.files.get(fid)
            for j, (key, _t) in enumerate(self.COLUMNS):
                val = r.get(key) if r else None
                text = format_money(val) if key in ("funding_amount", "disburse_amount") else (
                    str(val) if val not in (None, "") else "—")
                item = QTableWidgetItem(text)
                item.setData(Qt.UserRole, fid)
                if key in ("file_number",):
                    item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(i, j, item)
        self.table.resizeColumnsToContents()

    def _selected_fid(self):
        row = self.table.currentRow()
        if row < 0 or row >= len(self.items):
            return None
        return self.items[row]

    def _row_selected(self):
        fid = self._selected_fid()
        if not fid:
            return
        r = self.ctx.files.get(fid)
        self.f_amount.setValue(float(r.get("disburse_amount") or 0))
        self.f_ledger.setText(r.get("ledger_number") or "")
        self.f_check.setText(r.get("check_number") or "")
        self.f_check_date.set_iso(r.get("check_received_date"))
        self.f_recipient.setText(r.get("recipient_name") or "")

    def _remove_selected(self):
        fid = self._selected_fid()
        if fid:
            self.items.remove(fid)
            self._reload_table()

    # -- حفظ بيانات الصرف -------------------------------------------------------------------
    def _collect_row_data(self):
        return {
            "disburse_amount": self.f_amount.value() or None,
            "ledger_number": self.f_ledger.text().strip() or None,
            "check_number": self.f_check.text().strip() or None,
            "check_received_date": self.f_check_date.iso_value("تاريخ استلام الشيك"),
            "recipient_name": self.f_recipient.text().strip() or None,
        }

    def _save_row(self):
        if not self._can():
            QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية إدارة الصرف.")
            return
        fid = self._selected_fid()
        if not fid:
            QMessageBox.information(self, "تنبيه", "اختر ملفًا من القائمة.")
            return
        try:
            final = self.ctx.files.save_disbursement_data(
                fid, self._collect_row_data(),
                user_id=self.ctx.user["id"] if self.ctx.user else None)
            msg = "تم حفظ بيانات الصرف."
            if final == "disbursed":
                msg += " اكتملت بيانات الشيك والقيد — أصبحت حالة الملف «منصرفة»."
            QMessageBox.information(self, "تم", msg)
            self._reload_table()
        except Exception as exc:
            QMessageBox.critical(self, "خطأ", str(exc))

    def _bulk_fill(self):
        if not self._can():
            QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية إدارة الصرف.")
            return
        if not self.items:
            QMessageBox.information(self, "تنبيه", "القائمة فارغة.")
            return
        dlg = BulkDisburseDialog(self)
        if dlg.exec() != QDialog.Accepted:
            return
        data = dlg.data()
        uid = self.ctx.user["id"] if self.ctx.user else None
        n = 0
        for fid in self.items:
            try:
                self.ctx.files.save_disbursement_data(fid, data, user_id=uid)
                n += 1
            except Exception:
                pass
        QMessageBox.information(self, "تم", f"تمت التعبئة لـ {n} ملفًا.")
        self._reload_table()

    # -- البحث في المنصرفة --------------------------------------------------------------------
    def _search_ledger(self):
        q = self.lc_search.text().strip()
        if not q:
            return
        rows = self.ctx.files.search_disbursed(q)
        if not rows:
            QMessageBox.information(self, "لا نتائج", "لم يُعثر على ملفات بهذا الرقم.")
            return
        self.items = [r["id"] for r in rows]
        self._reload_table()
        self.hint_lbl.setText(f"نتائج البحث برقم القيد/الشيك «{q}»: {len(rows)} ملف.")

    # -- الطباعة والتأكيد ------------------------------------------------------------------------
    def _print_statement(self):
        if not self.items:
            QMessageBox.information(self, "تنبيه", "القائمة فارغة.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "حفظ كشف الصرف PDF",
                                              "كشف_صرف.pdf", "PDF (*.pdf)")
        if not path:
            return
        try:
            rows = [self.ctx.files.get(fid) for fid in self.items]
            build_disbursement_statement(rows, path, settings=self.ctx.settings())
            QMessageBox.information(self, "تم", f"تم حفظ الكشف:\n{path}")
        except Exception as exc:
            QMessageBox.critical(self, "خطأ", f"فشل إنشاء الكشف: {exc}")

    def _confirm_delivery(self):
        if not self._can():
            QMessageBox.warning(self, "صلاحيات", "لا تملك صلاحية إدارة الصرف.")
            return
        if not self.items:
            QMessageBox.information(self, "تنبيه", "القائمة فارغة.")
            return
        if QMessageBox.question(
                self, "تأكيد التسليم",
                f"سيتم التأشير على {len(self.items)} ملفًا بأنها «مسلمة لمكتب المدير التنفيذي "
                "لاستكمال صرفها» مع توثيق تاريخ اليوم، وتصبح حالتها «قيد الصرف».\nمتابعة؟"
        ) != QMessageBox.Yes:
            return
        uid = self.ctx.user["id"] if self.ctx.user else None
        # حفظ الكشف أولًا
        cur = self.ctx.conn.execute(
            "INSERT INTO disbursement_lists (title, created_by) VALUES (?,?)",
            (f"كشف صرف بتاريخ {date.today().isoformat()}", uid))
        list_id = cur.lastrowid
        for fid in self.items:
            self.ctx.conn.execute(
                "INSERT OR IGNORE INTO disbursement_list_items (list_id, file_id) VALUES (?,?)",
                (list_id, fid))
        self.ctx.conn.commit()
        res = self.ctx.files.confirm_delivery_to_director(self.items, user_id=uid)
        self.ctx.conn.execute("UPDATE disbursement_lists SET confirmed_at=datetime('now'),"
                              " confirmed_by=? WHERE id=?", (uid, list_id))
        self.ctx.conn.commit()
        msg = f"تم تأشير {len(res['done'])} ملفًا بتاريخ {res['date']}."
        if res["errors"]:
            msg += "\nتعذر:\n" + "\n".join(res["errors"])
        QMessageBox.information(self, "تم", msg)
        self._reload_table()

    def refresh(self):
        self._reload_table()


class BulkDisburseDialog(QDialog):
    """تعبئة جماعية لبيانات الصرف (رقم القيد/الشيك/التاريخ/المستلم)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("تعبئة جماعية لبيانات الصرف")
        form = QFormLayout(self)
        form.setLabelAlignment(Qt.AlignRight)
        self.ledger = QLineEdit()
        self.check = QLineEdit()
        from .widgets import DateField
        self.check_date = DateField()
        from datetime import date as _d
        self.check_date.set_iso(_d.today().isoformat())
        self.recipient = QLineEdit()
        self.amount = QDoubleSpinBox()
        self.amount.setRange(0, 999999999)
        self.amount.setDecimals(2)
        self.amount.setSpecialValueText("— بدون تغيير —")
        form.addRow("رقم القيد:", self.ledger)
        form.addRow("رقم الشيك:", self.check)
        form.addRow("تاريخ استلام الشيك:", self.check_date)
        form.addRow("اسم المستلم:", self.recipient)
        form.addRow("مبلغ الصرف:", self.amount)
        form.addRow(QLabel("الحقول الفارغة لن تُغيَّر."))
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.button(QDialogButtonBox.Ok).setText("تطبيق على الكل")
        btns.button(QDialogButtonBox.Cancel).setText("إلغاء")
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        form.addRow(btns)
        rtl_align(self)
        from .widgets import install_enter_navigation
        install_enter_navigation(self)

    def data(self):
        d = {}
        if self.ledger.text().strip():
            d["ledger_number"] = self.ledger.text().strip()
        if self.check.text().strip():
            d["check_number"] = self.check.text().strip()
        d["check_received_date"] = self.check_date.iso_value("تاريخ استلام الشيك")
        if self.recipient.text().strip():
            d["recipient_name"] = self.recipient.text().strip()
        if self.amount.value():
            d["disburse_amount"] = self.amount.value()
        return d
