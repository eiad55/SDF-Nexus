# -*- coding: utf-8 -*-
"""نافذة تسجيل الدخول."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QDialog, QDialogButtonBox, QFormLayout, QLabel,
                               QLineEdit, QMessageBox, QVBoxLayout)

from .. import config
from ..services.auth_service import authenticate, change_password


class ChangePasswordDialog(QDialog):
    """تغيير كلمة المرور — تُستخدم إجباريًا عند أول دخول."""

    def __init__(self, parent=None, forced: bool = False):
        super().__init__(parent)
        self.setWindowTitle("تغيير كلمة المرور")
        self.setModal(True)
        self.setMinimumWidth(340)
        layout = QVBoxLayout(self)
        if forced:
            info = QLabel("يجب تغيير كلمة المرور الافتراضية قبل المتابعة.")
            info.setWordWrap(True)
            info.setStyleSheet("color: #B3541E; font-weight: bold;")
            layout.addWidget(info)
        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignRight)
        self.new_password = QLineEdit()
        self.new_password.setEchoMode(QLineEdit.Password)
        self.new_password.setAlignment(Qt.AlignRight)
        self.confirm_password = QLineEdit()
        self.confirm_password.setEchoMode(QLineEdit.Password)
        self.confirm_password.setAlignment(Qt.AlignRight)
        form.addRow("كلمة المرور الجديدة:", self.new_password)
        form.addRow("تأكيد كلمة المرور:", self.confirm_password)
        layout.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("حفظ")
        buttons.button(QDialogButtonBox.Cancel).setText("إلغاء")
        buttons.accepted.connect(self._save)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _save(self):
        new = self.new_password.text()
        if len(new) < 6:
            QMessageBox.warning(self, "تنبيه", "كلمة المرور يجب ألا تقل عن 6 أحرف.")
            return
        if new != self.confirm_password.text():
            QMessageBox.warning(self, "تنبيه", "تأكيد كلمة المرور غير مطابق.")
            return
        self.accept()

    @property
    def password(self) -> str:
        return self.new_password.text()


class LoginDialog(QDialog):
    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.setWindowTitle("تسجيل الدخول")
        self.setModal(True)
        self.setMinimumWidth(360)
        layout = QVBoxLayout(self)

        title = QLabel(config.APP_NAME_AR)
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: #1F3A5F;")
        layout.addWidget(title)
        sub = QLabel(config.ORG_NAME_AR)
        sub.setAlignment(Qt.AlignCenter)
        sub.setStyleSheet("color: #5A6B85;")
        layout.addWidget(sub)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignRight)
        self.username = QLineEdit()
        self.username.setPlaceholderText("اسم المستخدم")
        self.username.setAlignment(Qt.AlignRight)
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)
        self.password.setPlaceholderText("كلمة المرور")
        self.password.setAlignment(Qt.AlignRight)
        form.addRow("اسم المستخدم:", self.username)
        form.addRow("كلمة المرور:", self.password)
        layout.addLayout(form)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("دخول")
        buttons.button(QDialogButtonBox.Ok).setProperty("primary", True)
        buttons.button(QDialogButtonBox.Cancel).setText("إلغاء")
        buttons.accepted.connect(self.try_login)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.password.returnPressed.connect(self.try_login)

    def try_login(self):
        user = authenticate(self.ctx.conn, self.username.text(), self.password.text())
        if not user:
            QMessageBox.warning(self, "تعذر الدخول",
                                "اسم المستخدم أو كلمة المرور غير صحيحة.")
            return
        if user.get("must_change_password"):
            dlg = ChangePasswordDialog(self, forced=True)
            if dlg.exec() != QDialog.Accepted:
                return  # إلغاء التغيير الإجباري = عدم الدخول
            change_password(self.ctx.conn, user["id"], dlg.password)
            user["must_change_password"] = 0
        self.ctx.user = user
        self.accept()
