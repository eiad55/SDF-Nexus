# -*- coding: utf-8 -*-
"""النافذة الرئيسية: قائمة جانبية + صفحات."""
from PySide6.QtCore import QSettings, Qt
from PySide6.QtGui import QKeySequence, QShortcut
from PySide6.QtWidgets import (QButtonGroup, QHBoxLayout, QLabel, QMainWindow,
                               QPushButton, QStackedWidget, QStatusBar,
                               QVBoxLayout, QWidget)

from .. import config
from ..services.auth_service import ROLES, has_permission
from .widgets import Toast

NAV_HINTS = {
    "dashboard": "نظرة عامة: مؤشرات ورسوم وتنبيهات التأخير",
    "files": "بحث وإدارة ملفات البرامج التدريبية",
    "review": "مراجعة مستندات الملفات واعتمادها",
    "disburse": "إدخال بيانات الصرف ومتابعتها",
    "entities": "إدارة الجهات المستفيدة والمنفذة",
    "contributions": "نسب ومساهمات الجهات الشهرية",
    "import": "استيراد ملفات من Excel",
    "reports": "التقارير والطباعة والتصدير",
    "settings": "إعدادات النظام والقوائم المرجعية",
    "users": "حسابات المستخدمين وصلاحياتهم",
    "backup": "النسخ الاحتياطي والاستعادة وإعادة التهيئة",
}


class MainWindow(QMainWindow):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.setWindowTitle(f"{config.APP_NAME_AR} — {config.ORG_NAME_AR}")
        self.resize(1280, 800)
        self.setMinimumSize(1060, 620)

        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QHBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # -- القائمة الجانبية ------------------------------------------------
        sidebar = QWidget()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(264)
        side_layout = QVBoxLayout(sidebar)
        side_layout.setContentsMargins(0, 0, 0, 0)
        side_layout.setSpacing(2)

        # ترويسة من سطرين منفصلين (اسم النظام / الجهة) داخل شريط أغمق —
        # بعرض أوسع وخط أصغر حتى لا يتجاوز أي سطر عرض الشريط على أي خط نظام
        header = QWidget()
        header.setObjectName("sidebarHeader")
        hl = QVBoxLayout(header)
        hl.setContentsMargins(16, 16, 16, 13)
        hl.setSpacing(3)
        name_lbl = QLabel(config.APP_NAME_AR)
        name_lbl.setObjectName("sidebarTitle")
        name_lbl.setWordWrap(True)
        name_lbl.setAlignment(Qt.AlignRight | Qt.AlignTop)
        org_lbl = QLabel(config.ORG_NAME_AR)
        org_lbl.setObjectName("sidebarOrg")
        org_lbl.setWordWrap(True)
        org_lbl.setAlignment(Qt.AlignRight | Qt.AlignTop)
        hl.addWidget(name_lbl)
        hl.addWidget(org_lbl)
        side_layout.addWidget(header)

        self.stack = QStackedWidget()
        self.pages = {}
        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)

        # (المفتاح، العنوان، الصلاحية)
        self.nav_items = [
            ("dashboard", "لوحة التحكم", "file.view"),
            ("files", "إدارة الملفات", "file.view"),
            ("review", "المراجعة الفنية", "review.technical"),
            ("disburse", "الصرف", "disburse.manage"),
            ("entities", "الجهات المستفيدة", "settings.manage"),
            ("contributions", "المساهمات الشهرية", "contrib.manage"),
            ("import", "استيراد من Excel", "import"),
            ("reports", "التقارير والطباعة", "report.view"),
            ("settings", "الإعدادات", "settings.manage"),
            ("users", "المستخدمون", "user.manage"),
            ("backup", "النسخ الاحتياطي", "backup"),
        ]
        for key, label, perm in self.nav_items:
            if not has_permission(ctx.user, perm, ctx.conn):
                continue
            btn = QPushButton(label)
            btn.setToolTip(NAV_HINTS.get(key, label))
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _=False, k=key: self.show_page(k))
            self.nav_group.addButton(btn)
            side_layout.addWidget(btn)
            btn.setProperty("page_key", key)

        side_layout.addStretch(1)
        user_lbl = QLabel(f"المستخدم: {ctx.user['full_name']}\nالدور: {ROLES.get(ctx.user['role'], '')}")
        user_lbl.setStyleSheet("color: #9FB2CC; padding: 12px; font-size: 12px;")
        side_layout.addWidget(user_lbl)

        main_layout.addWidget(sidebar)

        # -- منطقة المحتوى ----------------------------------------------------
        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(20, 16, 20, 16)
        self.page_title = QLabel("")
        self.page_title.setObjectName("pageTitle")
        content_layout.addWidget(self.page_title)
        content_layout.addWidget(self.stack, 1)
        main_layout.addWidget(content, 1)

        self.setStatusBar(QStatusBar())
        self.statusBar().showMessage(f"متصل بقاعدة البيانات — {ctx.user['full_name']}")
        # شريط حالة حي: قاعدة البيانات + آخر نسخة احتياطية + زر نسخ سريع
        self._current_key = "dashboard"
        self._toast = None
        self._db_lbl = QLabel("")
        self._backup_lbl = QLabel("")
        self.statusBar().addPermanentWidget(self._db_lbl)
        self.statusBar().addPermanentWidget(self._backup_lbl)
        self._backup_btn = QPushButton("نسخة احتياطية الآن")
        self._backup_btn.setToolTip("إنشاء نسخة احتياطية كاملة فورًا")
        self._backup_btn.clicked.connect(self._quick_backup)
        self._backup_btn.setVisible(has_permission(ctx.user, "backup", ctx.conn))
        self.statusBar().addPermanentWidget(self._backup_btn)
        self._refresh_status()
        # بحث عام فوري من أي شاشة
        QShortcut(QKeySequence("Ctrl+K"), self).activated.connect(self._open_quick_search)

    def register_page(self, key: str, title: str, widget: QWidget):
        self.pages[key] = widget
        self.stack.addWidget(widget)
        widget.setProperty("page_title", title)

    # -- إشعارات وحالة ------------------------------------------------------
    def notify(self, text: str):
        """إشعار نجاح هادئ أسفل النافذة (لا يقاطع العمل)."""
        if self._toast is None:
            self._toast = Toast(self)
        self._toast.show_message(text)

    def _refresh_status(self):
        try:
            self._db_lbl.setText(f"قاعدة البيانات: {self.ctx.db.path.name}")
        except Exception:
            self._db_lbl.setText("")
        try:
            from datetime import datetime
            zips = sorted(config.backups_dir().glob("sdf_backup_*.zip"),
                          key=lambda p: p.stat().st_mtime, reverse=True)
            if zips:
                when = datetime.fromtimestamp(zips[0].stat().st_mtime)
                self._backup_lbl.setText(f"آخر نسخة احتياطية: {when:%Y-%m-%d %H:%M}")
            else:
                self._backup_lbl.setText("لا توجد نسخة احتياطية بعد")
        except Exception:
            self._backup_lbl.setText("")

    def _quick_backup(self):
        from ..services import backup_service
        try:
            path = backup_service.create_backup(self.ctx.conn)
        except Exception as exc:
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.critical(self, "النسخ الاحتياطي", f"فشل إنشاء النسخة: {exc}")
            return
        self._refresh_status()
        self.notify(f"أُنشئت نسخة احتياطية: {path.name}")

    def _open_quick_search(self):
        from .quick_search import QuickSearchDialog
        QuickSearchDialog(self.ctx, self._quick_open, parent=self).exec()

    def _quick_open(self, kind: str, ident: int):
        if kind == "file":
            self.show_page("files")
            page = self.pages.get("files")
            if page is not None and hasattr(page, "reveal_file"):
                page.reveal_file(ident)
        elif kind == "entity":
            self.show_page("entities")

    # -- تذكّر الجلسة (حجم/موضع النافذة + آخر صفحة) --------------------------
    def _settings(self):
        return QSettings("SkillsDevelopmentFund", "SDFBranchSystem")

    def restore_session(self):
        st = self._settings()
        user = (self.ctx.user or {}).get("username", "anon")
        geo = st.value(f"ui/{user}/geometry")
        if geo is not None:
            try:
                self.restoreGeometry(geo)
            except Exception:
                pass
        last = st.value(f"ui/{user}/last_page", "")
        if last and last in self.pages:
            self.show_page(last)

    def closeEvent(self, event):
        try:
            st = self._settings()
            user = (self.ctx.user or {}).get("username", "anon")
            st.setValue(f"ui/{user}/geometry", self.saveGeometry())
            st.setValue(f"ui/{user}/last_page", self._current_key)
        except Exception:
            pass
        super().closeEvent(event)

    def show_page(self, key: str):
        if key not in self.pages:
            return
        self._current_key = key
        # تفعيل زر القائمة
        for btn in self.nav_group.buttons():
            if btn.property("page_key") == key:
                btn.setChecked(True)
        page = self.pages[key]
        self.stack.setCurrentWidget(page)
        self.page_title.setText(page.property("page_title") or "")
        if hasattr(page, "refresh"):
            page.refresh()
