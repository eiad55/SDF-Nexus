#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""إعادة بناء أرشيف مصدر نظيف من جذر مستودع يحتوي مجلد sdf_pkg."""
import argparse
import shutil
import tempfile
import zipfile
from pathlib import Path

# Directories that are never part of the distributable source archive.
EXCLUDE_DIRS = {
    ".venv", "venv", "__pycache__", ".git", ".pytest_cache",
    ".mypy_cache", ".ruff_cache", "dist", "ci-logs",
}
EXCLUDE_FILES = {".DS_Store", "Thumbs.db"}
EXCLUDE_SUFFIXES = {".pyc", ".pyo"}
PYINSTALLER_BUILD_DIR = "SDFBranchSystem"
PYINSTALLER_BUILD_FILES = ("warn-", "xref-")


def _ignore_generated(src_root: Path):
    """Return a shutil.copytree ignore callback aware of project-relative paths."""
    root = src_root.resolve()

    def ignore(directory: str, names: list[str]) -> set[str]:
        current = Path(directory).resolve()
        try:
            relative_dir = current.relative_to(root)
        except ValueError:
            # Defensive fallback: do not ignore anything outside the known source root.
            return set()

        ignored: set[str] = set()
        for name in names:
            candidate = current / name
            rel_candidate = relative_dir / name
            # Never follow symlinks into paths outside the source tree or include
            # machine-specific linked content in a distributable archive.
            if candidate.is_symlink():
                ignored.add(name)
                continue
            if name in EXCLUDE_DIRS and candidate.is_dir():
                ignored.add(name)
                continue
            if name in EXCLUDE_FILES or candidate.suffix.lower() in EXCLUDE_SUFFIXES:
                ignored.add(name)
                continue
            # PyInstaller uses build/SDFBranchSystem as its work directory by default.
            # Keep build/*.spec, setup.iss, and icons; exclude only generated work output.
            if (
                candidate.is_dir()
                and len(rel_candidate.parts) >= 3
                and rel_candidate.parts[-3:-1] == ("sdf_pkg", "build")
                and name == PYINSTALLER_BUILD_DIR
            ):
                ignored.add(name)
                continue
            # PyInstaller may also leave these diagnostic files directly in build/.
            if len(rel_candidate.parts) >= 2 and rel_candidate.parts[-2] == "build":
                if name.endswith(".toc") or name.startswith(PYINSTALLER_BUILD_FILES):
                    ignored.add(name)
        return ignored

    return ignore


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build a clean SDFBranchSystem-source.zip from a repository root."
    )
    parser.add_argument(
        "source_dir", type=Path,
        help="repository root containing the sdf_pkg directory",
    )
    parser.add_argument("output_zip", type=Path, help="path for the generated ZIP")
    args = parser.parse_args()
    src = args.source_dir.resolve()
    out = args.output_zip.resolve()

    if not src.is_dir():
        parser.error(f"Source directory does not exist: {src}")
    project = src / "sdf_pkg"
    if not project.is_dir():
        parser.error(f"Required project directory does not exist: {project}")
    if out == src or src in out.parents:
        parser.error("Place the output ZIP outside the source directory.")

    required_source = project / "src/sdf_app/main.py"
    if not required_source.is_file():
        parser.error(f"Required source file is missing: {required_source}")

    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="sdf_pkg_stage_") as tmp:
        stage_root = Path(tmp) / "stage"
        stage_root.mkdir()
        shutil.copytree(project, stage_root / "sdf_pkg", ignore=_ignore_generated(src))

        temp_zip = out.with_suffix(out.suffix + ".tmp")
        try:
            with zipfile.ZipFile(
                temp_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=6
            ) as archive:
                for file in sorted(stage_root.rglob("*")):
                    if file.is_file():
                        archive.write(file, file.relative_to(stage_root).as_posix())

            with zipfile.ZipFile(temp_zip) as archive:
                bad = archive.testzip()
                if bad:
                    raise RuntimeError(f"ZIP integrity check failed at: {bad}")
                names = set(archive.namelist())
                required_entries = {
                    "sdf_pkg/src/sdf_app/main.py",
                    "sdf_pkg/build/SDFBranchSystem.spec",
                    "sdf_pkg/build/setup.iss",
                }
                missing = required_entries - names
                if missing:
                    raise RuntimeError(
                        "Required source entries are missing: " + ", ".join(sorted(missing))
                    )
                forbidden = [
                    name for name in names
                    if name.startswith(("sdf_pkg/dist/", "sdf_pkg/ci-logs/", "sdf_pkg/build/SDFBranchSystem/"))
                ]
                if forbidden:
                    raise RuntimeError(
                        "Generated build output found in source ZIP: "
                        + ", ".join(sorted(forbidden)[:10])
                    )
            temp_zip.replace(out)
        finally:
            if temp_zip.exists():
                temp_zip.unlink()

    with zipfile.ZipFile(out) as archive:
        print(f"built: {out} ({out.stat().st_size // 1024} KB; {len(archive.namelist())} files)")


if __name__ == "__main__":
    main()
