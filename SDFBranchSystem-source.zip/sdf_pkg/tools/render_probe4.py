# -*- coding: utf-8 -*-
"""مسبار علاج التلميح: رسم يدوي للتلميح داخل paintEvent مقابل النص المكتوب."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QPainter
from PySide6.QtWidgets import (QLabel, QLineEdit, QStyle, QStyleOptionFrame,
                               QVBoxLayout, QWidget)

from sdf_app.ui.app import create_app

PH = "القيمة (فارغ = بدون شرط)"


class PaintedHintEdit(QLineEdit):
    """QLineEdit يرسم تلميحه بنفسه محاذيًا لليمين عند الفراغ."""

    def paintEvent(self, event):
        if self.text() or not self.placeholderText():
            return super().paintEvent(event)
        # إطار الحقل عبر النمط نفسه ثم النص بمسار QPainter المباشر
        p = QPainter(self)
        opt = QStyleOptionFrame()
        self.initStyleOption(opt)
        self.style().drawPrimitive(QStyle.PE_PanelLineEdit, opt, p, self)
        rect = self.style().subElementRect(QStyle.SE_LineEditContents, opt, self)
        rect.adjust(4, 0, -4, 0)
        p.setPen(QColor("#8A94A6"))
        p.setFont(self.font())
        p.drawText(rect, Qt.AlignRight | Qt.AlignAbsolute | Qt.AlignVCenter, self.placeholderText())
        p.end()


def main() -> int:
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "render-probe4")
    out.mkdir(parents=True, exist_ok=True)
    app = create_app([])

    panel = QWidget()
    lay = QVBoxLayout(panel)

    lay.addWidget(QLabel("V8 تلميح يُضبط بعد العرض"))
    v8 = QLineEdit(); v8.setAlignment(Qt.AlignRight)
    lay.addWidget(v8)

    lay.addWidget(QLabel("V12 نص مكتوب فعليًا (ضابط)"))
    v12 = QLineEdit(); v12.setText(PH); v12.setAlignment(Qt.AlignRight)
    lay.addWidget(v12)

    lay.addWidget(QLabel("V13 تلميح مرسوم يدويًا + AlignAbsolute"))
    v13 = PaintedHintEdit(); v13.setPlaceholderText(PH)
    v13.setAlignment(Qt.AlignRight)
    lay.addWidget(v13)

    lay.addWidget(QLabel("V13ب تلميح مرسوم يدويًا — تاريخ"))
    v13b = PaintedHintEdit(); v13b.setPlaceholderText("اختر أو اكتب التاريخ")
    v13b.setAlignment(Qt.AlignRight)
    lay.addWidget(v13b)

    panel.resize(1000, 380)
    panel.show()
    app.processEvents()
    v8.setPlaceholderText(PH)  # بعد العرض
    app.processEvents()
    panel.grab().save(str(out / "cure.png"))
    print("probe4 done")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
