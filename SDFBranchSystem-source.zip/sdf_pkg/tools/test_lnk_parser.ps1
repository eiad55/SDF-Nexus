# test_lnk_parser.ps1 — fixture tests for tools/lnk_shortcut.ps1.
#
# Runs the structural Shell Link parser (Get-LnkParsed / Resolve-LnkTarget)
# against the synthetic fixtures in tests/fixtures/lnk and checks every
# extracted target against manifest.json. The trap fixture
# (trap_other_target.lnk) carries the expected exe path as a string inside
# its icon location / working directory while its real target is
# notepad.exe: the parser MUST report notepad.exe, proving acceptance can
# never come from finding a string in the raw bytes (the v9 defect).
#
# Platform note: parser assertions (LinkInfo extraction) are platform
# independent. Full resolver assertions (Target/Method) require Windows
# COM + rooted Windows paths, so on non-Windows hosts only the parser
# level and the linkinfo attempt value are asserted.
#
# Usage: pwsh -NoProfile -File test_lnk_parser.ps1 -FixturesDir <dir>
# Exit: 0 when all fixtures behave as the manifest requires; throws otherwise.

param([Parameter(Mandatory = $true)][string]$FixturesDir)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'lnk_shortcut.ps1')

$manifestPath = Join-Path $FixturesDir 'manifest.json'
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
$expectedExe = [string]$manifest.expected_exe
$failures = 0

foreach ($fx in $manifest.fixtures) {
    $path = Join-Path $FixturesDir $fx.file
    $parsed = Get-LnkParsed $path
    $actual = $null
    if ($parsed) { $actual = $parsed.LinkInfoTarget }
    $expected = $fx.target
    $targetOk = ($actual -eq $expected) -or
        ([string]::IsNullOrEmpty([string]$actual) -and [string]::IsNullOrEmpty([string]$expected))

    $resolution = Resolve-LnkTarget $path
    $matchOk = $true
    $detail = ''
    if ($IsWindows) {
        $isMatch = Test-LnkTargetEquals $resolution.Target $expectedExe
        $matchOk = ($isMatch -eq [bool]$fx.matches_run_exe)
        $detail = "method=$($resolution.Method) target=$($resolution.Target)"
    } else {
        # No COM here, and [IO.Path]::IsPathRooted treats Windows drive
        # paths as relative on non-Windows hosts, so the resolver marks
        # them <relative: ...> and returns no Target. Verify at parser
        # level instead: the extracted LinkInfo target string compared
        # directly (rootedness is a Windows-runner assertion).
        $li = [string]$resolution.Attempts.linkinfo
        $isMatch = $actual -and ($actual -ieq $expectedExe)
        $matchOk = ($isMatch -eq [bool]$fx.matches_run_exe)
        $detail = "linkinfo-attempt=[$li]"
    }

    if ($targetOk -and $matchOk) {
        Write-Output "PASS $($fx.file) extracted=[$actual] $detail"
    } else {
        $failures++
        Write-Output "FAIL $($fx.file) extracted=[$actual] expected=[$expected] $detail"
    }
}

if ($failures -gt 0) {
    throw "lnk parser fixtures failed: $failures of $($manifest.fixtures.Count)"
}
Write-Output "lnk parser fixtures: ALL $($manifest.fixtures.Count) PASS"
