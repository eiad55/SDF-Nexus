# -*- coding: utf-8 -*-
"""اختبار قبول: استيراد الملف الأصلي الحقيقي (ورقة2) إلى قاعدة اختبار."""
import argparse
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from sdf_app.database.connection import Database
from sdf_app.database.seeds import seed_all
from sdf_app.services import import_service as imp

def main():
    parser = argparse.ArgumentParser(description="اختبار استيراد ملف Excel إلى قاعدة اختبار منفصلة.")
    parser.add_argument("source", type=Path, help="مسار ملف Excel المصدر")
    parser.add_argument("--db-path", type=Path, help="مسار قاعدة اختبار جديدة (يجب ألا يكون موجودًا)")
    parser.add_argument("--sheet", default="ورقة2", help="اسم الورقة المراد اختبارها (افتراضي: ورقة2)")
    args = parser.parse_args()
    src = args.source.resolve()
    if not src.is_file():
        parser.error(f"ملف المصدر غير موجود: {src}")
    db_path = args.db_path.resolve() if args.db_path else Path(tempfile.gettempdir()) / "sdf_import_test.db"
    if db_path.exists():
        parser.error(f"قاعدة الاختبار موجودة ولن تُحذف تلقائيًا: {db_path}; اختر --db-path جديدًا أو احذفها يدويًا بعد التحقق.")
    db_path.parent.mkdir(parents=True, exist_ok=True)
    database = Database(db_path)
    conn = database.connect()
    seed_all(conn)

    print("الأوراق:", imp.list_sheets(src))
    prev = imp.preview_sheet(src, args.sheet, n_rows=3)
    print("عدد الأعمدة:", len(prev["headers"]), "| عدد الصفوف:", prev["total_rows"])
    mapping = imp.auto_map_columns(prev["headers"])
    print("أعمدة مطابقة تلقائيًا:", len(mapping), "من", len([h for h in prev['headers'] if h]))

    results = imp.analyze_rows(src, args.sheet, mapping, conn)
    summary = imp.summarize_analysis(results)
    print("ملخص التحليل:", summary)

    # عينة من الصفوف ذات الأخطاء
    shown = 0
    for r in results:
        if r.status == "error" and shown < 5:
            print(f"  صف {r.excel_row}: {r.errors[0][:100]}")
            shown += 1

    report = imp.execute_import(conn, results, duplicate_policy="skip",
                                source_file=str(src), sheet_name=args.sheet)
    print("تقرير الاستيراد:", {k: v for k, v in report.items() if k != "report"})

    n = conn.execute("SELECT COUNT(*) c FROM training_files").fetchone()["c"]
    print("السجلات في قاعدة البيانات:", n)

    # تحقق: إعادة حساب معادلة لعينة ومقارنتها بالمخزنة في Excel
    from sdf_app.core.finance import summarize
    row = conn.execute("SELECT * FROM training_files ORDER BY id LIMIT 1").fetchone()
    if row is not None:
        rec = dict(row)
        s = summarize(rec)
        print(f"أول ملف مستورد: إجمالي العقد المحسوب={s['contract_total']} | التمويل={rec['funding_amount']}")
    else:
        print("لم تُستورد سجلات؛ لا يمكن إجراء تحقق مالي على سجل.")

    n_branches = conn.execute("SELECT COUNT(*) c FROM branches").fetchone()["c"]
    n_entities = conn.execute("SELECT COUNT(*) c FROM entities").fetchone()["c"]
    n_trainers = conn.execute("SELECT COUNT(*) c FROM trainers").fetchone()["c"]
    print(f"فروع: {n_branches} | جهات: {n_entities} | مدربون: {n_trainers}")
    database.close()

if __name__ == "__main__":
    main()
