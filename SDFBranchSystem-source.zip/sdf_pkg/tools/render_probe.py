# -*- coding: utf-8 -*-
"""مسبار تصيير تشخيصي (CI على Windows فقط): يصوّر ودجات بعينها بمنصة
Windows الحقيقية لفحص قصّ الحروف الأولى في عناوين المجموعات وحقول الإدخال.
الاستخدام: python tools/render_probe.py <مجلد الإخراج>
يحترم QT_QPA_PLATFORM وQT_SCALE_FACTOR من البيئة.
"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from PySide6.QtWidgets import (QGroupBox, QLabel, QLineEdit, QVBoxLayout,
                               QWidget)

from sdf_app.ui.app import create_app


def main() -> int:
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "render-probe")
    out.mkdir(parents=True, exist_ok=True)
    scale = Path("scale.txt")
    app = create_app([])
    import os
    tag = os.environ.get("QT_SCALE_FACTOR", "1.0").replace(".", "_")

    from sdf_app.ui.context import AppContext
    ctx = AppContext(db_path=Path(tempfile.mktemp(suffix=".db")))
    ctx.user = {"id": 1, "username": "admin", "full_name": "مدير النظام",
                "role": "admin"}

    # صفحات حقيقية كاملة
    from sdf_app.ui.disbursement_page import DisbursementPage
    from sdf_app.ui.review_page import ReviewPage
    for name, page in (("review", ReviewPage(ctx)),
                       ("disburse", DisbursementPage(ctx))):
        page.resize(1200, 800)
        page.show()
        app.processEvents()
        page.grab().save(str(out / f"{name}_{tag}.png"))
        page.close()

    # لوحة ودجات مركّزة للمقارنة المباشرة
    panel = QWidget()
    lay = QVBoxLayout(panel)
    gb = QGroupBox("قائمة التحقق من الوثائق")
    gb_lay = QVBoxLayout(gb)
    gb_lay.addWidget(QLabel("محتوى داخل المجموعة"))
    lay.addWidget(gb)
    lay.addWidget(QLabel("قائمة التحقق من الوثائق"))
    e1 = QLineEdit()
    e1.setPlaceholderText("القيمة (فارغ = بدون شرط)")
    lay.addWidget(e1)
    from sdf_app.ui.widgets import DateField
    lay.addWidget(DateField())
    e2 = QLineEdit()
    e2.setPlaceholderText("رقم الملف")
    lay.addWidget(e2)
    e3 = QLineEdit()
    e3.setText("نص عربي مكتوب فعليًا في الحقل")
    lay.addWidget(e3)
    panel.resize(700, 420)
    panel.show()
    app.processEvents()
    panel.grab().save(str(out / f"widgets_{tag}.png"))
    print(f"probe done tag={tag} -> {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
