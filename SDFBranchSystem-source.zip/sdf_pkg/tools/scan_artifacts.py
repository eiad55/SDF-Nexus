#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Fail closed when build artifacts/logs contain common secret markers.

This is a lightweight defense-in-depth scanner, not a replacement for a dedicated
repository secret scanner. It intentionally reports locations/pattern names only,
never the matched value.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

BLOCKED_SUFFIXES = {
    ".db", ".sqlite", ".sqlite3", ".xlsx", ".xlsm", ".xls", ".pdf",
    ".env", ".pem", ".p12", ".pfx", ".key",
}
BLOCKED_NAMES = {".env", "id_rsa", "id_ed25519", "credentials.json", "secrets.json"}
TEXT_LIMIT = 5 * 1024 * 1024

PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("private-key-marker", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----")),
    ("github-token", re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9_]{30,}|github_pat_[A-Za-z0-9_]{22,})\b")),
    ("aws-access-key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("credential-assignment", re.compile(
        r"(?i)\b(?:password|passwd|api[_-]?key|access[_-]?token|client[_-]?secret)\s*[:=]\s*['\"]?([^\s'\";,]{8,})"
    )),
)

PLACEHOLDERS = {
    "changeme", "change_me", "your_token_here", "your_api_key_here",
    "example123", "placeholder", "redacted", "********", "<redacted>",
}


def _is_text(data: bytes) -> bool:
    if b"\x00" in data:
        return False
    try:
        data.decode("utf-8-sig")
        return True
    except UnicodeDecodeError:
        return False


def scan_roots(roots: list[Path]) -> list[str]:
    findings: list[str] = []
    seen: set[Path] = set()
    for root in roots:
        if not root.exists():
            continue
        candidates = [root] if root.is_file() else sorted(root.rglob("*"))
        for path in candidates:
            try:
                resolved = path.resolve(strict=True)
            except (OSError, RuntimeError):
                findings.append(f"unresolvable-path: {path}")
                continue
            if resolved in seen:
                continue
            seen.add(resolved)
            if path.is_symlink():
                findings.append(f"symlink-in-artifact: {path}")
                continue
            if not path.is_file():
                continue
            if path.suffix.lower() in BLOCKED_SUFFIXES or path.name.lower() in BLOCKED_NAMES:
                findings.append(f"blocked-file-type: {path}")
                continue
            try:
                if path.stat().st_size > TEXT_LIMIT:
                    continue
                raw = path.read_bytes()
            except OSError:
                findings.append(f"unreadable-file: {path}")
                continue
            if not _is_text(raw):
                continue
            content = raw.decode("utf-8-sig", errors="replace")
            for label, pattern in PATTERNS:
                match = pattern.search(content)
                if not match:
                    continue
                if label == "credential-assignment":
                    value = match.group(1).strip().lower().rstrip(".")
                    if value in PLACEHOLDERS or value.startswith(("<", "${", "%")):
                        continue
                findings.append(f"{label}: {path}")
    return findings


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("roots", nargs="+", type=Path, help="Artifact/log roots to scan")
    args = parser.parse_args(argv)
    missing = [str(root) for root in args.roots if not root.exists()]
    if missing:
        print("ERROR: scan root does not exist: " + ", ".join(missing), file=sys.stderr)
        return 2
    findings = scan_roots(args.roots)
    if findings:
        print("Artifact content scan FAILED; matching values are intentionally omitted:")
        for finding in findings:
            print(f" - {finding}")
        return 1
    print(f"Artifact content scan passed ({len(args.roots)} root(s)).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
