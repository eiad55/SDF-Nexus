# -*- coding: utf-8 -*-
"""مسبار متغيرات: يعزل سبب رسم تلميح QLineEdit يسارًا رغم AlignRight."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QComboBox, QHBoxLayout, QLabel, QLineEdit,
                               QVBoxLayout, QWidget)

from sdf_app.ui.app import create_app
from sdf_app.ui.widgets import DateField, rtl_align

PH = "القيمة (فارغ = بدون شرط)"


def main() -> int:
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "render-probe3")
    out.mkdir(parents=True, exist_ok=True)
    app = create_app([])

    panel = QWidget()
    lay = QVBoxLayout(panel)

    v1 = QLineEdit(); v1.setPlaceholderText(PH); v1.setAlignment(Qt.AlignRight)
    lay.addWidget(QLabel("V1 محاذاة عند الإنشاء")); lay.addWidget(v1)

    v2 = QLineEdit(); v2.setPlaceholderText(PH)
    lay.addWidget(QLabel("V2 محاذاة لاحقة (نمط refresh)")); lay.addWidget(v2)

    row = QHBoxLayout()
    val = QLineEdit(); val.setPlaceholderText(PH)
    op = QComboBox(); op.addItems([">", "<", "="])
    row.addWidget(QLabel("عدد المتدربين حسب العقد:"))
    row.addWidget(op); row.addWidget(val, 1)
    lay.addWidget(QLabel("V3 نسخة صف المعايير الحرفية")); lay.addLayout(row)

    lay.addWidget(QLabel("V4 DateField عريض"))
    lay.addWidget(DateField())

    v5 = QLineEdit(); v5.setPlaceholderText(PH); v5.setAlignment(Qt.AlignRight)
    v5.setText("x"); v5.setText("")
    lay.addWidget(QLabel("V5 محاذاة + دورة نص")); lay.addWidget(v5)

    v6 = QLineEdit(); v6.setPlaceholderText(PH); v6.setAlignment(Qt.AlignRight)
    v6.setLayoutDirection(Qt.LeftToRight)
    lay.addWidget(QLabel("V6 اتجاه LTR على الحقل نفسه")); lay.addWidget(v6)

    v7 = QLineEdit(); v7.setPlaceholderText(PH)
    v7.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    lay.addWidget(QLabel("V7 AlignRight|AlignVCenter")); lay.addWidget(v7)

    panel.resize(1000, 560)
    panel.show()
    app.processEvents()
    v2.setAlignment(Qt.AlignRight)   # المحاذاة اللاحقة بعد العرض (مثل refresh عند التنقل)
    rtl_align(panel)                  # مرور المشي مثل الصفحات
    app.processEvents()
    panel.grab().save(str(out / "variants.png"))
    print("probe3 done")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
