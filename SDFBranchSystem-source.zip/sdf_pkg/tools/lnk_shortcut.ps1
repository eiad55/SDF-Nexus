# lnk_shortcut.ps1 — Shell Link (.lnk) target resolution for install-smoke.
#
# Why this file exists (proven root cause, run 39086711009): Inno Setup
# created the Start Menu shortcut successfully and the smoke test found the
# .lnk file, but WScript.Shell's CreateShortcut().TargetPath returned an
# empty string for that link, so a WSH-only equality check could never pass.
#
# Design rules (acceptance is NOT weakened):
#   * A shortcut is accepted only when an actually-resolved target path
#     equals the expected executable path. Resolved targets come from, in
#     order: WScript.Shell TargetPath, Shell.Application GetLink().Path,
#     and a structural [MS-SHLLINK] parse of the LinkInfo target field
#     (LocalBasePath / LocalBasePathUnicode + CommonPathSuffix).
#   * Searching the raw .lnk bytes for the expected path string is NOT an
#     acceptance method: the string can appear in the name, working
#     directory, arguments, or icon location of a link whose real target
#     is a different file (proven false positive against v9). StringData
#     is extracted for diagnostics only.
#   * Only rooted (absolute) resolved targets are acceptable. A relative
#     value is recorded in the attempts log and treated as unresolved:
#     the installer writes absolute targets, so a relative-only link
#     cannot prove the expected absolute target.
#   * Every method's outcome is recorded (value / <empty> / <error: ...> /
#     <unavailable> / <relative: ...>) so a failure log explains itself.

$script:LnkWshShell = $null
$script:LnkShellApp = $null
$script:LnkComTried = $false

function Initialize-LnkCom {
    if ($script:LnkComTried) { return }
    $script:LnkComTried = $true
    try { $script:LnkWshShell = New-Object -ComObject WScript.Shell } catch {}
    try { $script:LnkShellApp = New-Object -ComObject Shell.Application } catch {}
}

function Read-LnkAnsiString {
    param([byte[]]$Bytes, [int]$Offset)
    if ($Offset -lt 0 -or $Offset -ge $Bytes.Length) { return $null }
    $end = $Offset
    while ($end -lt $Bytes.Length -and $Bytes[$end] -ne 0) { $end++ }
    if ($end -eq $Offset) { return "" }
    return [System.Text.Encoding]::GetEncoding(1252).GetString($Bytes, $Offset, $end - $Offset)
}

function Read-LnkUtf16String {
    param([byte[]]$Bytes, [int]$Offset)
    if ($Offset -lt 0 -or $Offset + 2 -gt $Bytes.Length) { return $null }
    $end = $Offset
    while ($end + 2 -le $Bytes.Length -and -not ($Bytes[$end] -eq 0 -and $Bytes[$end + 1] -eq 0)) { $end += 2 }
    if ($end -eq $Offset) { return "" }
    return [System.Text.Encoding]::Unicode.GetString($Bytes, $Offset, $end - $Offset)
}

function Get-LnkParsed {
    # Structural [MS-SHLLINK] parse. Returns $null when the file is not a
    # parseable Shell Link; otherwise a hashtable with:
    #   LinkInfoTarget - the actual target stored in LinkInfo (or $null)
    #   StringData     - name/relative_path/working_dir/arguments/icon_location (diagnostics only)
    #   LinkFlags      - raw LinkFlags value
    param([string]$LnkPath)
    try {
        $bytes = [System.IO.File]::ReadAllBytes($LnkPath)
        if ($bytes.Length -lt 76) { return $null }
        if ([System.BitConverter]::ToUInt32($bytes, 0) -ne 0x4C) { return $null }
        $flags = [System.BitConverter]::ToUInt32($bytes, 20)
        $isUnicode = [bool]($flags -band 0x80)
        $offset = 76

        if ($flags -band 0x1) {
            # HasLinkTargetIDList: WORD size followed by the IDList.
            if ($offset + 2 -gt $bytes.Length) { return $null }
            $idListSize = [System.BitConverter]::ToUInt16($bytes, $offset)
            $offset += 2 + $idListSize
            if ($offset -gt $bytes.Length) { return $null }
        }

        $linkInfoTarget = $null
        if ($flags -band 0x2) {
            # HasLinkInfo.
            $liStart = $offset
            if ($liStart + 28 -gt $bytes.Length) { return $null }
            $liSize = [System.BitConverter]::ToUInt32($bytes, $liStart)
            if ($liSize -lt 28 -or $liStart + $liSize -gt $bytes.Length) { return $null }
            $liHeaderSize = [System.BitConverter]::ToUInt32($bytes, $liStart + 4)
            $liFlags = [System.BitConverter]::ToUInt32($bytes, $liStart + 8)
            if ($liFlags -band 0x1) {
                # VolumeIDAndLocalBasePath present.
                $localBaseOffset = [System.BitConverter]::ToUInt32($bytes, $liStart + 16)
                $suffixOffset = [System.BitConverter]::ToUInt32($bytes, $liStart + 24)
                $target = $null
                if ($liHeaderSize -ge 0x24) {
                    $localBaseUnicodeOffset = [System.BitConverter]::ToUInt32($bytes, $liStart + 28)
                    if ($localBaseUnicodeOffset -ne 0) {
                        $target = Read-LnkUtf16String $bytes ($liStart + $localBaseUnicodeOffset)
                    }
                }
                if ([string]::IsNullOrEmpty($target) -and $localBaseOffset -ne 0) {
                    $target = Read-LnkAnsiString $bytes ($liStart + $localBaseOffset)
                }
                $suffix = $null
                if ($liHeaderSize -ge 0x24) {
                    $suffixUnicodeOffset = [System.BitConverter]::ToUInt32($bytes, $liStart + 32)
                    if ($suffixUnicodeOffset -ne 0) {
                        $suffix = Read-LnkUtf16String $bytes ($liStart + $suffixUnicodeOffset)
                    }
                }
                if ([string]::IsNullOrEmpty($suffix) -and $suffixOffset -ne 0) {
                    $suffix = Read-LnkAnsiString $bytes ($liStart + $suffixOffset)
                }
                if ($target -and -not [string]::IsNullOrEmpty($suffix)) {
                    if ($target.EndsWith('\') -or $target.EndsWith('/')) {
                        $target = $target + $suffix
                    } elseif (-not $target.EndsWith($suffix)) {
                        $target = $target + '\' + $suffix
                    }
                }
                $linkInfoTarget = $target
            }
            $offset += $liSize
        }

        $stringData = [ordered]@{}
        $fields = @(
            @(0x4, 'name'), @(0x8, 'relative_path'), @(0x10, 'working_dir'),
            @(0x20, 'arguments'), @(0x40, 'icon_location')
        )
        foreach ($field in $fields) {
            if ($flags -band $field[0]) {
                if ($offset + 2 -gt $bytes.Length) { break }
                $count = [System.BitConverter]::ToUInt16($bytes, $offset)
                $offset += 2
                if ($isUnicode) {
                    $byteCount = $count * 2
                    if ($offset + $byteCount -gt $bytes.Length) { break }
                    $stringData[$field[1]] = [System.Text.Encoding]::Unicode.GetString($bytes, $offset, $byteCount)
                    $offset += $byteCount
                } else {
                    if ($offset + $count -gt $bytes.Length) { break }
                    $stringData[$field[1]] = [System.Text.Encoding]::GetEncoding(1252).GetString($bytes, $offset, $count)
                    $offset += $count
                }
            }
        }

        return @{
            LinkInfoTarget = $linkInfoTarget
            StringData = $stringData
            LinkFlags = $flags
        }
    } catch {
        return $null
    }
}

function Resolve-LnkTarget {
    # Tries each resolution method in order and records every outcome.
    # Returns [pscustomobject] with Target (rooted path or $null), Method
    # ('wsh' | 'shell' | 'linkinfo' | 'none'), Attempts (ordered map), Parsed.
    param([string]$LnkPath)
    $attempts = [ordered]@{ wsh = $null; shell = $null; linkinfo = $null }
    Initialize-LnkCom

    if ($script:LnkWshShell) {
        try {
            $wshTarget = $script:LnkWshShell.CreateShortcut($LnkPath).TargetPath
            if ($wshTarget) { $attempts.wsh = $wshTarget } else { $attempts.wsh = '<empty>' }
        } catch { $attempts.wsh = "<error: $($_.Exception.Message)>" }
    } else { $attempts.wsh = '<unavailable>' }

    if ($script:LnkShellApp) {
        try {
            $folder = $script:LnkShellApp.Namespace((Split-Path -Parent $LnkPath))
            $item = $null
            if ($folder) { $item = $folder.ParseName((Split-Path -Leaf $LnkPath)) }
            if ($item) {
                $linkObj = $item.GetLink()
                if ($linkObj -and $linkObj.Path) {
                    $attempts.shell = [string]$linkObj.Path
                } else { $attempts.shell = '<empty>' }
            } else { $attempts.shell = '<no-item>' }
        } catch { $attempts.shell = "<error: $($_.Exception.Message)>" }
    } else { $attempts.shell = '<unavailable>' }

    $parsed = Get-LnkParsed $LnkPath
    if ($parsed) {
        if ($parsed.LinkInfoTarget) { $attempts.linkinfo = $parsed.LinkInfoTarget }
        else { $attempts.linkinfo = '<none>' }
    } else { $attempts.linkinfo = '<unparseable>' }

    foreach ($method in @('wsh', 'shell', 'linkinfo')) {
        $value = $attempts[$method]
        if ($value -and $value -notlike '<*') {
            if ([System.IO.Path]::IsPathRooted($value)) {
                return [pscustomobject]@{
                    Target = $value; Method = $method
                    Attempts = $attempts; Parsed = $parsed
                }
            }
            $attempts[$method] = "<relative: $value>"
        }
    }
    return [pscustomobject]@{
        Target = $null; Method = 'none'
        Attempts = $attempts; Parsed = $parsed
    }
}

function Test-LnkTargetEquals {
    param([string]$Target, [string]$ExpectedPath)
    if (-not $Target) { return $false }
    try {
        return ([System.IO.Path]::GetFullPath($Target) -ieq
                [System.IO.Path]::GetFullPath($ExpectedPath))
    } catch { return $false }
}

function Format-LnkResolution {
    param([string]$LnkPath, $Resolution)
    $a = $Resolution.Attempts
    return "shortcut_resolution path=$LnkPath method=$($Resolution.Method) target=$($Resolution.Target) wsh=[$($a.wsh)] shell=[$($a.shell)] linkinfo=[$($a.linkinfo)]"
}
