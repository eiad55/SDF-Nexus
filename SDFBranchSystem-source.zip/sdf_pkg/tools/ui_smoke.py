# -*- coding: utf-8 -*-
"""اختبار دخاني اختياري للواجهة باستخدام ملف مصدر يحدده المستخدم."""
import argparse
import os
import sys
import tempfile
from pathlib import Path


def shot(widget, name, output_dir):
    pix = widget.grab()
    target = output_dir / f"{name}.png"
    if not pix.save(str(target)):
        raise RuntimeError(f"تعذر حفظ لقطة الشاشة: {target}")
    print("shot:", target)


def main():
    parser = argparse.ArgumentParser(description="تشغيل الواجهة على قاعدة اختبار مؤقتة وبيانات من ملف تحدده.")
    parser.add_argument("source", type=Path, help="مسار ملف Excel المصدر؛ قد يحتوي بيانات حساسة")
    parser.add_argument("--sheet", default="ورقة2", help="اسم ورقة Excel المراد استيرادها")
    parser.add_argument("--username", default=os.environ.get("SDF_SMOKE_USERNAME", "admin"), help="اسم مستخدم الاختبار (الافتراضي من SDF_SMOKE_USERNAME أو admin)")
    parser.add_argument("--password-env", default="SDF_SMOKE_PASSWORD", help="اسم متغير البيئة الذي يحتوي كلمة مرور الاختبار؛ لا تمرر كلمة المرور مباشرة في سطر الأوامر")
    parser.add_argument("--output-dir", type=Path, help="مجلد لقطات الشاشة؛ الافتراضي مجلد مؤقت")
    args = parser.parse_args()
    src = args.source.resolve()
    if not src.is_file():
        parser.error(f"ملف المصدر غير موجود: {src}")
    password = os.environ.get(args.password_env)
    if not password:
        parser.error(
            f"متغير كلمة مرور الاختبار غير مضبوط: {args.password_env}. "
            "اضبطه لبيئة الاختبار بدل تضمين كلمة المرور في الشيفرة."
        )

    # Defer optional GUI imports until after argparse, so --help works even when
    # PySide6 is not installed. Keep the offscreen setting before importing Qt.
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))
    try:
        from sdf_app.ui.app import create_app
        from sdf_app.ui.context import AppContext
        from sdf_app.services import import_service as imp
        from sdf_app.services.auth_service import authenticate
        from sdf_app.ui.main_window import MainWindow
        import sdf_app.main as app_main
    except ImportError as exc:
        parser.error(
            f"تعذر تحميل اعتماديات واجهة الاختبار: {exc}. "
            "ثبّت متطلبات المشروع أولًا."
        )

    with tempfile.TemporaryDirectory(prefix="sdf_ui_smoke_") as tmp:
        work = Path(tmp)
        os.environ["SDF_DATA_DIR"] = str(work / "data")
        shots = args.output_dir.resolve() if args.output_dir else work / "shots"
        shots.mkdir(parents=True, exist_ok=True)
        ctx = AppContext()
        try:
            mapping = imp.auto_map_columns(imp.preview_sheet(src, args.sheet)["headers"])
            results = imp.analyze_rows(src, args.sheet, mapping, ctx.conn)
            rep = imp.execute_import(ctx.conn, results, source_file=str(src), sheet_name=args.sheet)
            print("imported:", rep["imported"])
            ctx.user = authenticate(ctx.conn, args.username, password)
            if not ctx.user:
                raise RuntimeError("فشل تسجيل الدخول بحساب الاختبار المحدد.")
            app = create_app([])
            window = MainWindow(ctx)
            pages = app_main._wire_pages(window, ctx)
            window.show()
            app.processEvents()
            shot(window, "00_main_dashboard", shots)
            window.show_page("files")
            app.processEvents()
            shot(window, "01_files", shots)
            window.show_page("review")
            app.processEvents()
            rows, _total = ctx.files.search({}, page=1, per_page=1)
            if rows:
                pages_ctx_review = window.pages["review"]
                pages_ctx_review.open_file(rows[0]["id"])
                app.processEvents()
                shot(window, "02_review", shots)
            from sdf_app.ui.file_dialog import FileDialog
            dlg = FileDialog(ctx)
            dlg.show()
            app.processEvents()
            shot(dlg, "03_file_dialog", shots)
            dlg.close()
            window.show_page("reports")
            app.processEvents()
            shot(window, "04_reports", shots)
            window.show_page("settings")
            app.processEvents()
            shot(window, "05_settings", shots)
            print("SMOKE OK")
            print("Screenshots:", shots)
            window.close()
            app.processEvents()
        finally:
            ctx.db.close()


if __name__ == "__main__":
    main()
