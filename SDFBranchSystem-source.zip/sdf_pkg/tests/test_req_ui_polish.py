# -*- coding: utf-8 -*-
"""اختبارات تحسين الواجهة v14 (بناءً على فحص بصري حقيقي على Windows):
خط عربي مضمّن، لا قصّ في الترويسة/العناوين، لا أعمدة صفر شاردة، أطوال تفاعلية."""
import pytest
from PySide6.QtGui import QFontDatabase
from PySide6.QtWidgets import QLabel

from sdf_app.ui.app import UI_FONT_FAMILY
from sdf_app.ui.context import AppContext


@pytest.fixture()
def ctx(tmp_path, qapp):
    c = AppContext(db_path=tmp_path / "ui14.db")
    c.user = {"id": 1, "username": "admin", "full_name": "مدير النظام", "role": "admin"}
    yield c
    c.db.close()


def test_bundled_arabic_font_is_registered_and_used(qapp):
    assert UI_FONT_FAMILY in QFontDatabase.families()
    assert qapp.font().family() == UI_FONT_FAMILY


def _main_with_dashboard(ctx, qapp):
    from sdf_app.ui.dashboard_page import DashboardPage
    from sdf_app.ui.main_window import MainWindow
    win = MainWindow(ctx)
    page = DashboardPage(ctx, win.show_page)
    win.register_page("dashboard", "لوحة التحكم", page)
    win.show_page("dashboard")
    return win, page


def test_sidebar_header_lines_fit_sidebar_width(ctx, qapp):
    """كل سطر في ترويسة الشريط الجانبي يجب أن يتسع داخل عرض التسمية بخطها
    الفعلي (السبب الجذري لقصّ الحروف على أجهزة Windows)."""
    win, _page = _main_with_dashboard(ctx, qapp)
    win.resize(1366, 768)
    win.show(); qapp.processEvents()
    sidebar_w = 264
    for name in ("sidebarTitle", "sidebarOrg"):
        lbl = win.findChild(QLabel, name)
        assert lbl is not None
        fm = lbl.fontMetrics()
        for line in lbl.text().split("\n"):
            for word in line.split():
                assert fm.horizontalAdvance(word) <= lbl.width(), (name, word)
        # ارتفاع التسمية يكفي نصها الملفوف بالكامل على عرضها الحالي
        assert lbl.height() >= lbl.heightForWidth(lbl.width()) - 2
    assert win.width() >= sidebar_w
    win.close()


def test_chart_panel_titles_complete_not_clipped(ctx, qapp):
    win, page = _main_with_dashboard(ctx, qapp)
    win.resize(1366, 768)
    win.show(); qapp.processEvents(); page.refresh(); qapp.processEvents()
    titles = [w for w in page.findChildren(QLabel) if w.objectName() == "chartTitle"]
    assert len(titles) == 3
    for t in titles:
        assert t.text().startswith("ملفات")  # الميم موجودة في النص أصلًا
        fm = t.fontMetrics()
        # العنوان إما ظاهر كاملًا على سطر، أو ملفوفًا بارتفاع كافٍ — لا قصّ صامت
        assert t.height() >= t.heightForWidth(t.width()) - 2
        assert fm.horizontalAdvance(t.text()) <= t.width() or t.wordWrap()
    win.close()


def test_zero_value_bars_draw_no_stray_stub(qapp):
    """قيم صفر لا ترسم أعمدة (كانت تظهر كعلامة | بجانب كل اسم)."""
    from PySide6.QtGui import QColor, QPixmap
    from sdf_app.ui.widgets import BarChart
    chart = BarChart()
    chart.resize(420, 120)
    chart.set_data([("تعز", 0), ("عدن", 0)])
    chart.show(); qapp.processEvents()
    img = chart.grab().toImage()
    bar = QColor("#1F3A5F")
    # منطقة الأعمدة فقط (بين منطقة القيمة يسارًا ومنطقة التسمية يمينًا) —
    # نص التسميات نفسه مرسوم بلون العمود فلا يدخل في الفحص
    fm = chart.fontMetrics()
    label_w = max(130, min(fm.horizontalAdvance("تعز") + 8, int(chart.width() * 0.45)))
    x_end = chart.width() - label_w - 16
    hits = 0
    for x in range(80, x_end):
        for y in range(img.height()):
            if img.pixelColor(x, y) == bar:
                hits += 1
    assert hits == 0  # لا بكسل بلون العمود في منطقة الأعمدة عند القيم الصفرية
    chart.close()


def test_dashboard_heights_are_responsive_not_fixed(ctx, qapp):
    """عند نافذة قصيرة: الصفحة تتمدد/تُمرَّر بدل انضغاط البطاقات أو قصّها،
    وبطاقات المؤشرات بارتفاع محكوم بالمحتوى لا تتمدد بلا حد."""
    win, page = _main_with_dashboard(ctx, qapp)
    win.resize(1160, 560)
    win.show(); qapp.processEvents(); page.refresh(); qapp.processEvents()
    card_h = page.total_card.height()
    assert 80 <= card_h <= 190
    # منطقة التمرير فعّالة: مدى التمرير العمودي موجب عند قصر النافذة
    sb = page._scroll.verticalScrollBar()
    assert sb.maximum() > 0
    win.close()


def test_file_dialog_never_exceeds_screen(ctx, qapp):
    from sdf_app.ui.file_dialog import FileDialog
    dlg = FileDialog(ctx)
    avail = dlg.screen().availableGeometry()
    assert dlg.height() <= int(avail.height() * 0.94) + 2
    dlg.close()
