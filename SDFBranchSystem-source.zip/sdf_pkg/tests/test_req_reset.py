# -*- coding: utf-8 -*-
"""اختبارات متطلبات 2026-10-19 — إعادة تهيئة النظام (بند 12) على مجلد تجريبي فقط."""
import pytest

from sdf_app import config
from sdf_app.database.connection import Database
from sdf_app.database.seeds import seed_all
from sdf_app.services import backup_service, reset_service
from sdf_app.services.auth_service import create_user
from sdf_app.services.file_service import FileService


@pytest.fixture()
def env(tmp_path, monkeypatch):
    data = tmp_path / "data"
    data.mkdir()
    monkeypatch.setenv("SDF_DATA_DIR", str(data))
    db = Database(config.db_path())
    conn = db.connect()
    seed_all(conn)
    fs = FileService(conn)
    fid = fs.create({"file_number": 999, "program_name": "بيانات قبل التهيئة",
                     "received_date": "2026-01-05"}, user_id=1)
    att = config.attachments_dir() / str(fid)
    att.mkdir(parents=True, exist_ok=True)
    (att / "a.pdf").write_bytes(b"data")
    yield conn, db, data, fid
    db.close()


def test_prepare_reset_admin_only(env):
    conn, db, data, fid = env
    clerk = create_user(conn, "clerk9", "موظف", "Clerk@123", "data_entry")
    with pytest.raises(PermissionError):
        reset_service.prepare_reset(conn, clerk)
    with pytest.raises(PermissionError):
        reset_service.prepare_reset(conn, None)
    # لم يتغير شيء
    assert conn.execute("SELECT COUNT(*) c FROM training_files").fetchone()["c"] == 1


def test_reset_cycle_backup_verified_wipe_reinit_restore(env, tmp_path, monkeypatch):
    conn, db, data, fid = env
    zip_path = reset_service.prepare_reset(conn, 1)
    assert zip_path.exists() and str(zip_path).startswith(str(config.backups_dir()))
    db.close()
    # المسح + إعادة التهيئة
    reset_service.execute_wipe(config.db_path(), config.attachments_dir())
    assert not config.db_path().exists()
    assert list(config.attachments_dir().iterdir()) == []
    assert zip_path.exists()  # النسخة خارج نطاق المسح وباقية
    reset_service.reinitialize(config.db_path())
    db2 = Database(config.db_path())
    c2 = db2.connect()
    seed_all(c2)
    assert c2.execute("SELECT COUNT(*) c FROM training_files").fetchone()["c"] == 0
    admin = c2.execute("SELECT role, must_change_password FROM users WHERE username='admin'").fetchone()
    assert admin["role"] == "admin" and admin["must_change_password"] == 1
    db2.close()
    # الاستعادة من نسخة ما قبل التهيئة تعيد البيانات فعليًا (بيئة ثانية نظيفة)
    data2 = tmp_path / "data2"
    data2.mkdir()
    monkeypatch.setenv("SDF_DATA_DIR", str(data2))
    backup_service.restore_backup(zip_path, confirm=True)
    db3 = Database(config.db_path())
    c3 = db3.connect()
    row = c3.execute("SELECT program_name FROM training_files WHERE file_number=999").fetchone()
    assert row is not None and row["program_name"] == "بيانات قبل التهيئة"
    db3.close()


def test_prepare_failure_aborts_without_touching_data(env, monkeypatch):
    conn, db, data, fid = env

    def boom(*a, **k):
        raise RuntimeError("محاكاة فشل النسخ")

    monkeypatch.setattr(backup_service, "create_backup", boom)
    with pytest.raises(RuntimeError):
        reset_service.prepare_reset(conn, 1)
    assert conn.execute("SELECT COUNT(*) c FROM training_files").fetchone()["c"] == 1
    assert (config.attachments_dir() / str(fid) / "a.pdf").exists()
    assert config.db_path().exists()
