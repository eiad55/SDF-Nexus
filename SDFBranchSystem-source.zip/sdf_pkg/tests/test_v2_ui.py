# -*- coding: utf-8 -*-
"""اختبارات دخان للواجهة (offscreen): بناء كل الصفحات الجديدة والمعدّلة وتحديثها."""
import pytest

from PySide6.QtWidgets import QApplication, QMessageBox

from sdf_app.ui.context import AppContext


@pytest.fixture()
def ctx(tmp_path, qapp, monkeypatch):
    # نوافذ صامتة حتى لا يعلّق الاختبار
    monkeypatch.setattr(QMessageBox, "warning", staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "information", staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "critical", staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "question",
                        staticmethod(lambda *a, **k: QMessageBox.Yes))
    c = AppContext(db_path=tmp_path / "ui.db")
    c.user = {"id": 1, "username": "admin", "full_name": "مدير النظام", "role": "admin"}
    yield c
    c.db.close()


def _seed_file(ctx):
    from sdf_app.services.file_service import FileService
    fs = FileService(ctx.conn)
    return fs.create({"file_number": 901, "program_name": "برنامج واجهة",
                      "received_date": "2026-01-05", "exec_start": "2026-02-01",
                      "funding_amount": 75000, "approved_trainees": 12}, user_id=1)


def test_main_window_wires_all_pages(ctx, qapp):
    from sdf_app.main import _wire_pages
    from sdf_app.ui.main_window import MainWindow
    win = MainWindow(ctx)
    _wire_pages(win, ctx)
    for key in ("dashboard", "files", "review", "disburse", "entities",
                "contributions", "reports", "settings"):
        assert key in win.pages, key
    # عناصر القائمة الجانبية الجديدة ظاهرة للمدير
    labels = [b.text() for b in win.nav_group.buttons()]
    assert "الصرف" in labels and "الجهات المستفيدة" in labels and "المساهمات الشهرية" in labels
    win.close()


def test_dashboard_refresh_with_filter(ctx, qapp):
    _seed_file(ctx)
    from sdf_app.ui.dashboard_page import DashboardPage
    d = DashboardPage(ctx, on_navigate=lambda *a: None)
    d.refresh()
    assert "901" not in d.total_card.value_lbl.text()  # الإجمالي رقم فقط
    assert d.total_card.value_lbl.text().strip() == "1"
    # ترشيح بفرع غير موجود ← صفر
    d._apply_filter({"branch_id": 99999}, "فرع وهمي")
    assert d.total_card.value_lbl.text().strip() == "0"
    assert not d.btn_clear_filter.isHidden()
    d.clear_filter()
    assert d.total_card.value_lbl.text().strip() == "1"
    # بطاقة التمويل
    assert "75,000" in d.fin_cards["funding"].value_lbl.text()
    assert d.fin_cards["trainees"].value_lbl.text().strip() == "12"
    d.close()


def test_files_page_search_and_columns(ctx, qapp):
    _seed_file(ctx)
    from sdf_app.ui.files_page import FilesPage
    p = FilesPage(ctx)
    p.refresh()
    assert p.total == 1
    headers = [p.table.horizontalHeaderItem(i).text() for i in range(p.table.columnCount())]
    assert "رقم التسميح" in headers and "رقم الملف في الفرع" in headers
    assert not hasattr(p, "diff_only")  # أُزيل خيار الفروقات
    p.close()


def test_file_dialog_new_and_save(ctx, qapp):
    from sdf_app.ui.file_dialog import FileDialog
    dlg = FileDialog(ctx)
    # الحقول الإلزامية: الحفظ بدونها يُظهر تحذيرًا ولا يقبل
    dlg.save()
    # لا يزال مفتوحًا (لم يُقبل)
    assert dlg.result() == 0
    # تعبئة الإلزامي
    dlg.widgets["file_number"][0].setValue(902)
    for key in ("branch_id", "program_id", "beneficiary_id"):
        w, _ = dlg.widgets[key]
        assert w.count() >= 0  # القوائم المقيدة موجودة
    dlg.close()


def test_file_dialog_existing_with_tables(ctx, qapp):
    fid = _seed_file(ctx)
    ctx.conn.execute("INSERT INTO trainees_nomination (file_id, seq, full_name, beneficiary_id)"
                     " VALUES (?,?,?,?)", (fid, 1, "مرشح أ", None))
    ctx.conn.commit()
    from sdf_app.ui.file_dialog import FileDialog
    dlg = FileDialog(ctx, file_id=fid)
    assert dlg.nom_table.rowCount() == 1
    dlg._att_carry_from_nomination()
    assert dlg.att_table.rowCount() == 1
    dlg.close()


def test_disbursement_page_flow(ctx, qapp):
    _seed_file(ctx)
    from sdf_app.ui.disbursement_page import DisbursementPage
    p = DisbursementPage(ctx)
    p.search_box.setText("901")
    p._add_by_search()
    assert p.items and p.table.rowCount() == 1
    p.close()


def test_entities_page_crud(ctx, qapp):
    from sdf_app.ui.entities_page import EntitiesPage
    p = EntitiesPage(ctx)
    p.refresh()
    n0 = p.table.rowCount()
    ctx.conn.execute("INSERT INTO entities (name, kind, tax_number, employee_count)"
                     " VALUES (?,?,?,?)", ("جهة اختبار", "beneficiary", "999", 25))
    ctx.conn.commit()
    p.refresh()
    assert p.table.rowCount() == n0 + 1
    p.close()


def test_contributions_page(ctx, qapp):
    from sdf_app.ui.contributions_page import ContributionsPage
    ctx.conn.execute("INSERT INTO entities (name, kind) VALUES (?,?)", ("جهة مساهمات", "beneficiary"))
    ctx.conn.commit()
    p = ContributionsPage(ctx)
    p.refresh()
    assert p.table.rowCount() == 0  # بلا جهة مختارة
    p.entity_cb.setCurrentIndex(0)
    p.refresh()
    assert p.table.rowCount() == 12
    assert "50%" in p.rates_lbl.text()
    p.close()


def test_settings_pages_build(ctx, qapp):
    from sdf_app.ui.settings_page import SettingsPage
    s = SettingsPage(ctx)
    names = [s.tabs.tabText(i) for i in range(s.tabs.count())]
    assert "المدربون" in names and "الصلاحيات" in names and "البرامج التدريبية" in [
        s.lookup_cb.itemText(i) for i in range(s.lookup_cb.count())]
    s.close()


def test_review_page_build(ctx, qapp):
    fid = _seed_file(ctx)
    from sdf_app.ui.review_page import ReviewPage
    r = ReviewPage(ctx)
    r.open_file(fid)
    assert r.check_table.rowCount() >= 10  # كل البنود ظاهرة
    assert "901" in r.file_title.text()
    r.close()


# -- إصلاحات المراجعة (واجهة): الفارغ ≠ صفر، الدولار، الصلاحيات، التعديل الموثق --------------
def _ui_user(ctx, role):
    from sdf_app.services.auth_service import create_user
    uid = create_user(ctx.conn, f"ui_{role}", role, "secret123", role, actor_id=1)
    return {"id": uid, "username": f"ui_{role}", "full_name": role, "role": role}


def _walk_ui(ctx, fid, codes):
    from sdf_app.services.file_service import FileService
    fs = FileService(ctx.conn)
    for code in codes:
        fs.change_status(fid, code, user_id=1)
    return fs


_TO_READY = ("received", "tech_review", "tech_done", "finance_review", "ready_approve")


def test_file_dialog_empty_counts_stay_null_not_zero(ctx, qapp):
    from sdf_app.ui.file_dialog import FileDialog
    keys = ("contract_trainees", "nominees_count", "attendance_trainees",
            "certificates_count", "approved_trainees")
    dlg = FileDialog(ctx)
    assert all(dlg._collect()[k] is None for k in keys)
    dlg.widgets["certificates_count"][0].setValue(0)  # صفر حقيقي يبقى صفرًا
    assert dlg._collect()["certificates_count"] == 0
    dlg.close()
    # فتح ملف قائم وحفظه لا يحوّل المفقود إلى صفر
    fid = _seed_file(ctx)
    dlg = FileDialog(ctx, file_id=fid)
    dlg.save()
    row = ctx.conn.execute("SELECT attendance_trainees, nominees_count, approved_trainees"
                           " FROM training_files WHERE id=?", (fid,)).fetchone()
    assert row[0] is None and row[1] is None and row[2] == 12


def test_file_dialog_usd_contract_is_shown_in_riyals(ctx, qapp):
    from sdf_app.ui.file_dialog import FileDialog
    dlg = FileDialog(ctx)
    w = lambda k: dlg.widgets[k][0]
    w("contract_trainees").setValue(10)
    w("contract_hours").setValue(20)
    w("contract_cost_per_trainee").setValue(500)
    w("cost_currency").setCurrentIndex(w("cost_currency").findData("USD"))
    w("exchange_rate").setValue(2500)
    dlg._recalc_contract()
    assert "12,500,000" in dlg.contract_total_lbl.text()
    assert "62,500" in dlg.contract_hour_lbl.text()
    w("exchange_rate").setValue(0)
    dlg._recalc_contract()
    assert "سعر الصرف" in dlg.contract_total_lbl.text()  # تنبيه بدل رقم مضلل
    dlg.close()


def test_file_dialog_status_options_follow_permissions(ctx, qapp):
    from sdf_app.ui.file_dialog import FileDialog
    fid = _seed_file(ctx)
    dlg = FileDialog(ctx, file_id=fid)
    assert dlg.status_cb.count() >= 1 and dlg.status_apply_btn.isEnabled()
    dlg.close()
    ctx.user = _ui_user(ctx, "viewer")
    dlg = FileDialog(ctx, file_id=fid)
    assert dlg.status_cb.count() == 0 and not dlg.status_apply_btn.isEnabled()
    dlg.close()
    ctx.user = _ui_user(ctx, "data_entry")
    dlg = FileDialog(ctx, file_id=fid)
    assert [dlg.status_cb.itemData(i) for i in range(dlg.status_cb.count())] == ["received"]
    dlg.close()


def test_approval_with_blockers_goes_through_documented_exception(ctx, qapp, monkeypatch):
    from PySide6.QtWidgets import QInputDialog
    from sdf_app.services.file_service import FileService
    from sdf_app.ui.file_dialog import FileDialog
    fs = FileService(ctx.conn)
    fid = fs.create({"file_number": 950, "program_name": "بلا مالية",
                     "received_date": "2026-01-05"}, user_id=1)
    _walk_ui(ctx, fid, _TO_READY)
    ctx.user = _ui_user(ctx, "finance_reviewer")
    dlg = FileDialog(ctx, file_id=fid)
    dlg.status_cb.setCurrentIndex(dlg.status_cb.findData("approved"))
    monkeypatch.setattr(QInputDialog, "getText", staticmethod(lambda *a, **k: ("", True)))
    dlg._change_status()  # سبب فارغ ← لا اعتماد
    assert fs.get(fid)["status_code"] == "ready_approve"
    monkeypatch.setattr(QInputDialog, "getText",
                        staticmethod(lambda *a, **k: ("قرار الإدارة", True)))
    dlg._change_status()
    assert fs.get(fid)["status_code"] == "approved"
    assert ctx.conn.execute("SELECT COUNT(*) FROM audit_log WHERE action='status.exception'"
                            " AND entity_id=?", (fid,)).fetchone()[0] == 1
    dlg.close()


def test_financial_edit_after_approval_needs_permission_and_reason(ctx, qapp, monkeypatch):
    from PySide6.QtWidgets import QInputDialog
    from sdf_app.services.file_service import FileService
    from sdf_app.ui.file_dialog import FileDialog
    fs = FileService(ctx.conn)
    fid = fs.create({"file_number": 951, "program_name": "معتمد", "received_date": "2026-01-05",
                     "funding_amount": 10000, "approved_trainees": 10,
                     "approved_cost_per_trainee": 1000, "approved_hours": 20}, user_id=1)
    _walk_ui(ctx, fid, _TO_READY + ("approved",))
    monkeypatch.setattr(QInputDialog, "getText",
                        staticmethod(lambda *a, **k: ("خطأ في الإدخال", True)))
    # مراجع فني (بلا صلاحية الاعتماد المالي): مرفوض
    ctx.user = _ui_user(ctx, "tech_reviewer")
    dlg = FileDialog(ctx, file_id=fid)
    dlg.widgets["funding_amount"][0].setValue(9000)
    dlg.save()
    assert fs.get(fid)["funding_amount"] == 10000
    dlg.close()
    # المدير: يمر بسبب مكتوب ويُدقَّق بالقيمة القديمة والجديدة
    ctx.user = {"id": 1, "username": "admin", "full_name": "مدير النظام", "role": "admin"}
    dlg = FileDialog(ctx, file_id=fid)
    dlg.widgets["funding_amount"][0].setValue(9000)
    dlg.save()
    assert fs.get(fid)["funding_amount"] == 9000
    detail = ctx.conn.execute("SELECT details FROM audit_log WHERE action='finance.update'"
                              " AND entity_id=? ORDER BY id DESC LIMIT 1", (fid,)).fetchone()[0]
    assert "10000" in detail and "9000" in detail and "خطأ في الإدخال" in detail
    dlg.close()
