# -*- coding: utf-8 -*-
"""اختبارات ميزات v15 (بنود 1–14 المتفق عليها مع المستخدم)."""
import pytest
from PySide6.QtCore import QSettings, Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QMessageBox, QProgressBar

from sdf_app.services.file_service import FileService
from sdf_app.ui.context import AppContext


@pytest.fixture()
def ctx(tmp_path, qapp, monkeypatch):
    for name in ("warning", "information", "critical"):
        monkeypatch.setattr(QMessageBox, name,
                            staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "question",
                        staticmethod(lambda *a, **k: QMessageBox.Yes))
    c = AppContext(db_path=tmp_path / "f15.db")
    c.user = {"id": 1, "username": "admin", "full_name": "مدير النظام", "role": "admin"}
    yield c
    c.db.close()


def _mkfile(ctx, number=11, program="برنامج تجريبي", received="2026-01-05"):
    fs = FileService(ctx.conn)
    return fs.create({"file_number": number, "program_name": program,
                      "received_date": received, "exec_start": "2026-02-01",
                      "approved_trainees": 10, "funding_amount": 1000,
                      "claimed_amount": 1200}, user_id=1)


def test_completion_map_matches_reviewed_items(ctx):
    fid = _mkfile(ctx)
    # تجسيد بنود المراجعة كما تفعل صفحة المراجعة عند فتح الملف
    doc_types = [r["id"] for r in ctx.conn.execute(
        "SELECT id FROM document_types WHERE active=1 ORDER BY sort_order")]
    assert doc_types
    for dt in doc_types:
        ctx.conn.execute(
            "INSERT INTO review_items (file_id, document_type_id) VALUES (?,?)", (fid, dt))
    ctx.conn.commit()
    items = ctx.files.review_items(fid)
    assert len(items) == len(doc_types)
    for it in items[:2]:
        ctx.conn.execute("UPDATE review_items SET result='مطابق' WHERE id=?", (it["id"],))
    ctx.conn.commit()
    pct = ctx.files.completion_map([fid])[fid]
    assert pct == round(100 * 2 / len(doc_types))
    # ملف لم يُفتح في المراجعة قط: اكتماله صفر لا مئة
    fid2 = _mkfile(ctx, number=12)
    assert ctx.files.completion_map([fid2])[fid2] == 0


def test_quick_search_finds_file_and_opens(ctx, qapp):
    fid = _mkfile(ctx)
    got = []
    from sdf_app.ui.quick_search import QuickSearchDialog
    dlg = QuickSearchDialog(ctx, lambda k, i: got.append((k, i)))
    dlg._refresh("برنامج تجريبي")
    assert dlg.list.count() >= 1
    dlg._activate(dlg.list.item(0))
    assert got == [("file", fid)]


def _window(ctx, qapp):
    from sdf_app.ui.dashboard_page import DashboardPage
    from sdf_app.ui.files_page import FilesPage
    from sdf_app.ui.main_window import MainWindow
    win = MainWindow(ctx)
    dash = DashboardPage(ctx, win.show_page)
    win.register_page("dashboard", "لوحة التحكم", dash)
    files = FilesPage(ctx)
    win.register_page("files", "إدارة الملفات", files)
    return win, dash, files


def test_main_window_toast_and_status(ctx, qapp):
    win, _d, _f = _window(ctx, qapp)
    win.show(); qapp.processEvents()
    win.notify("تم الحفظ")
    assert win._toast is not None and win._toast.isVisible()
    # شريط الحالة بسيط كما طلبه المستخدم (أُلغي الشريط الحي بقراره)
    assert "متصل بقاعدة البيانات" in win.statusBar().currentMessage()
    assert not hasattr(win, "_backup_btn")
    win.close()


def test_session_restore_last_page(ctx, qapp):
    st = QSettings("SkillsDevelopmentFund", "SDFBranchSystem")
    st.setValue("ui/admin/last_page", "files")
    win, _d, _f = _window(ctx, qapp)
    win.restore_session()
    assert win._current_key == "files"
    win.close()
    st.remove("ui/admin/last_page")


def test_dashboard_overdue_banner_and_welcome(ctx, qapp):
    from sdf_app.ui.dashboard_page import DashboardPage
    page = DashboardPage(ctx, lambda *a: None)
    page.show(); qapp.processEvents(); page.refresh(); qapp.processEvents()
    # قاعدة فارغة: لوحة البداية ظاهرة ولا تنبيه
    assert page.welcome.isVisible()
    assert not page.alert_bar.isVisible()
    # ملف قديم غير منتهٍ: يظهر التنبيه وتختفي لوحة البداية
    fid = _mkfile(ctx, received="2025-01-01")
    ctx.conn.execute("UPDATE training_files SET received_date='2025-01-01' WHERE id=?", (fid,))
    ctx.conn.commit()
    page.refresh(); qapp.processEvents()
    assert not page.welcome.isVisible()
    assert page.alert_bar.isVisible()
    assert "متأخر" in page.alert_lbl.text()
    page.close()


def test_files_page_completion_column_and_preview(ctx, qapp):
    _mkfile(ctx)
    from sdf_app.ui.files_page import FilesPage
    page = FilesPage(ctx)
    page.show(); qapp.processEvents(); page.refresh(); qapp.processEvents()
    headers = [page.table.horizontalHeaderItem(j).text() for j in range(page.table.columnCount())]
    assert "اكتمال المستندات" in headers
    col = headers.index("اكتمال المستندات")
    bar = page.table.cellWidget(0, col)
    assert isinstance(bar, QProgressBar)
    # المعاينة السريعة
    page.btn_preview.setChecked(True)
    page.table.selectRow(0)
    page.table.setCurrentCell(0, 0)  # تثبيت الخلية الجارية كما تفعل نقرة الماوس
    qapp.processEvents()
    page._update_preview()
    assert "برنامج تجريبي" in page.pv_body.text()
    page.close()


def test_files_page_enter_opens_and_reveal(ctx, qapp):
    fid = _mkfile(ctx)
    opened = []
    from sdf_app.ui.files_page import FilesPage
    page = FilesPage(ctx)
    page.on_open_file = lambda i: opened.append(i)
    page.show(); qapp.processEvents(); page.refresh(); qapp.processEvents()
    page.table.selectRow(0)
    page.table.setFocus()
    QTest.keyClick(page.table, Qt.Key_Return)
    qapp.processEvents()
    assert opened == [fid]
    page.reveal_file(fid)
    assert page.selected_file_id() == fid
    page.close()


def test_files_page_column_toggle_persists(ctx, qapp):
    from sdf_app.ui.files_page import FilesPage
    page = FilesPage(ctx)
    page.show(); qapp.processEvents()
    page._set_column_visible(2, False)
    assert page.table.isColumnHidden(2)
    st = QSettings("SkillsDevelopmentFund", "SDFBranchSystem")
    assert 2 in [int(x) for x in (st.value("ui/admin/files_hidden_columns") or [])]
    page._set_column_visible(2, True)
    page.close()


def test_disbursement_count_label(ctx, qapp):
    fid = _mkfile(ctx)
    from sdf_app.ui.disbursement_page import DisbursementPage
    page = DisbursementPage(ctx)
    page.items.append(fid)
    page._reload_table()
    assert "1" in page.count_lbl.text()
    page.close()


# -- تدقيق v17 (من صور جهاز المستخدم الحقيقي) --------------------------------

def test_settings_nav_titles_and_tabs(ctx, qapp):
    from sdf_app.ui.main_window import MainWindow
    from sdf_app.ui.settings_page import SettingsPage
    from sdf_app.ui.dashboard_page import DashboardPage
    win = MainWindow(ctx)
    win.register_page("dashboard", "لوحة التحكم", DashboardPage(ctx, win.show_page))
    sp = SettingsPage(ctx)
    win.register_page("settings", "الإعدادات", sp)
    win.register_page("users", "المستخدمون", sp)
    win.register_page("backup", "النسخ الاحتياطي", sp)
    win.show(); qapp.processEvents()
    win.show_page("backup")
    assert win.page_title.text() == "النسخ الاحتياطي"
    assert sp.tabs.tabText(sp.tabs.currentIndex()) == "النسخ الاحتياطي"
    win.show_page("users")
    assert win.page_title.text() == "المستخدمون"
    assert sp.tabs.tabText(sp.tabs.currentIndex()) == "المستخدمون"
    win.show_page("settings")
    assert win.page_title.text() == "الإعدادات"
    win.close()


def test_chart_zero_rows_draw_nothing(ctx, qapp):
    from sdf_app.ui.widgets import BarChart
    c = BarChart()
    c.setMinimumSize(560, 120)
    c.set_data([("تعز", 0), ("الحديدة", 0)])
    c.show(); qapp.processEvents()
    img = c.grab().toImage()
    # منطقة الرسم بين التسمية (يمين) والقيمة (يسار): لا بكسل غير الخلفية
    bg = img.pixel(300, 20)
    non_bg = 0
    for x in range(90, 400):
        for y in range(5, 110):
            if img.pixel(x, y) != bg:
                non_bg += 1
    assert non_bg == 0
    c.close()


def test_disburse_form_label_first(ctx, qapp):
    from PySide6.QtWidgets import QLabel
    from sdf_app.ui.disbursement_page import DisbursementPage
    page = DisbursementPage(ctx)
    gf = page.btn_save_row.parentWidget()
    lay = gf.layout()
    first = lay.itemAt(0).widget()
    assert isinstance(first, QLabel) and "مبلغ الصرف" in first.text()
    page.close()


def test_review_search_field_sized(ctx, qapp):
    from sdf_app.ui.review_page import ReviewPage
    page = ReviewPage(ctx)
    page.resize(1200, 700)
    page.show(); qapp.processEvents()
    assert page.file_search.width() >= 260
    page.close()


def test_files_empty_hint(ctx, qapp):
    from sdf_app.ui.files_page import FilesPage
    page = FilesPage(ctx)
    page.show(); qapp.processEvents(); page.refresh(); qapp.processEvents()
    assert page.empty_hint.isVisible()
    _mkfile(ctx)
    page.refresh(); qapp.processEvents()
    assert not page.empty_hint.isVisible()
    page.close()


def test_datefield_placeholder_arabic(ctx, qapp):
    from sdf_app.ui.widgets import DateField
    f = DateField()
    assert "التاريخ" in f.edit.placeholderText()
