# -*- coding: utf-8 -*-
"""اختبارات تركيبات Shell Link الاصطناعية (tests/fixtures/lnk).

تتحقق بمحلّل مرجعي مستقل بلغة Python (وفق [MS-SHLLINK]) من أن التركيبات
تحمل القيم التي يعلنها manifest.json، وأن محلّل PowerShell المشترك
(tools/lnk_shortcut.ps1 عبر tools/test_lnk_parser.ps1) يستخرج الأهداف
نفسها عندما تتوفر pwsh.

حالة الفخ هي الأهم: trap_other_target.lnk هدفها الفعلي notepad.exe بينما
تحمل مسار الملف التنفيذي المتوقع كنص داخل IconLocation وWorkingDir —
أي فحص يقبل بوجود النص الخام داخل البايتات (عيب v9 المثبت) سيراها مطابقة
خطأً. المحلّل البنيوي يجب أن يقرأ notepad.exe حصرًا.
"""
import json
import shutil
import struct
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "tests" / "fixtures" / "lnk"
MANIFEST = json.loads((FIXTURES / "manifest.json").read_text(encoding="utf-8"))
EXPECTED_EXE = MANIFEST["expected_exe"]


def _ansi(data: bytes, off: int):
    if off <= 0 or off >= len(data):
        return None
    end = data.find(b"\x00", off)
    if end == -1:
        return None
    if end == off:
        return ""
    return data[off:end].decode("cp1252")


def _utf16(data: bytes, off: int):
    if off <= 0 or off + 2 > len(data):
        return None
    end = off
    while end + 2 <= len(data) and data[end:end + 2] != b"\x00\x00":
        end += 2
    if end == off:
        return ""
    return data[off:end].decode("utf-16-le")


def reference_linkinfo_target(data: bytes):
    """استخراج هدف LinkInfo بنيويًا (مرجع مستقل عن محلّل PowerShell)."""
    if len(data) < 76 or struct.unpack_from("<I", data, 0)[0] != 0x4C:
        return None
    flags = struct.unpack_from("<I", data, 20)[0]
    offset = 76
    if flags & 0x1:
        (size,) = struct.unpack_from("<H", data, offset)
        offset += 2 + size
    if not (flags & 0x2):
        return None
    li = offset
    if li + 28 > len(data):
        return None
    li_size, li_header, li_flags = struct.unpack_from("<III", data, li)
    if li_size < 28 or li + li_size > len(data):
        return None
    if not (li_flags & 0x1):
        return None
    lb_off, suf_off = struct.unpack_from("<II", data, li + 16)[0], \
        struct.unpack_from("<I", data, li + 24)[0]
    target = None
    if li_header >= 0x24:
        (lbu_off,) = struct.unpack_from("<I", data, li + 28)
        if lbu_off:
            target = _utf16(data, li + lbu_off)
    if not target and lb_off:
        target = _ansi(data, li + lb_off)
    suffix = None
    if li_header >= 0x24:
        (sufu_off,) = struct.unpack_from("<I", data, li + 32)
        if sufu_off:
            suffix = _utf16(data, li + sufu_off)
    if not suffix and suf_off:
        suffix = _ansi(data, li + suf_off)
    if target and suffix:
        if target.endswith(("\\", "/")):
            target = target + suffix
        elif not target.endswith(suffix):
            target = target + "\\" + suffix
    return target


@pytest.mark.parametrize("fx", MANIFEST["fixtures"], ids=lambda f: f["file"])
def test_reference_parser_matches_manifest(fx):
    data = (FIXTURES / fx["file"]).read_bytes()
    target = reference_linkinfo_target(data)
    assert target == fx["target"], \
        f"{fx['file']}: extracted {target!r} != manifest {fx['target']!r}"
    is_match = bool(target) and target.lower() == EXPECTED_EXE.lower()
    assert is_match == fx["matches_run_exe"]


def test_trap_fixture_would_fool_raw_string_search():
    """توثيق دائم لعيب v9: النص الخام موجود، والهدف الفعلي مختلف."""
    data = (FIXTURES / "trap_other_target.lnk").read_bytes()
    raw_latin1 = data.decode("latin-1")
    raw_utf16 = data.decode("utf-16-le", errors="ignore")
    assert EXPECTED_EXE in raw_latin1 or EXPECTED_EXE in raw_utf16, \
        "التركيبة يجب أن تحمل المسار كنص خام حتى تكون فخًا صالحًا"
    assert reference_linkinfo_target(data) == r"C:\Windows\System32\notepad.exe"


def _find_pwsh():
    return shutil.which("pwsh") or (
        "/tmp/pwsh/pwsh" if Path("/tmp/pwsh/pwsh").is_file() else None)


def test_powershell_parser_fixtures_when_pwsh_available():
    pwsh = _find_pwsh()
    if not pwsh:
        pytest.skip("pwsh غير متاحة في هذه البيئة؛ تُنفَّذ في خطوة CI على Windows")
    script = ROOT / "tools" / "test_lnk_parser.ps1"
    proc = subprocess.run(
        [pwsh, "-NoProfile", "-File", str(script), "-FixturesDir", str(FIXTURES)],
        capture_output=True, text=True, timeout=180)
    assert proc.returncode == 0, proc.stdout + proc.stderr
    assert "ALL 8 PASS" in proc.stdout
