# -*- coding: utf-8 -*-
"""اختبارات v16: إلغاء شريط الحالة الحي + الإجراءات الجماعية الموسعة."""
import pytest
from PySide6.QtWidgets import QFileDialog, QMessageBox

from sdf_app.services.file_service import FileService
from sdf_app.ui.context import AppContext


@pytest.fixture()
def ctx(tmp_path, qapp, monkeypatch):
    for name in ("warning", "information", "critical"):
        monkeypatch.setattr(QMessageBox, name,
                            staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "question",
                        staticmethod(lambda *a, **k: QMessageBox.Yes))
    c = AppContext(db_path=tmp_path / "f16.db")
    c.user = {"id": 1, "username": "admin", "full_name": "مدير النظام", "role": "admin"}
    yield c
    c.db.close()


def _mkfile(ctx, number, program):
    return FileService(ctx.conn).create(
        {"file_number": number, "program_name": program,
         "received_date": "2026-01-05", "exec_start": "2026-02-01",
         "approved_trainees": 10, "funding_amount": 1000,
         "claimed_amount": 1200}, user_id=1)


def _page_with_two(ctx, qapp):
    _mkfile(ctx, 21, "برنامج أول")
    _mkfile(ctx, 22, "برنامج ثانٍ")
    from sdf_app.ui.files_page import FilesPage
    page = FilesPage(ctx)
    page.show(); qapp.processEvents(); page.refresh(); qapp.processEvents()
    return page


def _select_first(page, qapp):
    page.table.selectRow(0)
    page.table.setCurrentCell(0, 0)
    qapp.processEvents()


def test_bundle_pdf_merges_forms(ctx, tmp_path):
    f1 = _mkfile(ctx, 21, "برنامج أول")
    f2 = _mkfile(ctx, 22, "برنامج ثانٍ")
    from sdf_app.reports.bulk_forms import build_forms_bundle
    out = build_forms_bundle(ctx.files, ctx.settings(), [f1, f2],
                             tmp_path / "bundle.pdf")
    assert out.exists() and out.stat().st_size > 1000
    from pypdf import PdfReader
    assert len(PdfReader(str(out)).pages) >= 2


def test_bulk_export_selected_only(ctx, tmp_path, qapp, monkeypatch):
    page = _page_with_two(ctx, qapp)
    _select_first(page, qapp)
    assert len(page._selected_ids()) == 1
    dest = tmp_path / "sel.xlsx"
    monkeypatch.setattr(QFileDialog, "getSaveFileName",
                        staticmethod(lambda *a, **k: (str(dest), "Excel (*.xlsx)")))
    selected_id = page._selected_ids()[0]
    selected_program = ctx.files.get(selected_id)["program_name"]
    other_program = "برنامج ثانٍ" if selected_program == "برنامج أول" else "برنامج أول"
    page.export_selected()
    assert dest.exists()
    from openpyxl import load_workbook
    wb = load_workbook(dest)
    ws = wb.active
    texts = [str(c.value) for row in ws.iter_rows() for c in row if c.value]
    assert any(selected_program in t for t in texts)
    assert not any(other_program in t for t in texts)
    page.close()


def test_selection_counter_and_bulk_print(ctx, tmp_path, qapp, monkeypatch):
    page = _page_with_two(ctx, qapp)
    _select_first(page, qapp)
    page._update_sel_count()
    assert "1" in page.sel_lbl.text()
    dest = tmp_path / "forms.pdf"
    monkeypatch.setattr(QFileDialog, "getSaveFileName",
                        staticmethod(lambda *a, **k: (str(dest), "PDF (*.pdf)")))
    page.print_selected_forms()
    assert dest.exists()
    from pypdf import PdfReader
    assert len(PdfReader(str(dest)).pages) >= 1
    page.close()


def test_backup_archive_self_verified(ctx, tmp_path):
    from sdf_app.services import backup_service
    out = backup_service.create_backup(ctx.conn, dest_dir=tmp_path / "bk")
    assert out.exists()
    assert backup_service.verify_archive(out) is True
    # أرشيف تالف يجب أن يفشل في التحقق (لا نسخ وهمية)
    bad = tmp_path / "bad.zip"
    data = bytearray(out.read_bytes())
    data[len(data) // 2] ^= 0xFF
    bad.write_bytes(bytes(data))
    assert backup_service.verify_archive(bad) is False


def test_friendly_error_messages():
    import sqlite3
    from sdf_app.ui.widgets import friendly_message
    # رسالة مجال عربية تظهر كما هي
    assert friendly_message(ValueError("اسم الملف مكرر")) == "اسم الملف مكرر"
    # خطأ تقني خام يُترجم ولا يتسرب نصه الإنجليزي
    out = friendly_message(sqlite3.OperationalError("database is locked"), "الحفظ")
    assert "database is locked" not in out and "قاعدة البيانات" not in out  # صياغة عامة عربية
    assert out.startswith("تعذر الحفظ")
    out2 = friendly_message(PermissionError(13, "Permission denied"))
    assert "Permission denied" not in out2 and "مفتوحًا" in out2
