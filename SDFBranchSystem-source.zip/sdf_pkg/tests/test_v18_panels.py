# -*- coding: utf-8 -*-
"""v18: لا عناوين QGroupBox في أي صفحة (قصّ الحرف الأول على Windows — مثبت
بصور جهاز حقيقي وبمسبار CI)، والعناوين لوحات QLabel كاملة."""
import tempfile
from pathlib import Path

import pytest
from PySide6.QtWidgets import QGroupBox

from sdf_app.ui.app import create_app


@pytest.fixture(scope="module")
def qapp():
    return create_app([])


@pytest.fixture()
def ctx():
    from sdf_app.ui.context import AppContext
    c = AppContext(db_path=Path(tempfile.mktemp(suffix=".db")))
    c.user = {"id": 1, "username": "admin", "full_name": "مدير",
              "role": "admin"}
    return c


def _titled_groupboxes(widget):
    return [g for g in widget.findChildren(QGroupBox) if g.title()]


def test_no_titled_groupboxes_anywhere(qapp, ctx):
    from sdf_app.ui.contributions_page import ContributionsPage
    from sdf_app.ui.disbursement_page import DisbursementPage
    from sdf_app.ui.entities_page import EntitiesPage
    from sdf_app.ui.files_page import FilesPage
    from sdf_app.ui.reports_page import ReportsPage
    from sdf_app.ui.review_page import ReviewPage
    from sdf_app.ui.settings_page import SettingsPage
    pages = [FilesPage(ctx), ReviewPage(ctx), DisbursementPage(ctx),
             ContributionsPage(ctx), ReportsPage(ctx), EntitiesPage(ctx),
             SettingsPage(ctx)]
    for page in pages:
        bad = _titled_groupboxes(page)
        assert not bad, f"{type(page).__name__}: {[b.title() for b in bad]}"


def test_titled_panels_carry_the_titles(qapp, ctx):
    from sdf_app.ui.review_page import ReviewPage
    from sdf_app.ui.widgets import TitledPanel
    page = ReviewPage(ctx)
    titles = {p.title_lbl.text() for p in page.findChildren(TitledPanel)}
    assert "بيانات الملف" in titles
    assert "قائمة التحقق من الوثائق" in titles
    assert "الملخص المالي" in titles


def test_file_dialog_has_no_titled_groupboxes(qapp, ctx):
    from sdf_app.ui.file_dialog import FileDialog
    dlg = FileDialog(ctx)
    assert not _titled_groupboxes(dlg)
