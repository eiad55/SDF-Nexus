# -*- coding: utf-8 -*-
"""اختبارات متطلبات 2026-10-19 — استمارة المراجعة الفنية (بنود 8.1 و8.2 و8.3).

ملاحظة منهجية: نصوص PDF العربية في هذا المشروع تخرج مُشكّلة الاتجاه (presentation
forms) ومجزّأة على مستوى المقاطع، فلا يصلح استخراج النص من pypdf حكمًا على العبارات.
لذلك تعتمد الاختبارات على: عقد المصدر (العبارات نفسها في قالب الاستمارة)، وسلوك
البناء (صفحة واحدة، أثر فعلي للإعدادات على الملف الناتج)، وثبات الإعدادات في القاعدة.
"""
from pathlib import Path

import pytest

from sdf_app.database.connection import Database
from sdf_app.database.seeds import seed_all
from sdf_app.services.file_service import FileService

REPORTS_DIR = Path(__file__).resolve().parents[1] / "src" / "sdf_app" / "reports"


@pytest.fixture()
def conn(tmp_path):
    db = Database(tmp_path / "t.db")
    c = db.connect()
    seed_all(c)
    yield c
    db.close()


def _rec(conn):
    fs = FileService(conn)
    fid = fs.create({"file_number": 77, "program_name": "برنامج فحص",
                     "received_date": "2026-01-05", "funding_amount": 50000,
                     "approved_trainees": 20, "approved_cost_per_trainee": 2500},
                    user_id=1)
    return fs.get(fid)


def test_deleted_phrase_absent_everywhere():
    """8.1: العبارة المحذوفة لا توجد في أي قالب تقارير (شاشة/طباعة/تصدير)."""
    for py in REPORTS_DIR.rglob("*.py"):
        src = py.read_text(encoding="utf-8")
        assert "دليل إجراءات عمليات مكتب النائب" not in src, py.name
        assert "مدخل إلكترونيًا" not in src, py.name


def test_memo_wording_updated_and_old_gone():
    """8.3: المخاطبة تبدأ بالصياغة المطلوبة، والصياغة القديمة غائبة."""
    src = (REPORTS_DIR / "review_form.py").read_text(encoding="utf-8")
    assert "ترون بعاليه نتائج المراجعة الفنية لملف البرنامج التدريبي الموضح أعلاه" in src
    assert "ترون بعالية" not in src
    assert "نتائج الفنية لملف" not in src


def test_form_builds_single_page_with_and_without_signatories(conn, tmp_path):
    from pypdf import PdfReader
    from sdf_app.reports.review_form import build_review_form
    rec = _rec(conn)
    a = tmp_path / "a.pdf"
    b = tmp_path / "b.pdf"
    build_review_form(rec, [], a, settings={"org_name": "X", "office_name": "Y"})
    build_review_form(rec, [], b, settings={
        "org_name": "X", "office_name": "Y",
        "signatory_tech": "اسم تجريبي أول", "signatory_finance": "اسم تجريبي ثان",
        "signatory_office_manager": "اسم تجريبي ثالث",
        "signatory_deputy": "اسم تجريبي رابع", "signatory_executive": "اسم تجريبي خامس"})
    assert len(PdfReader(str(a)).pages) == 1
    assert len(PdfReader(str(b)).pages) == 1
    # أسماء الموقّعين تصل فعليًا إلى المستند: الناتجان مختلفان
    assert a.read_bytes() != b.read_bytes()


def test_signatory_settings_persist_across_reopen(tmp_path):
    """8.2: الأسماء تُحفظ في جدول settings وتبقى بعد إعادة فتح القاعدة."""
    from sdf_app.ui.context import AppContext
    p = tmp_path / "s.db"
    ctx = AppContext(db_path=p)
    ctx.set_setting("signatory_tech", "موظف تجريبي")
    ctx.set_setting("signatory_executive", "مدير تجريبي")
    ctx.db.close()
    ctx2 = AppContext(db_path=p)
    s = ctx2.settings()
    assert s.get("signatory_tech") == "موظف تجريبي"
    assert s.get("signatory_executive") == "مدير تجريبي"
    ctx2.db.close()
