# -*- coding: utf-8 -*-
"""اختبارات البندين 7–8: سجل الأخطاء، وإلزام تغيير كلمة المرور الافتراضية."""
import logging
import sqlite3

import pytest

from sdf_app.database.connection import Database
from sdf_app.database.seeds import seed_all
from sdf_app.services.auth_service import (authenticate, change_password, create_user,
                                           hash_password, verify_password)


@pytest.fixture()
def conn(tmp_path):
    db = Database(tmp_path / "t.db")
    c = db.connect()
    seed_all(c)
    yield c
    db.close()


def test_fresh_admin_must_change_password(conn):
    row = conn.execute("SELECT must_change_password FROM users WHERE username='admin'").fetchone()
    assert row["must_change_password"] == 1


def test_authenticate_returns_flag(conn):
    user = authenticate(conn, "admin", "admin123")
    assert user is not None and user.get("must_change_password") == 1


def test_v4_migration_flags_only_default_password(tmp_path):
    # قاعدة حقيقية بالإصدار 4 ← نُرجعها يدويًا إلى 3 ثم نعيد الفتح
    db = Database(tmp_path / "t.db")
    c = db.connect()
    seed_all(c)
    admin_id = c.execute("SELECT id FROM users WHERE username='admin'").fetchone()["id"]
    other = create_user(c, "naim", "نعيم", "secret99", "viewer", actor_id=admin_id)
    # مستخدم غيّر كلمته الافتراضية
    change_password(c, other, "another99")
    db.close()

    raw = sqlite3.connect(tmp_path / "t.db")
    raw.execute("ALTER TABLE users DROP COLUMN must_change_password")
    raw.execute("DELETE FROM schema_migrations WHERE version > 3")
    raw.commit()
    raw.close()

    db2 = Database(tmp_path / "t.db")
    c2 = db2.connect()
    try:
        ver = c2.execute("SELECT MAX(version) FROM schema_migrations").fetchone()[0]
        assert ver == 4
        a = c2.execute("SELECT must_change_password FROM users WHERE username='admin'").fetchone()
        o = c2.execute("SELECT must_change_password FROM users WHERE username='naim'").fetchone()
        assert a["must_change_password"] == 1  # ما زالت admin123
        assert o["must_change_password"] == 0  # غُيّرت
        # تكرار الفتح آمن (الترحيل لا يُعاد)
        assert verify_password("admin123", c2.execute(
            "SELECT password_hash FROM users WHERE username='admin'").fetchone()[0])
    finally:
        db2.close()


def test_change_password_clears_flag(conn):
    admin_id = conn.execute("SELECT id FROM users WHERE username='admin'").fetchone()["id"]
    change_password(conn, admin_id, "newpass123")
    row = conn.execute(
        "SELECT must_change_password FROM users WHERE id=?", (admin_id,)).fetchone()
    assert row["must_change_password"] == 0
    assert authenticate(conn, "admin", "newpass123") is not None
    assert authenticate(conn, "admin", "admin123") is None


def test_change_password_rejects_short(conn):
    admin_id = conn.execute("SELECT id FROM users WHERE username='admin'").fetchone()["id"]
    with pytest.raises(ValueError):
        change_password(conn, admin_id, "123")


# -- واجهة ---------------------------------------------------------------------------
@pytest.fixture()
def uictx(tmp_path, qapp, monkeypatch):
    from PySide6.QtWidgets import QMessageBox
    monkeypatch.setattr(QMessageBox, "warning", staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "critical", staticmethod(lambda *a, **k: QMessageBox.Ok))
    from sdf_app.ui.context import AppContext
    c = AppContext(db_path=tmp_path / "ui78.db")
    yield c
    c.db.close()


def test_login_dialog_hides_default_credentials(uictx, qapp):
    from sdf_app.ui.login_dialog import LoginDialog
    dlg = LoginDialog(uictx)
    text = "\n".join(w.text() for w in dlg.findChildren(__import__(
        "PySide6.QtWidgets", fromlist=["QLabel"]).QLabel))
    assert "admin123" not in text
    dlg.close()


def test_forced_dialog_validates(uictx, qapp, monkeypatch):
    from PySide6.QtWidgets import QDialog, QMessageBox
    from sdf_app.ui.login_dialog import ChangePasswordDialog
    calls = []
    monkeypatch.setattr(QMessageBox, "warning",
                        staticmethod(lambda *a, **k: calls.append(True) or QMessageBox.Ok))
    dlg = ChangePasswordDialog(forced=True)
    dlg.new_password.setText("123")
    dlg.confirm_password.setText("123")
    dlg._save()
    assert calls and dlg.result() != QDialog.Accepted
    calls.clear()
    dlg.new_password.setText("newpass123")
    dlg.confirm_password.setText("different")
    dlg._save()
    assert calls and dlg.result() != QDialog.Accepted
    dlg.new_password.setText("newpass123")
    dlg.confirm_password.setText("newpass123")
    dlg._save()
    assert dlg.result() == QDialog.Accepted and dlg.password == "newpass123"
    dlg.close()


def test_logging_setup_writes_file(tmp_path, monkeypatch):
    import sdf_app.config as cfg
    monkeypatch.setattr(cfg, "data_dir", lambda: tmp_path)
    import importlib
    import sdf_app.main as main_mod
    importlib.reload(main_mod)
    main_mod._setup_logging()
    assert (tmp_path / "logs" / "app.log").exists()
    logging.getLogger("sdf_app").info("probe")
    assert "probe" in (tmp_path / "logs" / "app.log").read_text(encoding="utf-8")
