# -*- coding: utf-8 -*-
"""اختبارات متطلبات 2026-10-19 — نموذج الملف: التواريخ (10.1)، Enter (10.2)،
المدرب (10.4)، ترخيص الجهة المنفذة والترحيل v5 (10.5)."""
import pytest

from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QMessageBox

from sdf_app.ui.context import AppContext


@pytest.fixture()
def ctx(tmp_path, qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "warning", staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "information", staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "critical", staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "question",
                        staticmethod(lambda *a, **k: QMessageBox.Yes))
    c = AppContext(db_path=tmp_path / "ui.db")
    c.user = {"id": 1, "username": "admin", "full_name": "مدير النظام", "role": "admin"}
    yield c
    c.db.close()


def _seed_lookups(ctx):
    conn = ctx.conn
    conn.execute("INSERT OR IGNORE INTO branches (name) VALUES ('فرع تجريبي')")
    conn.execute("INSERT OR IGNORE INTO programs (name) VALUES ('برنامج تجريبي')")
    conn.execute("INSERT OR IGNORE INTO entities (name, kind) VALUES ('جهة مستفيدة تجريبية', 'beneficiary')")
    conn.execute("INSERT OR IGNORE INTO entities (name, kind) VALUES ('جهة منفذة تجريبية', 'implementing')")
    conn.commit()
    ids = {}
    ids["branch"] = conn.execute("SELECT id FROM branches WHERE name='فرع تجريبي'").fetchone()[0]
    ids["program"] = conn.execute("SELECT id FROM programs WHERE name='برنامج تجريبي'").fetchone()[0]
    ids["benef"] = conn.execute(
        "SELECT id FROM entities WHERE name='جهة مستفيدة تجريبية'").fetchone()[0]
    ids["impl"] = conn.execute(
        "SELECT id FROM entities WHERE name='جهة منفذة تجريبية'").fetchone()[0]
    return ids


def _pick(dlg, key, item_id):
    w, _ = dlg.widgets[key]
    idx = w.findData(item_id)
    assert idx >= 0, key
    w.setCurrentIndex(idx)


# -- 10.1 ودجت التاريخ ---------------------------------------------------------

def test_date_field_manual_formats(qapp):
    from sdf_app.ui.widgets import DateField
    f = DateField()
    f.edit.setText("25/12/2026")
    assert f.iso_value("تاريخ") == "2026-12-25"
    assert f.edit.text() == "2026-12-25"  # تُطبَّع للصيغة المعيارية
    f.edit.setText("٢٥/١٢/٢٠٢٦")  # أرقام عربية
    assert f.iso_value("تاريخ") == "2026-12-25"
    f.edit.setText("")
    assert f.iso_value("تاريخ") is None


def test_date_field_invalid_raises_clear_error(qapp):
    from sdf_app.ui.widgets import DateField
    f = DateField()
    f.edit.setText("31/02/2026")
    with pytest.raises(ValueError) as ei:
        f.iso_value("تاريخ بداية التنفيذ")
    assert "YYYY-MM-DD" in str(ei.value)
    assert "تاريخ بداية التنفيذ" in str(ei.value)


def test_dialog_invalid_date_blocks_save_and_end_before_start(ctx, qapp):
    from sdf_app.ui.file_dialog import FileDialog
    ids = _seed_lookups(ctx)
    dlg = FileDialog(ctx)
    dlg.show()
    dlg.widgets["file_number"][0].setValue(4242)
    _pick(dlg, "branch_id", ids["branch"])
    _pick(dlg, "program_id", ids["program"])
    _pick(dlg, "beneficiary_id", ids["benef"])
    start = dlg.widgets["exec_start"][0]
    end = dlg.widgets["exec_end"][0]
    start.edit.setText("31/02/2026")  # تاريخ مستحيل
    dlg.save()
    assert dlg.result() == 0
    assert ctx.conn.execute("SELECT COUNT(*) c FROM training_files").fetchone()["c"] == 0
    start.edit.setText("25/02/2026")
    end.edit.setText("20/02/2026")  # النهاية قبل البداية
    dlg.save()
    assert dlg.result() == 0
    assert ctx.conn.execute("SELECT COUNT(*) c FROM training_files").fetchone()["c"] == 0
    end.edit.setText("28/02/2026")
    dlg.save()
    assert dlg.result() != 0
    row = ctx.conn.execute(
        "SELECT exec_start, exec_end FROM training_files WHERE file_number=4242").fetchone()
    assert row["exec_start"] == "2026-02-25" and row["exec_end"] == "2026-02-28"
    dlg.close()


# -- 10.2 Enter -----------------------------------------------------------------

def test_enter_moves_focus_not_save(ctx, qapp):
    from sdf_app.ui.file_dialog import FileDialog
    _seed_lookups(ctx)
    dlg = FileDialog(ctx)
    dlg.show()
    qapp.processEvents()
    field = dlg.widgets["group_name"][0]
    field.setFocus()
    qapp.processEvents()
    assert dlg.focusWidget() is field
    QTest.keyClick(field, Qt.Key_Return)
    qapp.processEvents()
    assert dlg.focusWidget() is not field, "Enter يجب أن ينقل التركيز"
    assert dlg.result() == 0, "Enter يجب ألا يحفظ/يُقبل الحوار"
    assert ctx.conn.execute("SELECT COUNT(*) c FROM training_files").fetchone()["c"] == 0
    dlg.close()


# -- 10.4 بيانات المدرب -----------------------------------------------------------

def test_trainer_selection_fills_details_and_saved_file_keeps_its_own(ctx, qapp):
    from sdf_app.ui.file_dialog import FileDialog
    ids = _seed_lookups(ctx)
    conn = ctx.conn
    conn.execute("INSERT INTO trainers (name, qualification, experience) VALUES (?,?,?)",
                 ("مدرب أول", "ماجستير إدارة", "10 سنوات"))
    conn.execute("INSERT INTO trainers (name, qualification, experience) VALUES (?,?,?)",
                 ("مدرب ثان", "بكالوريوس هندسة", "5 سنوات"))
    conn.commit()
    t1 = conn.execute("SELECT id FROM trainers WHERE name='مدرب أول'").fetchone()[0]
    t2 = conn.execute("SELECT id FROM trainers WHERE name='مدرب ثان'").fetchone()[0]

    dlg = FileDialog(ctx)
    dlg.show()
    _pick(dlg, "trainer_id", t1)
    assert dlg.widgets["trainer_qualification"][0].text() == "ماجستير إدارة"
    assert dlg.widgets["trainer_experience"][0].text() == "10 سنوات"
    _pick(dlg, "trainer_id", t2)
    assert dlg.widgets["trainer_qualification"][0].text() == "بكالوريوس هندسة"
    # قيمة محفوظة في الملف لا تُستبدل عند إعادة الفتح بقيمة المدرب الحالية
    dlg.widgets["trainer_qualification"][0].setText("مؤهل محفوظ في الملف")
    dlg.widgets["file_number"][0].setValue(5151)
    _pick(dlg, "branch_id", ids["branch"])
    _pick(dlg, "program_id", ids["program"])
    _pick(dlg, "beneficiary_id", ids["benef"])
    dlg.save()
    assert dlg.result() != 0
    fid = conn.execute("SELECT id FROM training_files WHERE file_number=5151").fetchone()[0]
    dlg.close()
    dlg2 = FileDialog(ctx, file_id=fid)
    assert dlg2.widgets["trainer_qualification"][0].text() == "مؤهل محفوظ في الملف"
    dlg2.close()


# -- 10.5 ترخيص الجهة المنفذة -------------------------------------------------------

def test_entity_latest_license_shows_and_saves_snapshot(ctx, qapp):
    from sdf_app.services import license_service
    from sdf_app.ui.file_dialog import FileDialog
    ids = _seed_lookups(ctx)
    license_service.add_license(ctx.conn, ids["impl"], "وزارة العمل", "2024-01-01", "2025-12-31")
    license_service.add_license(ctx.conn, ids["impl"], "هيئة التدريب", "2026-01-01", "2027-12-31")
    assert license_service.latest_license(ctx.conn, ids["impl"])["license_issuer"] == "هيئة التدريب"

    dlg = FileDialog(ctx)
    dlg.show()
    _pick(dlg, "implementing_id", ids["impl"])
    assert "هيئة التدريب" in dlg.license_info_lbl.text()
    assert "2027-12-31" in dlg.license_info_lbl.text()
    dlg.widgets["file_number"][0].setValue(6161)
    _pick(dlg, "branch_id", ids["branch"])
    _pick(dlg, "program_id", ids["program"])
    _pick(dlg, "beneficiary_id", ids["benef"])
    dlg.save()
    assert dlg.result() != 0
    row = ctx.conn.execute(
        "SELECT license_issuer, license_start, license_end FROM training_files"
        " WHERE file_number=6161").fetchone()
    assert row["license_issuer"] == "هيئة التدريب"
    assert row["license_start"] == "2026-01-01" and row["license_end"] == "2027-12-31"
    dlg.close()


def test_migration_v5_backfills_licenses_and_trainer_active(tmp_path):
    from sdf_app.database.connection import Database
    p = tmp_path / "old.db"
    db = Database(p)
    conn = db.connect()
    # محاكاة قاعدة ما قبل v5: إسقاط آثار v5 وإدخال بيانات ترخيص قديمة على ملف
    conn.execute("DROP TABLE IF EXISTS entity_licenses")
    conn.execute("ALTER TABLE trainers DROP COLUMN active")
    conn.execute("DELETE FROM schema_migrations WHERE version=5")
    conn.execute("INSERT INTO entities (name, kind) VALUES ('منفذ قديم', 'implementing')")
    eid = conn.execute("SELECT id FROM entities WHERE name='منفذ قديم'").fetchone()[0]
    conn.execute(
        "INSERT INTO training_files (file_number, program_name, implementing_id,"
        " license_issuer, license_start, license_end) VALUES (1, 'ب', ?, 'جهة قديمة',"
        " '2023-01-01', '2024-01-01')", (eid,))
    conn.commit()
    db.close()
    db2 = Database(p)
    conn2 = db2.connect()
    assert conn2.execute("SELECT MAX(version) v FROM schema_migrations").fetchone()["v"] == 5
    rows = conn2.execute("SELECT * FROM entity_licenses WHERE entity_id=?", (eid,)).fetchall()
    assert len(rows) == 1 and rows[0]["license_issuer"] == "جهة قديمة"
    cols = {c[1] for c in conn2.execute("PRAGMA table_info(trainers)")}
    assert "active" in cols
    # التاريخ محفوظ: قيم الملف الأصلية لم تتغير
    r = conn2.execute("SELECT license_issuer FROM training_files WHERE file_number=1").fetchone()
    assert r["license_issuer"] == "جهة قديمة"
    db2.close()
