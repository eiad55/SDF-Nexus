# -*- coding: utf-8 -*-
"""عقود ساكنة بين المثبّت (setup.iss) واختبار install-smoke في الـ Workflow.

هذه الاختبارات لا تُغني عن تشغيل Windows فعلي، لكنها تمنع التراجع الصامت عن
الاتفاق الذي يجعل اختصار قائمة ابدأ قابلًا للعثور عليه والتحقق من هدفه، وتمنع
إضعاف شروط القبول أو رفع صلاحيات التثبيت أو حذف بيانات المستخدم عند الإزالة.
"""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SETUP_ISS = ROOT / "build" / "setup.iss"


def _setup_text() -> str:
    return SETUP_ISS.read_text(encoding="utf-8-sig")


def _section(text: str, header: str) -> str:
    """محتوى قسم Inno Setup (سطر ترويسة وحده) حتى الترويسة التالية أو النهاية."""
    lines = text.splitlines()
    try:
        start = next(i for i, ln in enumerate(lines) if ln.strip() == header)
    except StopIteration:
        return ""
    body = []
    for ln in lines[start + 1:]:
        if ln.strip().startswith("[") and ln.strip().endswith("]"):
            break
        body.append(ln)
    return "\n".join(body)


def _code_lines(section: str) -> list[str]:
    """أسطر القسم الفعلية دون التعليقات (تبدأ بـ ;) والأسطر الفارغة."""
    return [ln.strip() for ln in section.splitlines()
            if ln.strip() and not ln.strip().startswith(";")]


def _workflow_text() -> str:
    # الـ Workflow يعيش في جذر المستودع، وحزمة المصدر تُفك بجانبه في CI.
    candidates = [
        ROOT.parent / ".github" / "workflows" / "build-windows.yml",
        ROOT.parents[1] / ".github" / "workflows" / "build-windows.yml",
    ]
    for cand in candidates:
        if cand.is_file():
            return cand.read_text(encoding="utf-8")
    return ""


def test_start_menu_icon_uses_deterministic_autoprograms_path():
    icons = "\n".join(_code_lines(_section(_setup_text(), "[Icons]")))
    assert "{group}" not in icons, "اختصار {group} يعتمد على صفحة/حالة مجلد قائمة ابدأ"
    start_menu_lines = [ln for ln in icons.splitlines()
                        if "{autoprograms}" in ln and "Filename:" in ln]
    assert start_menu_lines, "لا يوجد اختصار قائمة ابدأ عبر {autoprograms}"
    assert "{#MyAppExeName}" in start_menu_lines[0]


def test_installer_privileges_stay_lowest():
    text = _setup_text()
    assert re.search(r"(?m)^PrivilegesRequired=lowest\s*$", text), \
        "لا ترفع صلاحيات التثبيت لإصلاح فشل الاختصار"


def test_uninstall_does_not_delete_user_data_dir():
    entries = _code_lines(_section(_setup_text(), "[UninstallDelete]"))
    assert entries == [], "يجب ألا يحذف إلغاء التثبيت أي ملفات (البيانات في LOCALAPPDATA)"


def test_workflow_shortcut_check_contract():
    wf = _workflow_text()
    if not wf:
        import pytest
        pytest.skip("build-windows.yml غير موجود بجانب حزمة المصدر في هذه البيئة")
    # يبحث في مساري المستخدم والنظام معًا
    assert 'Join-Path $env:APPDATA "Microsoft/Windows/Start Menu/Programs"' in wf
    assert 'Join-Path $env:ProgramData "Microsoft/Windows/Start Menu/Programs"' in wf
    # يحلّ هدف الاختصار عبر محلّل Shell Link المشترك ويقارنه بالملف التنفيذي
    assert "lnk_shortcut.ps1" in wf and "Resolve-LnkTarget" in wf
    assert "Test-LnkTargetEquals" in wf and "shortcut_match=" in wf
    assert "Format-LnkResolution" in wf
    assert "لم يُعثر على اختصار قائمة ابدأ" in wf
    # سجل Inno Setup وتشخيص الاختصارات: بدونهما لا يمكن إثبات السبب الجذري عند الفشل
    assert "/LOG=" in wf and "installer-inno.log" in wf
    assert "shortcut_diag_found" in wf


def test_workflow_shortcut_resolution_is_not_wsh_only():
    """حارسا تراجع لسببين مثبتين:

    1. تشغيل 39086711009: أنشأ Inno Setup الاختصار بنجاح وعدّده الاختبار،
       لكن WScript.Shell أعاد TargetPath فارغًا — اعتماد WSH وحده مرفوض.
    2. تدقيق v9: قبول الاختصار لمجرد وجود مسار الملف التنفيذي كنص خام داخل
       بايتات .lnk إيجابية كاذبة مثبتة بالتنفيذ (تركيبة trap_other_target
       هدفها notepad.exe وتحمل المسار في IconLocation) — البحث النصي
       الخام ممنوع كطريقة قبول في الـ Workflow وفي المحلّل معًا.

    الحلّ المعتمد: ملف مشترك tools/lnk_shortcut.ps1 يحلّ الهدف فعليًا
    (WSH ثم Shell.Application GetLink ثم تحليل بنيوي لحقل LinkInfo في
    تنسيق [MS-SHLLINK])، ويُستخدم في فحص التثبيت وفحص بقايا الإزالة.
    """
    wf = _workflow_text()
    if not wf:
        import pytest
        pytest.skip("build-windows.yml غير موجود بجانب حزمة المصدر في هذه البيئة")
    parser_path = ROOT / "tools" / "lnk_shortcut.ps1"
    assert parser_path.is_file(), "ملف محلّل الاختصارات المشترك مفقود"
    parser = parser_path.read_text(encoding="utf-8")
    # المحلّل البنيوي موجود ويستخرج حقل الهدف الفعلي
    assert "function Get-LnkParsed" in parser
    assert "LocalBasePath" in parser and "function Resolve-LnkTarget" in parser
    assert "Shell.Application" in parser and "GetLink()" in parser
    assert "shortcut_resolution" in parser  # سطر التشخيص الموحّد لكل محاولات الحلّ
    # ممنوع القبول بالنص الخام في أيٍّ من الملفين
    for text in (wf, parser):
        assert "Test-ShortcutBinaryTarget" not in text
        assert ".Contains($ExpectedPath)" not in text
        assert "binary_match" not in text
    # الاستخدام في الفحصين + خطوة اختبار التركيبات على Windows
    assert wf.count("Resolve-LnkTarget") >= 2
    assert "$expectedStartMenuLnk" in wf  # كشف البقايا بهوية مسار المثبّت نفسه
    assert "test_lnk_parser.ps1" in wf


def test_workflow_lnk_tools_reach_install_smoke_via_artifact():
    """حارس تراجع لعيب v10 المُكتشف من تشغيل 39093452332: وظيفة
    install-smoke لا تملك checkout ولا تفكّ أرشيف المصدر، فأي مسار يفترض
    شجرة مصدر محلية (مثل sdf-source) غير موجود على الـ runner ويفشل فورًا.
    يجب أن تصل أدوات فحص الاختصارات عبر artifact ترفعه وظيفة build
    (التي تفكّ المصدر في مساحة عملها) وتنزّله install-smoke، وأن تشير كل
    المسارات إلى مجلد التنزيل ذلك."""
    wf = _workflow_text()
    if not wf:
        import pytest
        pytest.skip("build-windows.yml غير موجود بجانب حزمة المصدر في هذه البيئة")
    assert "sdf-source" not in wf, "مسار مصدر وهمي لا يوجد على runner install-smoke"
    assert "SDFBranchSystem-LnkTools" in wf          # artifact الأدوات
    assert "path: lnk-tools" in wf                     # ما ترفعه build (صيغة مجلد كحزمة Portable)
    assert "sdf-lnk-tools/tools/lnk_shortcut.ps1" in wf
    assert "sdf-lnk-tools/tools/test_lnk_parser.ps1" in wf
    assert "sdf-lnk-tools/tests/fixtures/lnk" in wf
