# -*- coding: utf-8 -*-
"""اختبارات متطلبات 2026-10-19 — حذف الملفات لمدير النظام فقط (10.3)."""
import pytest

from sdf_app import config
from sdf_app.database.connection import Database
from sdf_app.database.seeds import seed_all
from sdf_app.services.auth_service import create_user
from sdf_app.services.file_service import FileService


@pytest.fixture()
def env(tmp_path, monkeypatch):
    db = Database(tmp_path / "t.db")
    conn = db.connect()
    seed_all(conn)
    monkeypatch.setattr(config, "attachments_dir", lambda: tmp_path / "att")
    yield conn, tmp_path
    db.close()


def _file(fs, num, user_id=1):
    return fs.create({"file_number": num, "program_name": f"برنامج {num}",
                      "received_date": "2026-01-05"}, user_id=user_id)


def _relate(conn, fid, tmp_path):
    conn.execute("INSERT INTO review_items (file_id, document_type_id, result)"
                 " VALUES (?, 1, 'مطابق')", (fid,))
    conn.execute("INSERT INTO trainees_nomination (file_id, seq, full_name)"
                 " VALUES (?, 1, 'متدرب')", (fid,))
    conn.execute("INSERT INTO file_history (file_id, from_status_id, to_status_id)"
                 " VALUES (?, NULL, 1)", (fid,))
    folder = config.attachments_dir() / str(fid)
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "doc.pdf").write_bytes(b"x")
    conn.execute("INSERT INTO attachments (file_id, original_name, stored_name)"
                 " VALUES (?, 'doc.pdf', 'doc.pdf')", (fid,))
    conn.commit()


def test_non_admin_cannot_delete_even_calling_service(env):
    conn, tmp = env
    fs = FileService(conn)
    clerk = create_user(conn, "clerk1", "موظف إدخال", "Clerk@123", "data_entry")
    fid = _file(fs, 101)
    with pytest.raises(PermissionError):
        fs.delete_files([fid], user_id=clerk)
    assert conn.execute("SELECT COUNT(*) c FROM training_files").fetchone()["c"] == 1
    # ومجهول/بدون مستخدم مرفوض أيضًا
    with pytest.raises(PermissionError):
        fs.delete_files([fid], user_id=None)


def test_admin_deletes_multiple_with_relations_and_audit(env):
    conn, tmp = env
    fs = FileService(conn)
    f1, f2, f3 = _file(fs, 201), _file(fs, 202), _file(fs, 203)
    _relate(conn, f1, tmp)
    _relate(conn, f2, tmp)
    # ملف ثالث جعل الأول مادته العلمية: يجب فك الارتباط لا منع الحذف
    conn.execute("UPDATE training_files SET material_file_id=? WHERE id=?", (f1, f3))
    conn.commit()
    res = fs.delete_files([f1, f2], user_id=1)
    assert res["count"] == 2
    assert conn.execute("SELECT COUNT(*) c FROM training_files").fetchone()["c"] == 1
    for t in ("review_items", "trainees_nomination", "file_history", "attachments"):
        assert conn.execute(f"SELECT COUNT(*) c FROM {t}").fetchone()["c"] == 0, t
    # الملف الفعلي للمرفق أُزيل
    assert not (config.attachments_dir() / str(f1) / "doc.pdf").exists()
    # فكّ ارتباط المادة العلمية
    assert conn.execute("SELECT material_file_id FROM training_files WHERE id=?",
                        (f3,)).fetchone()[0] is None
    # التدقيق محفوظ بلقطة تعريفية رغم حذف الملف وسجل حركته
    audits = conn.execute(
        "SELECT details FROM audit_log WHERE action='file.delete'").fetchall()
    assert len(audits) == 2
    assert any("201" in a["details"] for a in audits)


def test_delete_missing_file_rejected_without_side_effects(env):
    conn, tmp = env
    fs = FileService(conn)
    fid = _file(fs, 301)
    with pytest.raises(ValueError):
        fs.delete_files([fid, 999999], user_id=1)
    assert conn.execute("SELECT COUNT(*) c FROM training_files").fetchone()["c"] == 1


def test_files_page_delete_button_admin_only(tmp_path, qapp, monkeypatch):
    from PySide6.QtWidgets import QMessageBox
    from sdf_app.ui.context import AppContext
    from sdf_app.ui.files_page import FilesPage
    monkeypatch.setattr(QMessageBox, "question",
                        staticmethod(lambda *a, **k: QMessageBox.Yes))
    c = AppContext(db_path=tmp_path / "ui.db")
    c.user = {"id": 2, "username": "clerk", "full_name": "موظف", "role": "data_entry"}
    page = FilesPage(c)
    assert page.btn_delete.isHidden() or not page.btn_delete.isVisible()
    page.close()
    c.user = {"id": 1, "username": "admin", "full_name": "مدير", "role": "admin"}
    page2 = FilesPage(c)
    page2.show()
    qapp.processEvents()
    assert page2.btn_delete.isVisible()
    page2.close()
    c.db.close()
