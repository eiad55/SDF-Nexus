# -*- coding: utf-8 -*-
"""اختبار منطق حلقة بحث الاختصار في خطوة التثبيت (تنفيذ فعلي بـ pwsh).

السبب الجذري لتشغيل 39095127444: وجدت الحلقة الاختصار المطابق وسجّلت
shortcut_match=، لكن سطر `$matchingShortcut = $true` كان مفقودًا من كتلة
المطابقة (سقط في إعادة هيكلة)، فبقيت القيمة False ودخل السكربت كتلة
التشخيص ورمى «لم يُعثر على اختصار» رغم نجاح المطابقة.

هذا الاختبار يستخرج مقطع البحث نفسه من الـ Workflow كما هو، ويشغّله
ببدائل (stubs) للمحلّل في حالتين:
- اختصار مطابق موجود ⇒ لا رمي، والعلم True، ولا تشخيص.
- لا اختصار مطابق ⇒ رمي مع تشخيص.
يُتخطى عند غياب pwsh محليًا، ويعمل على Windows CI حيث pwsh متاحة.
"""
import re
import shutil
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]

HARNESS = r"""
param([string]$SegmentPath, [string]$Case)
$ErrorActionPreference = 'Stop'
$tmp = Join-Path ([System.IO.Path]::GetTempPath()) ("lnkseg_" + [guid]::NewGuid().ToString('N'))
$appDataPrograms = Join-Path $tmp 'Roaming/Microsoft/Windows/Start Menu/Programs'
$progDataPrograms = Join-Path $tmp 'PD/Microsoft/Windows/Start Menu/Programs'
New-Item -ItemType Directory -Force -Path $appDataPrograms, $progDataPrograms | Out-Null
if ($Case -eq 'match') { New-Item -ItemType File -Path (Join-Path $appDataPrograms 'app.lnk') | Out-Null }
New-Item -ItemType File -Path (Join-Path $progDataPrograms 'other.lnk') | Out-Null
$env:APPDATA = Join-Path $tmp 'Roaming'; $env:ProgramData = Join-Path $tmp 'PD'
$exe = 'D:\install\SDFBranchSystem.exe'
$log = Join-Path $tmp 'smoke.log'; New-Item -ItemType File -Path $log | Out-Null
$programRoots = @($appDataPrograms, $progDataPrograms)
function Resolve-LnkTarget { param([string]$LnkPath)
  if ($LnkPath -like '*app.lnk') { return [pscustomobject]@{ Target = 'D:\install\SDFBranchSystem.exe'; Method = 'shell'; Attempts = [ordered]@{wsh='<empty>';shell='D:\install\SDFBranchSystem.exe';linkinfo='D:\install\SDFBranchSystem.exe'}; Parsed = $null } }
  return [pscustomobject]@{ Target = $null; Method = 'none'; Attempts = [ordered]@{wsh='<empty>';shell='<empty>';linkinfo='<none>'}; Parsed = $null }
}
function Test-LnkTargetEquals { param([string]$Target, [string]$ExpectedPath) if (-not $Target) { return $false }; return ($Target -ieq $ExpectedPath) }
function Format-LnkResolution { param([string]$LnkPath, $Resolution) return "shortcut_resolution path=$LnkPath method=$($Resolution.Method) target=$($Resolution.Target)" }
$threw = $false
try { . $SegmentPath } catch { $threw = $true }
$logText = Get-Content -LiteralPath $log -Raw
Write-Output "case=$Case threw=$threw matchingShortcut=$matchingShortcut logHasMatch=$($logText -match 'shortcut_match=') logHasDiag=$($logText -match 'shortcut_diag_found')"
"""


def _workflow_text() -> str:
    candidates = [
        ROOT.parent / ".github" / "workflows" / "build-windows.yml",
        ROOT.parents[1] / ".github" / "workflows" / "build-windows.yml",
    ]
    for cand in candidates:
        if cand.is_file():
            return cand.read_text(encoding="utf-8")
    return ""


def _run_block_with(wf_text: str, needle: str) -> str:
    """يستخرج كتلة run: | التي تحتوي needle من YAML بالمسافات البادئة فقط.

    دون اعتماد على PyYAML (غير موجودة في بيئة بناء المشروع)."""
    lines = wf_text.splitlines()
    for i, ln in enumerate(lines):
        m = re.match(r"^(\s*)run:\s*\|\s*$", ln)
        if not m:
            continue
        key_indent = len(m.group(1))
        block = []
        for ln2 in lines[i + 1:]:
            if ln2.strip() and len(ln2) - len(ln2.lstrip()) <= key_indent:
                break
            block.append(ln2)
        text = "\n".join(block)
        if needle in text:
            indents = [len(b) - len(b.lstrip()) for b in block if b.strip()]
            cut = min(indents) if indents else 0
            return "\n".join(b[cut:] if b.strip() else "" for b in block)
    raise AssertionError(f"لم يُعثر على كتلة run تحتوي {needle}")


def _extract_segment(wf_text: str) -> str:
    """مقطع البحث من تعريف العلم حتى نهاية كتلة التشخيص/الرمي."""
    run = _run_block_with(wf_text, "shortcut_match")
    lines = run.splitlines()
    start = next(i for i, ln in enumerate(lines)
                 if ln.strip() == "$matchingShortcut = $false")
    end = next(i for i, ln in enumerate(lines)
               if "throw" in ln and "لم يُعثر على اختصار قائمة ابدأ" in ln)
    return "\n".join(lines[start:end + 2])


def _find_pwsh():
    return shutil.which("pwsh") or (
        "/tmp/pwsh/pwsh" if Path("/tmp/pwsh/pwsh").is_file() else None)


def test_match_block_sets_matching_shortcut_flag():
    """حارس ساكن دائم: سطر تعيين العلم داخل كتلة المطابقة قبل التسجيل."""
    wf = _workflow_text()
    if not wf:
        pytest.skip("build-windows.yml غير موجود بجانب حزمة المصدر في هذه البيئة")
    pattern = re.compile(
        r"if \(Test-LnkTargetEquals \$shortcutResolution\.Target \$exe\) \{\s*\n"
        r"\s*\$matchingShortcut = \$true")
    assert pattern.search(wf), \
        "كتلة المطابقة لا تعيّن $matchingShortcut = $true (عيب تشغيل 39095127444)"


@pytest.mark.parametrize("case,expected", [
    ("match", "threw=False matchingShortcut=True logHasMatch=True logHasDiag=False"),
    ("nomatch", "threw=True matchingShortcut=False logHasMatch=False logHasDiag=True"),
])
def test_search_segment_logic_under_pwsh(tmp_path, case, expected):
    pwsh = _find_pwsh()
    if not pwsh:
        pytest.skip("pwsh غير متاحة في هذه البيئة")
    wf = _workflow_text()
    if not wf:
        pytest.skip("build-windows.yml غير موجود بجانب حزمة المصدر في هذه البيئة")
    segment = tmp_path / "segment.ps1"
    segment.write_text(_extract_segment(wf), encoding="utf-8")
    harness = tmp_path / "harness.ps1"
    harness.write_text(HARNESS, encoding="utf-8")
    proc = subprocess.run(
        [pwsh, "-NoProfile", "-File", str(harness),
         "-SegmentPath", str(segment), "-Case", case],
        capture_output=True, text=True, timeout=120)
    assert proc.returncode == 0, proc.stdout + proc.stderr
    result_line = next(ln for ln in proc.stdout.splitlines()
                       if ln.startswith("case="))
    for token in expected.split():
        assert token in result_line, f"{case}: {token} not in {result_line}"
