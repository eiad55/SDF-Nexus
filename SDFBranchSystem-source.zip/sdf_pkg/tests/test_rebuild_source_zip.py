"""Regression tests for safe, reproducible source archive creation."""
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

SCRIPT = Path(__file__).resolve().parents[1] / "tools" / "rebuild_source_zip.py"


def _make_repository(root: Path) -> Path:
    project = root / "sdf_pkg"
    (project / "src" / "sdf_app").mkdir(parents=True)
    (project / "src" / "sdf_app" / "main.py").write_text("# app entry\n", encoding="utf-8")
    (project / "src" / "sdf_app" / "بيانات عربية.txt").write_text("اختبار UTF-8\n", encoding="utf-8")
    (project / "build").mkdir(parents=True)
    (project / "build" / "SDFBranchSystem.spec").write_text("# spec\n", encoding="utf-8")
    (project / "build" / "setup.iss").write_text("; installer\n", encoding="utf-8")
    (project / "tests").mkdir()
    (project / "tests" / "test_example.py").write_text("def test_ok(): assert True\n", encoding="utf-8")
    return project


def _run(repo: Path, output: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, str(SCRIPT), str(repo), str(output)],
        text=True, capture_output=True, check=False,
    )


def test_rebuild_excludes_generated_outputs_and_keeps_unicode(tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    project = _make_repository(repo)

    # Simulate generated output from PyInstaller and CI.
    (project / "dist" / "SDFBranchSystem").mkdir(parents=True)
    (project / "dist" / "SDFBranchSystem" / "SDFBranchSystem.exe").write_bytes(b"binary")
    (project / "build" / "SDFBranchSystem").mkdir(parents=True)
    (project / "build" / "SDFBranchSystem" / "Analysis-00.toc").write_text("generated", encoding="utf-8")
    (project / "build" / "Analysis-00.toc").write_text("generated", encoding="utf-8")
    (project / "build" / "warn-SDFBranchSystem.txt").write_text("warning", encoding="utf-8")
    (project / "build" / "xref-SDFBranchSystem.html").write_text("xref", encoding="utf-8")
    (project / "ci-logs").mkdir()
    (project / "ci-logs" / "pytest.log").write_text("diagnostics", encoding="utf-8")
    (project / "src" / "sdf_app" / "__pycache__").mkdir()
    (project / "src" / "sdf_app" / "__pycache__" / "main.cpython-312.pyc").write_bytes(b"pyc")
    (project / ".venv" / "Lib").mkdir(parents=True)
    (project / ".venv" / "Lib" / "secret-test-file.txt").write_text("not source", encoding="utf-8")

    output = tmp_path / "SDFBranchSystem-source.zip"
    result = _run(repo, output)
    assert result.returncode == 0, result.stdout + "\n" + result.stderr
    assert output.is_file()

    with zipfile.ZipFile(output) as archive:
        names = set(archive.namelist())
        assert archive.testzip() is None
        assert "sdf_pkg/src/sdf_app/main.py" in names
        assert "sdf_pkg/src/sdf_app/بيانات عربية.txt" in names
        assert "sdf_pkg/build/SDFBranchSystem.spec" in names
        assert "sdf_pkg/build/setup.iss" in names
        assert not any(name.startswith("sdf_pkg/dist/") for name in names)
        assert not any(name.startswith("sdf_pkg/ci-logs/") for name in names)
        assert not any(name.startswith("sdf_pkg/build/SDFBranchSystem/") for name in names)
        assert not any(name.endswith((".toc", ".pyc")) or "/warn-" in name or "/xref-" in name for name in names)
        assert not any("__pycache__/" in name or ".venv/" in name for name in names)


def test_existing_output_zip_is_replaced_atomically(tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    _make_repository(repo)
    output = tmp_path / "SDFBranchSystem-source.zip"
    output.write_bytes(b"stale output")

    result = _run(repo, output)
    assert result.returncode == 0, result.stdout + "\n" + result.stderr
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        assert "sdf_pkg/src/sdf_app/main.py" in archive.namelist()


def test_output_inside_source_tree_is_rejected(tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    _make_repository(repo)
    output = repo / "sdf_pkg" / "nested.zip"

    result = _run(repo, output)
    assert result.returncode != 0
    assert "outside the source directory" in result.stderr
    assert not output.exists()


def test_symlink_is_not_followed_or_archived(tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    project = _make_repository(repo)
    outside = tmp_path / "outside-secret.txt"
    outside.write_text("outside content", encoding="utf-8")
    link = project / "src" / "sdf_app" / "linked-secret.txt"
    try:
        link.symlink_to(outside)
    except (OSError, NotImplementedError) as exc:
        pytest.skip(f"symlink creation is not supported in this environment: {exc}")

    output = tmp_path / "SDFBranchSystem-source.zip"
    result = _run(repo, output)
    assert result.returncode == 0, result.stdout + "\n" + result.stderr
    with zipfile.ZipFile(output) as archive:
        assert "sdf_pkg/src/sdf_app/linked-secret.txt" not in archive.namelist()
        assert all(b"outside content" not in archive.read(name) for name in archive.namelist())
