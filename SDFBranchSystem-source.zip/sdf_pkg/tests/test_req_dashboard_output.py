# -*- coding: utf-8 -*-
"""اختبارات متطلبات 2026-10-19 — إخراج لوحة التحكم (بند 6):
التصدير يرسم اللوحة الفعلية (بطاقات/رسوم) مقسمة على صفحات A4، لا جداول بديلة."""
from pathlib import Path

import pytest

from PySide6.QtWidgets import QFileDialog, QMessageBox

from sdf_app.ui.context import AppContext

SRC = Path(__file__).resolve().parents[1] / "src" / "sdf_app" / "ui" / "dashboard_page.py"


@pytest.fixture()
def ctx(tmp_path, qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "warning", staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "information", staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "critical", staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "question",
                        staticmethod(lambda *a, **k: QMessageBox.Yes))
    c = AppContext(db_path=tmp_path / "ui.db")
    c.user = {"id": 1, "username": "admin", "full_name": "مدير النظام", "role": "admin"}
    for i in range(8):
        c.conn.execute("INSERT OR IGNORE INTO branches (name) VALUES (?)", (f"فرع {i}",))
    c.conn.commit()
    from sdf_app.services.file_service import FileService
    fs = FileService(c.conn)
    bids = [r[0] for r in c.conn.execute("SELECT id FROM branches ORDER BY id LIMIT 8")]
    for n, bid in enumerate(bids, 1):
        fs.create({"file_number": 100 + n, "program_name": f"برنامج {n}",
                   "received_date": "2026-01-05", "branch_id": bid,
                   "exec_start": "2026-02-01", "approved_trainees": n,
                   "funding_amount": 1000 * n, "claimed_amount": 1200 * n}, user_id=1)
    yield c
    c.db.close()


def test_export_path_never_uses_table_builder():
    src = SRC.read_text(encoding="utf-8")
    assert "build_dashboard_pdf" not in src
    assert "_paint_dashboard" in src  # مُصيِّر واحد للطباعة والتصدير


def test_export_pdf_is_faithful_paginated_render(ctx, qapp, tmp_path, monkeypatch):
    from pypdf import PdfReader
    from sdf_app.ui.dashboard_page import DashboardPage
    page = DashboardPage(ctx, lambda *a: None)
    page.resize(760, 900)
    page.show()
    qapp.processEvents()
    page.refresh()
    qapp.processEvents()
    out = tmp_path / "dash.pdf"
    monkeypatch.setattr(QFileDialog, "getSaveFileName",
                        staticmethod(lambda *a, **k: (str(out), "PDF (*.pdf)")))
    page._export_pdf()
    assert out.exists() and out.stat().st_size > 3000
    reader = PdfReader(str(out))
    assert len(reader.pages) >= 1
    # صفحة A4
    box = reader.pages[0].mediabox
    assert abs(float(box.width) - 595.3) < 2 and abs(float(box.height) - 841.9) < 2
    # المحتوى هو اللوحة نفسها: عناوين البطاقات مرسومة كنص فعلي في الملف
    text = "".join((p.extract_text() or "") for p in reader.pages)
    import re
    assert re.sub(r"\s+", "", text)  # يوجد محتوى مرسوم
    page.close()


def test_paint_dashboard_paginates_instead_of_squashing(ctx, qapp, tmp_path):
    """المُصيِّر يقسّم المحتوى على صفحات (لا يضغطه في صفحة واحدة مشوّهة):
    بصفحة عريضة قصيرة نسبيًا يجب أن يتوزع محتوى اللوحة على صفحتين."""
    from pypdf import PdfReader
    from PySide6.QtGui import QPageLayout, QPageSize, QPainter, QPdfWriter
    from sdf_app.ui.dashboard_page import DashboardPage
    page = DashboardPage(ctx, lambda *a: None)
    page.resize(760, 900)
    page.show()
    qapp.processEvents()
    page.refresh()
    qapp.processEvents()
    out = tmp_path / "dash_land.pdf"
    writer = QPdfWriter(str(out))
    writer.setPageSize(QPageSize(QPageSize.A4))
    writer.setPageOrientation(QPageLayout.Landscape)
    writer.setResolution(150)
    painter = QPainter(writer)
    try:
        rect = writer.pageLayout().paintRectPixels(writer.resolution())
        page._paint_dashboard(painter, rect, writer.newPage)
    finally:
        painter.end()
    assert len(PdfReader(str(out)).pages) >= 2
    page.close()
