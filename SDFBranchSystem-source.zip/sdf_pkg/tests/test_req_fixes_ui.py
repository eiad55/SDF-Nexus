# -*- coding: utf-8 -*-
"""اختبارات متطلبات 2026-10-19 — الواجهة: مواضع التسميات والعناوين (بنود 5 و7)."""
import pytest

from PySide6.QtWidgets import QApplication, QLabel, QLineEdit, QMessageBox, QWidget

from sdf_app.ui.context import AppContext


@pytest.fixture()
def ctx(tmp_path, qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "warning", staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "information", staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "critical", staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "question",
                        staticmethod(lambda *a, **k: QMessageBox.Yes))
    c = AppContext(db_path=tmp_path / "ui.db")
    c.user = {"id": 1, "username": "admin", "full_name": "مدير النظام", "role": "admin"}
    yield c
    c.db.close()


def _x_in(widget, ancestor):
    return widget.mapTo(ancestor, widget.rect().topLeft()).x()


def test_labeled_row_label_is_right_of_field(qapp):
    from sdf_app.ui.widgets import labeled_row
    host = QWidget()
    field = QLineEdit()
    lay = labeled_row("اسم الحقل:", field)
    from PySide6.QtWidgets import QVBoxLayout
    v = QVBoxLayout(host)
    v.addLayout(lay)
    host.resize(600, 60)
    host.show()
    qapp.processEvents()
    lbl = host.findChild(QLabel)
    assert lbl is not None
    assert _x_in(lbl, host) > _x_in(field, host), "التسمية يجب أن تكون يمين الحقل"
    host.close()


def test_file_dialog_labels_right_of_fields(ctx, qapp):
    from sdf_app.ui.file_dialog import FileDialog
    dlg = FileDialog(ctx)
    dlg.resize(1100, 800)
    dlg.show()
    qapp.processEvents()
    from PySide6.QtWidgets import QTabWidget
    tabs = dlg.findChild(QTabWidget)
    labels = {l.text(): l for l in dlg.findChildren(QLabel)}
    for key, text in (("exec_start", "تاريخ بداية التنفيذ"),
                      ("contract_number", "رقم العقد")):
        w, _kind = dlg.widgets[key]
        target = None
        for t, lab in labels.items():
            if text and t.startswith(text):
                target = lab
                break
        assert target is not None, text
        # فعّل التبويب الذي يحمل الحقل قبل قياس الهندسة
        for i in range(tabs.count()):
            tabs.setCurrentIndex(i)
            qapp.processEvents()
            if w.isVisible() and target.isVisible():
                break
        assert _x_in(target, dlg) > _x_in(w, dlg), f"تسمية {text} ليست يمين حقلها"
    dlg.close()


def test_files_and_reports_grid_labels_right(ctx, qapp):
    from sdf_app.ui.files_page import FilesPage
    from sdf_app.ui.reports_page import ReportsPage
    fp = FilesPage(ctx)
    fp.resize(1200, 700)
    fp.show()
    qapp.processEvents()
    lbl = next(l for l in fp.findChildren(QLabel) if l.text() == "بحث:")
    assert _x_in(lbl, fp) > _x_in(fp.q, fp), "تسمية بحث يجب أن تكون يمين حقل البحث"
    fp.close()
    rp = ReportsPage(ctx)
    rp.resize(1200, 700)
    rp.show()
    qapp.processEvents()
    lbl2 = next(l for l in rp.findChildren(QLabel) if l.text().startswith("الجهة المستفيدة"))
    assert _x_in(lbl2, rp) > _x_in(rp.rep_benef, rp), "تسمية الجهة يجب أن تكون يمين قائمتها"
    rp.close()


def test_stat_card_titles_wrap_not_clip(qapp):
    from sdf_app.ui.widgets import StatCard
    card = StatCard("k", "إجمالي الفروقات (مطالب − تمويل)")
    assert card.title_lbl.wordWrap() is True
    assert card.sub_lbl.wordWrap() is True
    card.set_value("1,000", "سطر فرعي طويل نسبيًا للتجربة والتحقق")
    card.resize(220, 120)
    card.show()
    qapp.processEvents()
    # بلا قصّ صامت: البطاقة تستوعب السطر الملتف ضمن ارتفاعها
    assert card.title_lbl.height() >= card.title_lbl.fontMetrics().height()
    card.close()


def test_bar_chart_long_labels_render(qapp):
    from sdf_app.ui.widgets import BarChart
    ch = BarChart()
    ch.set_data([("فرع ذو اسم طويل جدًا يتجاوز العرض الثابت القديم بكثير", 5),
                 ("قصير", 3)])
    ch.resize(360, 120)
    ch.show()
    qapp.processEvents()
    pm = ch.grab()
    assert not pm.isNull()
    ch.close()
