from pathlib import Path

from tools.scan_artifacts import main, scan_roots


def test_scanner_passes_clean_text_and_binary(tmp_path):
    root = tmp_path / "dist"
    root.mkdir()
    (root / "readme.txt").write_text("Build completed. token=your_token_here\n", encoding="utf-8")
    (root / "app.exe").write_bytes(b"MZ\x00\x01\xffbinary")
    assert scan_roots([root]) == []


def test_scanner_detects_private_key_without_printing_contents(tmp_path, capsys):
    root = tmp_path / "logs"
    root.mkdir()
    marker = "-----BEGIN PRIVATE KEY-----\nVERY_SECRET_CONTENT\n"
    (root / "build.log").write_text(marker, encoding="utf-8")
    assert main([str(root)]) == 1
    output = capsys.readouterr().out
    assert "private-key-marker" in output
    assert "VERY_SECRET_CONTENT" not in output


def test_scanner_detects_credential_assignment(tmp_path):
    root = tmp_path / "logs"
    root.mkdir()
    (root / "debug.txt").write_text("api_key=not-a-real-but-long-secret\n", encoding="utf-8")
    findings = scan_roots([root])
    assert any("credential-assignment" in finding for finding in findings)


def test_scanner_rejects_sensitive_file_extensions(tmp_path):
    root = tmp_path / "dist"
    root.mkdir()
    (root / "user-data.db").write_bytes(b"SQLite format 3\x00")
    findings = scan_roots([root])
    assert any("blocked-file-type" in finding for finding in findings)


def test_scanner_rejects_symlink(tmp_path):
    root = tmp_path / "dist"
    root.mkdir()
    target = tmp_path / "outside.txt"
    target.write_text("normal", encoding="utf-8")
    link = root / "linked.txt"
    try:
        link.symlink_to(target)
    except (OSError, NotImplementedError):
        return
    findings = scan_roots([root])
    assert any("symlink-in-artifact" in finding for finding in findings)
