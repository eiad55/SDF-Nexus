# -*- coding: utf-8 -*-
import os
import sys
from pathlib import Path

import pytest

# Select Qt offscreen only on headless Unix runners; preserve native Windows UI backend.
if os.name != "nt" and not os.environ.get("DISPLAY") and not os.environ.get("WAYLAND_DISPLAY"):
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))


@pytest.fixture(scope="session")
def qapp():
    """Create exactly one QApplication for the entire test process."""
    from sdf_app.ui.app import create_app

    app = create_app([])
    app.setQuitOnLastWindowClosed(False)
    yield app
    _dispose_qt_widgets(app)


def _dispose_qt_widgets(app) -> None:
    """Close top-level widgets and flush deferred Qt deletions deterministically."""
    from PySide6.QtCore import QCoreApplication, QEvent

    for widget in list(app.topLevelWidgets()):
        try:
            widget.close()
            widget.deleteLater()
        except RuntimeError:
            # The C++ object may already have been deleted by Qt.
            pass
    QCoreApplication.sendPostedEvents(None, QEvent.DeferredDelete)
    app.processEvents()


@pytest.fixture(autouse=True)
def cleanup_qt_widgets_after_each_test():
    """Prevent widgets created by one test from surviving into the next test."""
    yield
    try:
        from PySide6.QtWidgets import QApplication
    except ImportError:
        return
    app = QApplication.instance()
    if app is not None:
        _dispose_qt_widgets(app)
