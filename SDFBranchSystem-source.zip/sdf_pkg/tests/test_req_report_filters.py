# -*- coding: utf-8 -*-
"""اختبارات متطلبات 2026-10-19 — فلاتر التقارير الثمانية (بند 9) على بيانات معروفة."""
import pytest

from sdf_app.database.connection import Database
from sdf_app.database.seeds import seed_all
from sdf_app.reports import excel_reports as er
from sdf_app.services.file_service import FileService


@pytest.fixture()
def conn(tmp_path):
    db = Database(tmp_path / "t.db")
    c = db.connect()
    seed_all(c)
    fs = FileService(c)

    def add(num, **kw):
        data = {"file_number": num, "program_name": f"برنامج {num}",
                "received_date": "2026-01-05"}
        data.update(kw)
        return fs.create(data, user_id=1)

    add(11, exec_start="2026-03-01", exec_end="2026-03-10", contract_date="2026-01-15",
        contract_trainees=30, contract_cost_per_trainee=1000, contract_hours=40,
        supervisor_name="مشرف أ")
    add(22, exec_start="2026-05-01", exec_end="2026-05-05", contract_date="2026-02-01",
        contract_trainees=10, contract_cost_per_trainee=2000, contract_hours=20,
        supervisor_name="مشرف ب")
    add(33, exec_start="2026-03-20", exec_end="2026-03-25", contract_date="2026-01-20",
        contract_trainees=30, contract_cost_per_trainee=500, contract_hours=60,
        supervisor_name="مشرف أ")
    add(44, exec_start="2026-06-01", exec_end="2026-06-03", contract_date="2026-03-01",
        contract_trainees=2, contract_cost_per_trainee=100, cost_currency="USD",
        exchange_rate=2000, contract_hours=10, supervisor_name="مشرف ج")
    c.execute("UPDATE training_files SET status_id="
              "(SELECT id FROM file_statuses WHERE code='disbursed') WHERE file_number=33")
    c.commit()
    yield c
    db.close()


def _nums(conn, filters):
    where, params = er._with_filters("1=1", (), filters)
    rows = er._rows_with_finance(conn, where, params)
    return {r["file_number"] for r in rows}


def test_no_filters_returns_all(conn):
    assert _nums(conn, {}) == {11, 22, 33, 44}
    assert _nums(conn, None) == {11, 22, 33, 44}


def test_exec_date_overlap(conn):
    assert _nums(conn, {"exec_from": "2026-03-01", "exec_to": "2026-03-31"}) == {11, 33}
    assert _nums(conn, {"exec_from": "2026-04-01", "exec_to": "2026-04-30"}) == set()
    # حد واحد فقط: كل ما يبدأ قبل نهاية يونيو وينتهي بعد بدايته
    assert _nums(conn, {"exec_to": "2026-03-15"}) == {11}


def test_contract_date_range(conn):
    assert _nums(conn, {"contract_from": "2026-01-01", "contract_to": "2026-01-31"}) == {11, 33}
    assert _nums(conn, {"contract_from": "2026-02-01"}) == {22, 44}


def test_numeric_comparisons(conn):
    assert _nums(conn, {"numeric": [("trainees", "=", 30)]}) == {11, 33}
    assert _nums(conn, {"numeric": [("trainees", "<", 15)]}) == {22, 44}
    assert _nums(conn, {"numeric": [("cost_per", ">", 750)]}) == {11, 22, 44}
    assert _nums(conn, {"numeric": [("total", "=", 30000)]}) == {11}
    assert _nums(conn, {"numeric": [("total", ">", 15000)]}) == {11, 22, 44}
    assert _nums(conn, {"numeric": [("hours", "=", 60)]}) == {33}
    # الدولار يُحوَّل بسعر الصرف: فرد 44 = 100$ × 2000 = 200,000 ريال
    assert _nums(conn, {"numeric": [("cost_per", ">", 150000)]}) == {44}
    assert _nums(conn, {"numeric": [("total", "=", 400000)]}) == {44}


def test_supervisor_and_disbursed(conn):
    assert _nums(conn, {"supervisor": "مشرف أ"}) == {11, 33}
    assert _nums(conn, {"disbursed_only": True}) == {33}
    assert _nums(conn, {"supervisor": "غير موجود"}) == set()


def test_combined_filters(conn):
    f = {"supervisor": "مشرف أ", "numeric": [("trainees", "=", 30)],
         "exec_from": "2026-03-01", "exec_to": "2026-03-31"}
    assert _nums(conn, f) == {11, 33}
    f["disbursed_only"] = True
    assert _nums(conn, f) == {33}


def test_filters_reach_excel_report(conn, tmp_path):
    from openpyxl import load_workbook
    out = tmp_path / "fin.xlsx"
    er.report_financial(conn, out, filters={"disbursed_only": True})
    wb = load_workbook(out)
    ws = wb.active
    nums = [ws.cell(row=i, column=1).value for i in range(3, 10)]
    nums = [n for n in nums if n is not None]
    assert nums == [33]


def test_reports_page_filters_build_and_clear(tmp_path, qapp, monkeypatch):
    from PySide6.QtWidgets import QMessageBox
    from sdf_app.ui.context import AppContext
    from sdf_app.ui.reports_page import ReportsPage
    monkeypatch.setattr(QMessageBox, "warning", staticmethod(lambda *a, **k: QMessageBox.Ok))
    c = AppContext(db_path=tmp_path / "ui.db")
    c.user = {"id": 1, "username": "admin", "full_name": "مدير", "role": "admin"}
    fs = FileService(c.conn)
    fs.create({"file_number": 55, "program_name": "ب", "received_date": "2026-01-05",
               "supervisor_name": "مشرف واجهة"}, user_id=1)
    page = ReportsPage(c)
    page._load_report_filters()
    names = [page.rep_supervisor.itemText(i) for i in range(page.rep_supervisor.count())]
    assert "مشرف واجهة" in names  # من البيانات الفعلية
    page.f_exec_from.edit.setText("01/03/2026")
    op, val = page.num_fields["trainees"]
    op.setCurrentText(">")
    val.setText("10")
    page.rep_disbursed.setChecked(True)
    f = page._report_filters()
    assert f["exec_from"] == "2026-03-01"
    assert f["numeric"] == [("trainees", ">", 10.0)]
    assert f["disbursed_only"] is True
    page._clear_filters()
    f2 = page._report_filters()
    assert f2["exec_from"] is None and f2["numeric"] == [] and f2["disbursed_only"] is False
    # قيمة رقمية فاسدة تُرفض برسالة واضحة لا بنتائج خاطئة
    page.num_fields["hours"][1].setText("abc")
    with pytest.raises(ValueError):
        page._report_filters()
    page.close()
    c.db.close()
