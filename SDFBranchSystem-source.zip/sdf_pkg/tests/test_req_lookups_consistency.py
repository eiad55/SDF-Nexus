# -*- coding: utf-8 -*-
"""اختبارات متطلبات 2026-10-19 — اتساق القوائم المرجعية (11.1/11.2) ومدربون (13)."""
import pytest

from PySide6.QtWidgets import QMessageBox

from sdf_app.database.connection import Database
from sdf_app.database.seeds import seed_all
from sdf_app.services.file_service import FileService
from sdf_app.ui.context import AppContext


@pytest.fixture()
def conn(tmp_path):
    db = Database(tmp_path / "t.db")
    c = db.connect()
    seed_all(c)
    yield c
    db.close()


@pytest.fixture()
def ctx(tmp_path, qapp, monkeypatch):
    monkeypatch.setattr(QMessageBox, "warning", staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "information", staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "critical", staticmethod(lambda *a, **k: QMessageBox.Ok))
    monkeypatch.setattr(QMessageBox, "question",
                        staticmethod(lambda *a, **k: QMessageBox.Yes))
    c = AppContext(db_path=tmp_path / "ui.db")
    c.user = {"id": 1, "username": "admin", "full_name": "مدير النظام", "role": "admin"}
    yield c
    c.db.close()


def test_dashboard_stats_exclude_inactive_branch_and_field(conn):
    fs = FileService(conn)
    conn.execute("INSERT INTO branches (name) VALUES ('فرع سيعطّل')")
    conn.execute("INSERT INTO program_fields (name) VALUES ('مجال سيعطّل')")
    conn.commit()
    bid = conn.execute("SELECT id FROM branches WHERE name='فرع سيعطّل'").fetchone()[0]
    fid_ = conn.execute("SELECT id FROM program_fields WHERE name='مجال سيعطّل'").fetchone()[0]
    fs.create({"file_number": 88, "program_name": "ب", "received_date": "2026-01-05",
               "branch_id": bid, "field_id": fid_}, user_id=1)
    stats = fs.dashboard_stats()
    assert "فرع سيعطّل" in [r["name"] for r in stats["by_branch"]]
    conn.execute("UPDATE branches SET active=0 WHERE id=?", (bid,))
    conn.execute("UPDATE program_fields SET active=0 WHERE id=?", (fid_,))
    conn.commit()
    stats = fs.dashboard_stats()
    assert "فرع سيعطّل" not in [r["name"] for r in stats["by_branch"]]
    assert "مجال سيعطّل" not in [r["name"] for r in stats["by_field"]]
    # التاريخ سليم: الملف نفسه ما زال موجودًا ومرتبطًا
    assert conn.execute("SELECT COUNT(*) c FROM training_files").fetchone()["c"] == 1


def test_review_items_visible_only_hides_unreviewed_inactive_keeps_reviewed(conn):
    fs = FileService(conn)
    conn.execute("INSERT INTO document_types (name) VALUES ('وثيقة ستعطّل')")
    conn.execute("INSERT INTO document_types (name) VALUES ('وثيقة رُوجعت')")
    conn.commit()
    d1 = conn.execute("SELECT id FROM document_types WHERE name='وثيقة ستعطّل'").fetchone()[0]
    d2 = conn.execute("SELECT id FROM document_types WHERE name='وثيقة رُوجعت'").fetchone()[0]
    fid = fs.create({"file_number": 89, "program_name": "ب", "received_date": "2026-01-05"},
                    user_id=1)
    conn.execute("INSERT INTO review_items (file_id, document_type_id)"
                 " VALUES (?, ?)", (fid, d1))
    conn.execute("INSERT INTO review_items (file_id, document_type_id, result)"
                 " VALUES (?, ?, 'مطابق')", (fid, d2))
    conn.execute("UPDATE document_types SET active=0 WHERE id IN (?,?)", (d1, d2))
    conn.commit()
    all_items = fs.review_items(fid)
    assert len(all_items) == 2  # الافتراضي: كل شيء (التاريخ محفوظ)
    visible = fs.review_items(fid, visible_only=True)
    names = [it["document_name"] for it in visible]
    assert names == ["وثيقة رُوجعت"]  # غير المراجعة اختفت، والمراجعة بقيت


def _select_lookup(page, table, kind=None):
    for i in range(page.lookup_cb.count()):
        if page.lookup_cb.itemData(i) == (table, kind):
            page.lookup_cb.setCurrentIndex(i)
            return
    raise AssertionError((table, kind))


def test_settings_lookup_search_reactivate_and_audit(ctx, qapp):
    from sdf_app.ui.settings_page import SettingsPage
    page = SettingsPage(ctx)
    # اختر قائمة الفروع
    _select_lookup(page, "branches")
    page.new_name.setText("فرع بحثي")
    page._lookup_add()
    names = [page.lookup_list.item(i).text() for i in range(page.lookup_list.count())]
    assert "فرع بحثي" in names
    # البحث يرشّح فورًا
    page.lookup_search.setText("بحثي")
    names = [page.lookup_list.item(i).text() for i in range(page.lookup_list.count())]
    assert names == ["فرع بحثي"]
    page.lookup_search.clear()
    # تعطيل ثم إعادة إضافة بالاسم نفسه = إعادة تفعيل لا تكرار
    page.lookup_list.setCurrentItem(
        next(page.lookup_list.item(i) for i in range(page.lookup_list.count())
             if page.lookup_list.item(i).text() == "فرع بحثي"))
    page._lookup_del()
    assert ctx.conn.execute(
        "SELECT active FROM branches WHERE name='فرع بحثي'").fetchone()[0] == 0
    page.new_name.setText("فرع بحثي")
    page._lookup_add()
    rows = ctx.conn.execute("SELECT active FROM branches WHERE name='فرع بحثي'").fetchall()
    assert len(rows) == 1 and rows[0][0] == 1
    actions = [r[0] for r in ctx.conn.execute(
        "SELECT action FROM audit_log WHERE entity='branches'")]
    assert "lookup.deactivate" in actions and "lookup.reactivate" in actions
    page.close()


def test_document_types_management_list_hides_inactive(ctx, qapp):
    from sdf_app.ui.settings_page import SettingsPage
    ctx.conn.execute("INSERT INTO document_types (name, active) VALUES ('نوع معطّل', 0)")
    ctx.conn.commit()
    page = SettingsPage(ctx)
    _select_lookup(page, "document_types")
    names = [page.lookup_list.item(i).text() for i in range(page.lookup_list.count())]
    assert "نوع معطّل" not in names
    page.close()


def test_trainer_soft_delete_keeps_history_and_hides_from_choices(ctx, qapp):
    from sdf_app.ui.file_dialog import FileDialog
    from sdf_app.ui.settings_page import SettingsPage
    ctx.conn.execute("INSERT INTO trainers (name, qualification) VALUES ('مدرب قديم', 'دكتوراه')")
    ctx.conn.commit()
    tid = ctx.conn.execute("SELECT id FROM trainers WHERE name='مدرب قديم'").fetchone()[0]
    page = SettingsPage(ctx)
    # تبويب المدربين هو الثاني
    page.tabs.setCurrentIndex(1)
    qapp.processEvents()
    assert "مدرب قديم" in [page.trainers_table.item(i, 0).text()
                            for i in range(page.trainers_table.rowCount())]
    page.trainers_table.selectRow(0)
    page._trainer_del()
    row = ctx.conn.execute("SELECT active FROM trainers WHERE id=?", (tid,)).fetchone()
    assert row is not None and row[0] == 0  # لم يُحذف فعليًا
    assert page.trainers_table.rowCount() == 0  # اختفى من قائمة الإدارة
    page.close()
    # ولا يظهر في قائمة اختيار مدرب الملف الجديد
    dlg = FileDialog(ctx)
    combo = dlg.widgets["trainer_id"][0]
    assert "مدرب قديم" not in [combo.itemText(i) for i in range(combo.count())]
    dlg.close()
